from .Globals import *

class Themes():
    def __init__(self):
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
            
        with dpg.theme(tag = G.LINE_THEME):
            with dpg.theme_component(dpg.mvAll):
                dpg.add_theme_color(dpg.mvPlotCol_Line, 
                                    G.CONFIG_DICT['default_colors']['default_crosshair_color'], 
                                    tag = 'crosshair_color_theme', 
                                    category = dpg.mvThemeCat_Plots)
                
            # Set up colormap registry
        for cmap_key in list(G.COLORMAP_DICT.keys()):
            
            cmap_name = f'{G.COLORMAP_DICT[cmap_key]["name"]}' # eg, m_fire
            cmap_name_r = f'{cmap_name}_r'

            rgb_values = getattr(G.COLORMAP_DICT[cmap_key]['module'], cmap_name)(list(range(256)))
            rgb_values_r = getattr(G.COLORMAP_DICT[cmap_key]['module'], cmap_name_r)(list(range(256)))

            dpg.add_colormap(list(np.round(rgb_values*255, decimals = 4)), False, parent = G.COLORMAP_TAG, tag=f'colormap_{cmap_name}')
            dpg.add_colormap(list(np.round(rgb_values_r*255, decimals = 4)), False, parent = G.COLORMAP_TAG, tag=f'colormap_{cmap_name_r}')

            print(f'{cmap_key} registered')

    def _cleanup_(self):
        pass