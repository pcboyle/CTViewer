from .Globals import *

class InformationBox(object):
    def __init__(self):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.group_text = ''
        self.landmark_volumes = {}
        self.items = []
        self.landmark_circles = []
        self.aliases = []
        self.infobox_options = []
        
        with dpg.child_window(width = G.CONFIG_DICT['app_settings']['info_box_width'], # G.INFORMATION_BOX_WINDOW_DEFAULTS['WINDOW_WIDTH'], 
                              height = G.CONFIG_DICT['app_settings']['info_box_height']): #G.INFORMATION_BOX_WINDOW_DEFAULTS['WINDOW_HEIGHT']):
            with dpg.tab_bar():
                with dpg.tab(label = 'Landmarks', tag = 'landmark_tab'):
                    dpg.add_button(label = 'Save Landmarks', tag = 'save_landmarks_button', 
                                   callback = self.save_landmarks, enabled=False)

                with dpg.tab(label = 'Group Tab', tag = 'InfoBoxTab_groups'):
                    dpg.add_text(self.group_text, tag = 'group_tab_text')

                with dpg.tab(label = 'Layer Tab', tag = 'InfoBoxTab_layers'):
                    dpg.add_text('', tag = 'InfoBoxTab_layers_text')

                with dpg.tab(label = 'Histograms', tag = 'InfoBoxTab_volume_histograms'):
                    with dpg.group(tag = 'InfoBox_histogram_volume'):
                        with dpg.plot(label = '', tag = 'InfoBoxTab_histogram_volume_plot', width = -1, height = 250):
                            dpg.add_plot_axis(dpg.mvXAxis, tag = 'InfoBoxTab_histogram_volume_plot_xaxis')
                            dpg.add_plot_axis(dpg.mvYAxis, tag = 'InfoBoxTab_histogram_volume_plot_yaxis')
                            dpg.add_line_series(np.zeros(5), np.zeros(5), parent = 'InfoBoxTab_histogram_volume_plot_yaxis', 
                                                show = False, tag = 'InfoBoxTab_histogram_volume_plot_line_series')
                        with dpg.group(horizontal=True):
                            dpg.add_text('Bins Min:')
                            dpg.add_input_float(label = '', callback = self.update_histogram_volume, width = 100, 
                                                step = 1, step_fast = 5,
                                                default_value = -3500, tag = 'InfoBoxTab_histogram_volume_bins_min')
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                            dpg.add_checkbox(label = 'Enable', tag = 'InfoBoxTab_histogram_volume_bins_min_checkbox', 
                                             default_value=True, callback = self.update_histogram_volume)
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                        with dpg.group(horizontal=True):
                            dpg.add_text('Bins Max:')
                            dpg.add_input_float(label = '', callback = self.update_histogram_volume, width = 100, step = 1, 
                                                step_fast = 5,
                                                default_value = 3500, tag = 'InfoBoxTab_histogram_volume_bins_max')
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                            dpg.add_checkbox(label = 'Enable', tag = 'InfoBoxTab_histogram_volume_bins_max_checkbox', 
                                             default_value=True, callback = self.update_histogram_volume)
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                        with dpg.group(horizontal=True):
                            dpg.add_text('Bin Step:')
                            dpg.add_input_float(label = '', callback = self.update_histogram_volume, width = 100, step = 1, 
                                                step_fast = 5,
                                                default_value = 1, tag = 'InfoBoxTab_histogram_volume_bin_step')
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                            dpg.add_checkbox(label = 'Enable', tag = 'InfoBoxTab_histogram_volume_bin_step_checkbox', 
                                             default_value=True, callback = self.update_histogram_volume)
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                    with dpg.group(tag = 'InfoBox_histogram_current_view'):
                        with dpg.plot(label = '', tag = 'InfoBoxTab_histogram_current_view_plot', width = -1, height = 250):
                            dpg.add_plot_axis(dpg.mvXAxis, tag = 'InfoBoxTab_histogram_current_view_plot_xaxis')
                            dpg.add_plot_axis(dpg.mvYAxis, tag = 'InfoBoxTab_histogram_current_view_plot_yaxis')
                            dpg.add_line_series(np.zeros(5), np.zeros(5), parent = 'InfoBoxTab_histogram_current_view_plot_yaxis', 
                                                show = False, tag = 'InfoBoxTab_histogram_current_view_plot_line_series')
                        with dpg.group(horizontal=True):
                            dpg.add_text('Bins Min:')
                            dpg.add_input_float(label = '', callback = self.update_histogram_current_view, width = 100, 
                                                step = 1, step_fast = 5,
                                                default_value = -3500, tag = 'InfoBoxTab_histogram_current_view_bins_min')
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                            dpg.add_checkbox(label = 'Enable', tag = 'InfoBoxTab_histogram_current_view_bins_min_checkbox', 
                                             default_value=True, callback = self.update_histogram_current_view)
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                        with dpg.group(horizontal=True):
                            dpg.add_text('Bins Max:')
                            dpg.add_input_float(label = '', callback = self.update_histogram_current_view, width = 100, step = 1, 
                                                step_fast = 5,
                                                default_value = 3500, tag = 'InfoBoxTab_histogram_current_view_bins_max')
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                            dpg.add_checkbox(label = 'Enable', tag = 'InfoBoxTab_histogram_current_view_bins_max_checkbox', 
                                             default_value=True, callback = self.update_histogram_current_view)
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                        with dpg.group(horizontal=True):
                            dpg.add_text('N Bins  :')
                            dpg.add_input_int(label = '', callback = self.update_histogram_current_view, width = 100, step = 1, 
                                                step_fast = 5,
                                                default_value = 100, tag = 'InfoBoxTab_histogram_current_view_n_bins')
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                            dpg.add_checkbox(label = '', tag = 'InfoBoxTab_histogram_current_view_n_bins_checkbox', 
                                             default_value=True, callback = self.update_histogram_current_view)
                            self.infobox_options.append(dpg.get_item_alias(dpg.last_item()))
                if G.DEBUG_MODE:
                    with dpg.tab(label = 'Debug Tab'):
                        with dpg.table(header_row = False, tag = 'DEBUG_TABLE', resizable=True):
                            dpg.add_table_column()
                            dpg.add_table_column()
                            for debug_tag in G.DEBUG_INFO_TAGS:
                                with dpg.table_row():
                                    dpg.add_text(debug_tag, tag = f'{debug_tag}_debug_label')
                                    if G.FILE_LOADED:
                                        dpg.add_text(default_value = f'{getattr(G.APP.main_view, debug_tag)}', 
                                                     tag = f'{debug_tag}_debug_info')
                                    else:
                                        dpg.add_text(default_value = 'Test', tag = f'{debug_tag}_debug_info')


    def update_histogram_volume(self):
        G.APP.main_view.update_histogram()

    def update_histogram_current_view(self):
        G.APP.main_view.update_histogram_current_view()


    def update_layer_tab(self):
        pass


    def update_landmark_colors(self):
        for landmark_circle in self.landmark_circles:
            if dpg.does_item_exist(landmark_circle):
                landmark_color = dpg.get_item_configuration(landmark_circle)['color']
                landmark_color_pick = dpg.get_value('landmark_color_picker')
                new_color = [landmark_color_pick[0] * 255.0, 
                             landmark_color_pick[1] * 255.0, 
                             landmark_color_pick[2] * 255.0, 
                             landmark_color[3] * 255.0]

                dpg.configure_item(landmark_circle, color = new_color)


    def update_landmark_radius(self, radius):
        for landmark_circle in self.landmark_circles: # Dictionary that's referenced elsewhere. 
            if dpg.does_item_exist(landmark_circle):
                dpg.configure_item(landmark_circle, radius = radius)


    def save_landmarks(self):
        if len(self.landmark_volumes.keys()) == 0:
            return

        file_path = G.CURRENT_FILE.parent.joinpath(f'{G.CURRENT_FILE.stem}_landmarks.xlsx')

        excel_writer = pandas.ExcelWriter(file_path, engine = 'xlsxwriter', 
                                          engine_kwargs = {'options': {'strings_to_numbers': True}})
        print(f'Saving landmarks at {file_path}.')
        
        for volume in self.landmark_volumes.keys():
            volume_sheet_name = volume.replace('/', '-')
            volume_landmark_dict_list = []
            for landmark_index in self.landmark_volumes[volume]['Landmarks'].keys():
                landmark = self.landmark_volumes[volume]['Landmarks'][landmark_index]['Landmark']
                quaternion = self.landmark_volumes[volume]['Landmarks'][landmark_index]['Quaternion'].tolist()
                volume_landmark_dict_list.append({'x':landmark[0], 'y':landmark[1], 
                                                  'z':landmark[2], 'hu':landmark[3], 
                                                  'qtn_a':quaternion[0], 'qtn_b': quaternion[1], 
                                                  'qtn_c':quaternion[2], 'qtn_d': quaternion[3]})

            dataframe = pandas.DataFrame(volume_landmark_dict_list)
            dataframe.to_excel(excel_writer, sheet_name = volume_sheet_name, )

        excel_writer.close()


    def add_landmark(self, option = 'mouse'):
        """
        current_volume is the current volume information object
        landmark_point is the point we've clicked on and is [x, y, z, hu]

        """

        current_volume = G.APP.main_view.current_volume_info

        if option == 'mouse':
            landmark_point_image = G.APP.main_view.mouse_position_information[:4] # [x, y, z, hu]
            landmark_point_viewport = G.APP.main_view.mouse_position_information[4:6]
            landmark_point_view = G.APP.main_view.mouse_position_information[6:9] # [x, y, z] in the viewport coordinates. 
            landmark_quaternion = G.APP.main_view.mouse_position_information[9]
            landmark_view = G.APP.main_view.mouse_position_information[-1] # 11 x 11 array of the view when we captured this point. 

        elif option == 'spacebar':
            landmark_point_image = G.APP.main_view.crosshair_position_information[:4] # [x, y, z, hu]
            landmark_point_viewport = G.APP.main_view.crosshair_position_information[4:6] # Always [0, 0] since the crosshair defines that location.
            landmark_point_view = G.APP.main_view.crosshair_position_information[6:9] # [x, y, z] in the viewport coordinates. 
            landmark_quaternion = G.APP.main_view.crosshair_position_information[9]
            landmark_view = G.APP.main_view.crosshair_position_information[-1] # 11 x 11 array of the view when we captured this point. 

        else:
            print(f"Unknown landmark option {option}.")
            return

        print(landmark_point_viewport)
        volume_name = current_volume.name
        current_volume.landmark_points[f'{current_volume.n_landmarks}'] = {'Image Coords': landmark_point_image, 
                                                                           'Viewport Coords': landmark_point_view, 
                                                                           'Orientation': landmark_quaternion,
                                                                           'Landmark View': landmark_view,
                                                                           'viewport_circle': dpg.draw_circle((landmark_point_viewport[0], landmark_point_viewport[1]),
                                                                                                              radius = G.APP.image_tools.landmark_radius,
                                                                                                              show = True,
                                                                                                              tag = f'{volume_name}_landmark_{current_volume.n_landmarks}_circle',
                                                                                                              color = dpg.get_value('landmark_color_picker'),
                                                                                                              parent = G.MAIN_PLOT_VIEW)}

        self.landmark_circles.append(f'{volume_name}_landmark_{current_volume.n_landmarks}_circle')
        self.items.append(f'{volume_name}_landmark_{current_volume.n_landmarks}_circle')

        G.APP.main_view.update_view()

        if volume_name not in self.landmark_volumes.keys():
            self.landmark_volumes[volume_name] = {'volume_object': current_volume, 'Landmarks': {}}
            with dpg.tree_node(label = volume_name, tag = f'{volume_name}_landmarks_node', parent = 'landmark_tab'):
                self.items.append(f'{volume_name}_landmarks_node')
                with dpg.table(header_row = False, tag = f'{volume_name}_landmarks_table'):
                    self.items.append(f'{volume_name}_landmarks_table')
                    dpg.add_table_column()

        self.landmark_volumes[volume_name]['Landmarks'][f'{current_volume.n_landmarks}'] = {'Landmark': landmark_point_image, 
                                                                                            'View': landmark_point_view, 
                                                                                            'Quaternion': landmark_quaternion,
                                                                                            'Rotation Matrix': landmark_quaternion.to_rotation_matrix,
                                                                                            'volume_object': current_volume}
        
        with dpg.table_row(parent=f'{volume_name}_landmarks_table', tag = f'{volume_name}_landmark_{current_volume.n_landmarks}_row'):
            dpg.add_selectable(label = f'{landmark_point_image[0]:<7}, {landmark_point_image[1]:<7}, {landmark_point_image[2]:<7}, {landmark_point_image[3]:<7}', 
                               tag = f'{volume_name}_landmark_{current_volume.n_landmarks}_selectable')
            self.items.append(f'{volume_name}_landmark_{current_volume.n_landmarks}_selectable')
            self.items.append(f'{volume_name}_landmark_{current_volume.n_landmarks}_row')
            
            with dpg.popup(dpg.last_item(), mousebutton = dpg.mvMouseButton_Right, min_size = [15, 15]):
                dpg.add_button(label = 'Remove Landmark', tag = f'remove++{volume_name}++landmark++{current_volume.n_landmarks}', callback = self.remove_landmark)
                self.items.append(f'remove++{volume_name}++landmark++{current_volume.n_landmarks}')
            # Want to add popup that shows the view when we chose the landmark. 
            # with dpg.tooltip(dpg.last_item()):

        current_volume.n_landmarks += 1
        print(volume_name, current_volume.n_landmarks, landmark_point_image)


    def remove_landmark(self, sender, app_data):
        
        volume_name = sender.split('++')[1]
        landmark_index = int(sender.split('++')[-1])

        dpg.configure_item(dpg.get_item_parent(sender), show=False)

        del getattr(self.landmark_volumes[volume_name]['volume_object'], 'landmark_points')[f'{landmark_index}']
        del self.landmark_volumes[volume_name]['Landmarks'][f'{landmark_index}']

        dpg.delete_item(f'{volume_name}_landmark_{landmark_index}_row')
        dpg.delete_item(f'{volume_name}_landmark_{landmark_index}_selectable')
        dpg.delete_item(f'{volume_name}_landmark_{landmark_index}_circle')
        print(f'Deleted {volume_name}_landmark_{landmark_index}_selectable')
        print(f'Deleted {volume_name}_landmark_{landmark_index}_circle')

        G.APP.main_view.update_view()
    
    def reset_histogram_plot(self):
        dpg.hide_item('InfoBoxTab_histogram_volume_plot_line_series')
        dpg.set_value('InfoBoxTab_histogram_volume_plot_line_series', 
                      [np.zeros(5), np.zeros(5)])
        dpg.hide_item('InfoBoxTab_histogram_current_view_plot_line_series')
        dpg.set_value('InfoBoxTab_histogram_current_view_plot_line_series', 
                      [np.zeros(5), np.zeros(5)])
        

    def load_image(self):
        self.update_group_names()
        self.enable_options()
        dpg.show_item('InfoBoxTab_histogram_volume_plot_line_series')
        dpg.show_item('InfoBoxTab_histogram_current_view_plot_line_series')

    def close_image(self):
        for item in self.items:
            if dpg.does_item_exist(item):
                dpg.delete_item(item)
            
            if dpg.does_alias_exist(item):
                dpg.remove_alias(item)

        self.landmark_volumes.clear()
        self.reset_histogram_plot()
        self.disable_options()


    def update_group_names(self):
        self.group_text = ''
        for group in G.APP.VolumeLayerGroups.group_names:
            self.group_text = f'{self.group_text}\n{group}'
        dpg.set_value('group_tab_text', self.group_text)

    
    def enable_options(self):
        for option_tag in self.infobox_options:
            dpg.enable_item(option_tag)
    

    def disable_options(self):
        for option_tag in self.infobox_options:
            dpg.disable_item(option_tag)

    def _cleanup_(self):
        pass