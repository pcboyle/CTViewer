# Updating ct_viewer module for the current user
Write-Host "Updating ct_viewer module for $env:USERNAME."

# Source the required Conda and Mamba scripts
# In PowerShell, this would require invoking the appropriate script to activate the environment
# Assuming conda is added to the path
& "conda" "activate" "ct_viewer"

# Get the active environment
$active_environment = (& "mamba" "info" | Select-String 'active environment').Line.Split(":")[1].Trim()

Write-Host "Updating ct_viewer module in the $active_environment environment."

# Change to the directory containing the .whl files
Set-Location "$env:USERPROFILE\Dropbox\Code\Python\medical_physics\ct_viewer\dist"

# Find the latest .whl file
$latest_whl_file = Get-ChildItem -Filter *.whl | Sort-Object LastWriteTime | Select-Object -Last 1

# Extract the latest version from the .whl file name
$latest_version = ($latest_whl_file.Name -split '-')[1]

# Get the currently installed version of ct_viewer
$installed_version = (mamba list ^ct --json | ConvertFrom-Json)[0].version

# Compare the versions
if ($latest_version -eq $installed_version) 
{
    Write-Host "Installed version $installed_version matches the latest version $latest_version. Exiting script."
} 
else 
{
    Write-Host "Updating ct_viewer from $installed_version to $latest_version."

    # Install the latest version using pip
    pip install --no-deps --no-build-isolation $latest_whl_file.FullName
}