from .Globals import *
from . import OptionValue
from . import CTVolume


class VolumeLayer(object):
    """
    default_orientation = [0, 0, 0, 0, 0, 0] -> [origin_x, origin_y, norm, pitch, yaw, roll]
    
    """

    # histogram_control_dict = {'min_value': ['InfoBoxTab_histogram_bins_min', 'InfoBoxTab_histogram_bins_min_checkbox'],
    #                           'max_value': ['InfoBoxTab_histogram_bins_max', 'InfoBoxTab_histogram_bins_max_checkbox'],
    #                           'step': ['InfoBoxTab_histogram_bin_step', 'InfoBoxTab_histogram_bin_step_checkbox']}
    
    def __init__(self, 
                 group, 
                 ctvolume,
                 volume_name = None, 
                 default_orientation = [0, 0, 0, 0, 0, 0], 
                 default_quaternion = G.QTN_DICT[G.VIEW], 
                 default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire'],
                 default_histogram = [0, 1200, 1, 'Linear'], # Bins min, max, step, scale
                 default_limits_origin = [-350, 350],
                 default_limits_norm = [-350, 350], 
                 default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]]):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.group = group
        self.ctvolume = ctvolume
        self.name = self.ctvolume.name if volume_name is not None else volume_name
        self.file = self.ctvolume.file
        self.group_name = group.group_name

        self.intensity_limits = default_limits_intensity
        self.control_list = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll', 'min_intensity', 'max_intensity', 'colormap']
        self.orientation_control_list = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll']
        self.intensity_control_list = ['min_intensity', 'max_intensity'] #, colormap]
        self.histogram_control_list = ['min_value', 'max_value', 'step', 'scale']
        self.orientation_control = G.DEFAULT_GROUP_LAYER_CONTROL
        self.intensity_control = G.DEFAULT_GROUP_LAYER_CONTROL
        self.is_volume_viewed = False
        
        self.layer_control = []
        self.group_control = [control_option for control_option in self.control_list]
        
        self.orientation = OptionValue.OrientationInfo(default_orientation = default_orientation, 
                                                       default_quaternion = default_quaternion, 
                                                       default_limits_origin = default_limits_origin,
                                                       default_limits_norm = default_limits_norm)
        
        self.intensity = OptionValue.IntensityInfo(default_intensity = default_intensity, 
                                                   default_limits = default_limits_intensity)
        

        self.histogram = OptionValue.HistogramInfo(default_histogram = default_histogram)

        self.view_plane = self.orientation.view_plane
        self.interpolator = self.ctvolume.interpolator
        self.mask_interpolator = self.ctvolume.mask_interpolator
        self.volume_center = self.ctvolume.volume_center

        self.colormap = self.intensity.colormap
        self.colormap_name = self.intensity.colormap_name
        self.colormap_string = self.intensity.get_colormap_string()
        self.colormap_reversed = self.intensity.colormap_reversed
        
        self.landmark_points = {} # Landmark_Index : Landmark_Dict

        self.n_landmarks = 0
        
        #self.transformation_history = [] # inverse_rotation, current_origin_vector, current_origin_difference, current_norm_direction

    def set_ctvolume(self, volume_name:str, volume_data:CTVolume.CTVolume):
        self.ctvolume = volume_data
        self.name = self.ctvolume.name if volume_name is not None else volume_name
        self.file = self.ctvolume.file

        pass

    def set_is_volume_viewed(self, volume_viewed_bool:bool = False):
        self.is_volume_viewed = volume_viewed_bool

    def add_to_group(self, group):
        if self.name not in group.volume_names:
            group.set_volume(self)

    def set_control_options(self, option_class:str, update:bool = False):

        if option_class not in ['orientation', 'intensity']:
            print(f'Option class {option_class} not recognized. Only "orientation" or "intensity" accepted.')
            return

        for control_option_name in getattr(self, f'{option_class}_control_list'):
            option_tag = G.OPTION_TAG_DICT[control_option_name]
            if getattr(self, f'{option_class}_control') == 'Group':
                control_option = getattr(getattr(self.group, option_class), control_option_name)
            else:
                control_option = getattr(getattr(self, option_class), control_option_name)
            if not update:
                dpg.configure_item(option_tag, min_value = control_option.limit_low, 
                                   max_value = control_option.limit_high, 
                                   default_value = control_option.default_value)
            dpg.set_value(f'{option_tag}_current_value', control_option.current_value)
            dpg.set_value(option_tag, control_option.current_value)        


    def get_attribute(self, attribute_name: str):
        if attribute_name not in list(self.__dict__.keys()):
            print(f'{attribute_name} not in {self.name}.')
            return
        return getattr(self, attribute_name)
    
    def set_attribute(self, attribute_name, attribute_value, make_copy = True):
        setattr(self, attribute_name, attribute_value)

    def reset_orientation(self):
        if self.orientation_control == 'Group':
            self.group.orientation.reset_orientation()

        else:
            self.orientation.reset_orientation()

    def update_orientation(self):
        if self.orientation_control == 'Group':
            self.group.orientation.update_orientation()
        
        else:
            self.orientation.update_orientation()

    def update_colormap(self):
        self.intensity.update_colormap()
        self.colormap = self.intensity.colormap
        self.colormap_reversed = self.intensity.colormap_reversed
        self.colormap_name = self.intensity.colormap_name
        self.colormap_string = self.intensity.get_colormap_string()

    def update_window(self, min_intensity, max_intensity, window_size):
        if self.intensity_control == 'Group':
            self.group.intensity.update_window(min_intensity, max_intensity, window_size)
        else:
            self.intensity.update_window(min_intensity, max_intensity, window_size)

    def set_dpg_window(self):        
        if self.intensity_control == 'Group':
            dpg.set_value(G.OPTION_TAG_DICT['min_intensity'], self.group.intensity.min_intensity.current_value)
            dpg.set_value(G.OPTION_TAG_DICT['max_intensity'], self.group.intensity.max_intensity.current_value)
            
        else:
            dpg.set_value(G.OPTION_TAG_DICT['min_intensity'], self.intensity.min_intensity.current_value)
            dpg.set_value(G.OPTION_TAG_DICT['max_intensity'], self.intensity.max_intensity.current_value)

    def update_control(self):
        
        # This will make it so we copy the group intensity to the current volume when we go from Layer -> group, reverting it
        # and from Group -> layer, ensuring we leave off from where the group was. 
        if G.FILE_LOADED:
            self.orientation.copy_orientation(getattr(G.APP.VolumeLayerGroups, G.APP.main_view.current_group_name).orientation)
            self.intensity.copy_intensity(getattr(G.APP.VolumeLayerGroups, G.APP.main_view.current_group_name).intensity)
            self.histogram.copy_histogram(getattr(G.APP.VolumeLayerGroups, G.APP.main_view.current_group_name).histogram)

        self.orientation_control = dpg.get_item_label(f'orientation_{G.GROUP_LAYER_CONTROL_BUTTON}')
        self.intensity_control = dpg.get_item_label(f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}')
        self.histogram_control = dpg.get_item_label(f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}')
        
    def interpolate_view(self, out_array = None, out_mask = None, view_plane = None, decimals = 2):
        if type(out_array) == type(None):
            return self.interpolator(cp.round(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T, decimals = decimals),
                                     method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:]
        else:
            if type(out_mask) == type(None):
                out_array[:] = self.interpolator(cp.round(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T, decimals = decimals),
                                                 method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)
            else:
                out_array[out_mask] = self.interpolator(cp.round(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T, decimals = decimals),
                                                        method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)[out_mask]
    
    def interpolate_mask(self, out_array = None, out_mask = None, view_plane = None):
        if type(out_array) == type(None):
            return self.mask_interpolator(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T,
                                      method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:]
        else:
            if type(out_mask) == type(None):
                out_array[:] = self.mask_interpolator(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T,
                                                      method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)
            else:
                out_array[out_mask] = self.mask_interpolator(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T,
                                                             method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)[out_mask]
    
    def get_orientation_value(self, value: str, modifier: str, check_control = True):

        if check_control and (self.orientation_control == 'Group'):
            return getattr(getattr(self.group.orientation, f'{value}'), f'{modifier}')

        return getattr(getattr(self.orientation, f'{value}'), f'{modifier}')
    

    def get_intensity_value(self, value: str, modifier:str, check_control = True):
        
        if check_control and (self.intensity_control == 'Group'):
            return getattr(getattr(self.group.intensity, f'{value}'), f'{modifier}')

        return getattr(getattr(self.intensity, f'{value}'), f'{modifier}')
    

    def set_dpg_histogram_values(self):
        dpg.set_value('InfoBoxTab_histogram_volume_bins_min', self.histogram.bins_min())
        dpg.set_value('InfoBoxTab_histogram_volume_bins_max', self.histogram.bins_max())
        dpg.set_value('InfoBoxTab_histogram_volume_bin_step', self.histogram.bin_step())


    def get_histogram(self, update_histogram = True, return_order = 'reversed', asnumpy = True):

        min_enabled = dpg.get_value('InfoBoxTab_histogram_volume_bins_min_checkbox')
        max_enabled = dpg.get_value('InfoBoxTab_histogram_volume_bins_max_checkbox')
        step_enabled = dpg.get_value('InfoBoxTab_histogram_volume_bin_step_checkbox')

        bin_min = dpg.get_value('InfoBoxTab_histogram_volume_bins_min') if min_enabled else None
        bin_max = dpg.get_value('InfoBoxTab_histogram_volume_bins_max') if max_enabled else None
        bin_step = dpg.get_value('InfoBoxTab_histogram_volume_bin_step') if step_enabled else None

        if update_histogram:
            self.histogram.update_histogram_params(min_value = bin_min, max_value = bin_max, bin_step = bin_step)
            self.histogram.update_histogram_counts(self.interpolator.values[~self.mask_interpolator.values.astype(bool)])
        
        return self.histogram.get_histogram(return_order = return_order, asnumpy = asnumpy)

    def set_dpg_histogram_limits(self, 
                                 x_axis, y_axis, unlock_axes = True,
                                 min_x = None, max_x = None, 
                                 min_y = None, max_y = None):
        
        dpg.set_axis_limits(x_axis, 
                            self.histogram.bins_min() if min_x is None else min_x,
                            self.histogram.bins_max() if max_x is None else max_x)
        
        dpg.set_axis_limits(y_axis, 
                            self.histogram.bin_counts().min() if min_y is None else min_y,
                            self.histogram.bin_counts().max() if max_y is None else max_y)
        
        if unlock_axes:
            dpg.set_axis_limits_auto(x_axis)
            dpg.set_axis_limits_auto(y_axis)

    def show_landmarks(self):
        for landmark_dict in self.landmark_points.values():
            dpg.show_item(landmark_dict['viewport_circle'])

    def hide_landmarks(self):
        for landmark_dict in self.landmark_points.values():
            dpg.hide_item(landmark_dict['viewport_circle'])

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_name = attrib_list.pop()
            if attrib_name == 'group':
                setattr(self, attrib_name, None)
                delattr(self, attrib_name)

            elif '_cleanup_' in dir(getattr(self, attrib_name)):
                try:
                    getattr(self, attrib_name)._cleanup_()
                finally:
                    setattr(self, attrib_name, None)
                    delattr(self, attrib_name)
            else:
                setattr(self, attrib_name, None)
                delattr(self, attrib_name)


class VolumeLayerGroup(object):
    """
    Each VolumeLayerGroup can hold volume information, but does not hold any volumes themselves. 
    
    Instead, it holds the orientation and rendering information for each volume in the group:
        
        Origin X
        Origin Y
        Origin Z
        Norm location
        Pitch
        Yaw
        Roll
        Min Intensity
        Max Intensity
        Colormap
        Quatnernion (Current, Previous, Default)
        Drag Points
        
    It can also hold global values for each of the above. The global values do not influence the local values, 
    except when adding a new volume to the group. When selecting between the two, the MainView will simply render 
    the appropriate image and send it to the texture. 
    
    """
    def __init__(self, 
                 group_name, 
                 default_orientation = [0, 0, 0, 0, 0, 0], 
                 default_quaternion = G.QTN_DICT[G.VIEW], 
                 default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire'],
                 default_histogram = [-0.5, 1200.5, 1, 'Linear'], # Bins min, max, step, scale
                 default_limits_origin = [-350, 350],
                 default_limits_norm = [-350, 350], 
                 default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]]):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
        
        self.volume_names = []
        self.volume_list = []
        self.group_name = group_name
        self.intensity_limits = default_limits_intensity
        self.control_list = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll', 'min_intensity', 'max_intensity', 'colormap']
        self.orientation_control_list = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll']
        self.intensity_control_list = ['min_intensity', 'max_intensity', 'colormap']
        self.histogram_control_list = ['min_value', 'max_value', 'step', 'scale']
        self.current_volume_loaded = None
        self.volume_reference_dict = {}
        
        self.orientation = OptionValue.OrientationInfo(default_orientation = default_orientation, 
                                                       default_quaternion = default_quaternion, 
                                                       default_limits_origin = default_limits_origin,
                                                       default_limits_norm = default_limits_norm)
        
        self.intensity = OptionValue.IntensityInfo(default_intensity = default_intensity, 
                                                   default_limits = default_limits_intensity)

        self.histogram = OptionValue.HistogramInfo(default_histogram = default_histogram)

    def get_volume(self, volume_name: str):
        if volume_name not in self.volume_names:
            print(f'{volume_name} not in {self.group_name}')
            return
        return getattr(self, volume_name)

    def get_volume_attribute(self, volume_name: str, attribute_name: str):
        return self.get_volume(volume_name).get_attribute(attribute_name)
    
    def set_volume_attribute(self, volume_name: str, attribute_name: str, attribute_value):
        self.get_volume(volume_name).set_attribute(attribute_name, attribute_value)

    def set_intensity_limits(self):
        for volume in self.volume_names:
            for index in [0, 1]: #[Min, Max]
                if self.intensity_limits[index][0] > self.get_volume_attribute(volume, 'intensity_limits')[index][0]:
                    self.intensity_limits[index][0] = self.get_volume_attribute(volume, 'intensity_limits')[index][0] * 1
            
                if self.intensity_limits[index][1] < self.get_volume_attribute(volume, 'intensity_limits')[index][1]:
                    self.intensity_limits[index][1] = self.get_volume_attribute(volume, 'intensity_limits')[index][1] * 1

    def set_volume(self, volumeLayer: VolumeLayer):
        if volumeLayer.name not in self.volume_names:
            print(f'Adding Volume {volumeLayer.name} to Group {self.group_name}')
            self.volume_names.append(self.volumeLayer.name)
            setattr(self, volumeLayer.name, volumeLayer)
        else:
            print(f'Volume {volumeLayer.name} already in Group {self.group_name}')

    def add_volume(self, 
                   ctvolume,
                   volume_name = None, 
                   default_orientation = [0, 0, 0, 0, 0, 0, 0], 
                   default_quaternion = G.QTN_DICT[G.VIEW], 
                   default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire'], 
                   default_histogram = [0, 1200, 1, 'Linear'], # [min, max, step, scale]
                   default_limits_origin = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER],
                   default_limits_norm = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                   default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]]): # [[min_low, min_high], [max_low, max_high]]

        temp_name = ctvolume.name if volume_name is None else volume_name
        if temp_name in self.volume_names:
            print(f'Volume {temp_name} already in Group {self.group_name}.')
            return
        
        self.volume_names.append(temp_name)

        setattr(self, temp_name, VolumeLayer(self, # This Group
                                             ctvolume,
                                             volume_name = temp_name,
                                             default_orientation = default_orientation, 
                                             default_quaternion = default_quaternion, 
                                             default_intensity = [ctvolume.rounded_min_max[0], 
                                                                  ctvolume.rounded_min_max[1], 
                                                                  G.DEFAULT_IMAGE_SETTINGS['colormap'], 
                                                                  'Fire'],
                                             default_histogram = [ctvolume.unique_values[0] - ctvolume.histogram_step/2,
                                                                  ctvolume.unique_values[-1] + ctvolume.histogram_step/2, 
                                                                  ctvolume.histogram_step, 
                                                                  'Linear'],
                                             default_limits_origin = default_limits_origin, 
                                             default_limits_norm = default_limits_norm, 
                                             default_limits_intensity = default_limits_intensity))

    def update_view(self):
        pass


    def set_current_volume(self, volume_name):
        #TODO Integrate this with MainView, start designating which volume is viewed here. 
        self.current_view_volume = self.volume_reference_dict[volume_name]


    def get_orientation_info(self, control_mode = 'Group'):
        if control_mode == 'Group':
            return self.orientation.view_plane(), self.orientation.norm_vector(), self.orientation.norm()
        
        else:
            pass
        

    def get_intensity_info(self, control_mode = 'Group'):
        pass


    def remove_volume(self, volume_name, clean_up = True):
        print(f'Removing {volume_name} from Group {self.group_name}.')
        # if volume_name == self.current_view_volume.name:
        #     pass
        # Doing this so we can simply use this function in remove_all_volumes below.
        if volume_name in self.volume_names:
            self.volume_names.remove(volume_name)

        if clean_up:
            getattr(self, volume_name)._cleanup_()

        setattr(self, volume_name, None)
        delattr(self, volume_name)

    def remove_all_volumes(self):
        while len(self.volume_names):
            volume_name = self.volume_names[-1]
            self.remove_volume(volume_name)

    def _cleanup_(self):
        self.remove_all_volumes()
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys):
            attrib_key = dict_keys[-1]
            # print(attrib_key)
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)
            dict_keys.remove(attrib_key)
                
    def reorder_volumes(self):
        pass
    

class VolumeLayerGroups(object):
    def __init__(self):
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
        self.group_names = []
        self.volume_names = {}

    def get_group(self, group_name):
        return getattr(self, group_name)
    
    def get_volume(self, group_name, volume_name):
        return self.get_group(group_name).get_volume(volume_name)
        
    def add_group(self, group_name = 'Group_1', **kwargs):
        if group_name in self.group_names:
            print(f'{group_name} already added.')
            return
        
        print(f'Adding {group_name} to groups.')
        setattr(self, group_name, VolumeLayerGroup(group_name, **kwargs))
        self.group_names.append(group_name)
        self.volume_names[group_name] = []

    def add_volume_to_group(self, 
                            group_name, 
                            ctvolume,
                            **kwargs):
        if group_name not in self.group_names:
            self.add_group(group_name = group_name)
            self.volume_names[group_name] = []

        self.get_group(group_name).add_volume(ctvolume,
                                              **kwargs)
        
        self.volume_names[group_name].append(ctvolume.name)
        
    def add_volumes_to_group(self, group_name, list_of_ctvolumes, **kwargs):
        for ctvolume in list_of_ctvolumes:
            self.add_volume_to_group(group_name, 
                                     ctvolume,
                                     **kwargs)

    def remove_group(self, group_name):
        print(f'Removing {group_name}')
        self.get_group(group_name).remove_all_volumes()
        setattr(self, group_name, None)
        delattr(self, group_name)
        self.group_names.remove(group_name)

    def remove_all_groups(self):
        while len(self.group_names):
            self.remove_group(self.group_names[-1])

    def _cleanup_(self):
        self.remove_all_groups()
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys):
            attrib_key = dict_keys.pop()
            setattr(self, attrib_key, None)
            # delattr(self, attrib_key)