import os
import sys
import cupy as cp
import numpy as np
import pandas
from copy import deepcopy
import colorcet
import matplotlib.pyplot as plt
from matplotlib import cm
from .fast_interp import interp1d, interp2d, interp3d
from cupyx.scipy.interpolate import RegularGridInterpolator, interpn
import quaternionic as qtn
import nibabel as nib
import configparser
import gdcm

# FileDialog
import datetime
from pathlib import Path
from operator import itemgetter
from contextlib import contextmanager
from typing import Generator, Union
from scipy.io import loadmat, savemat, whosmat
from scipy.io.matlab import matfile_version
import h5py

# All
import dearpygui.dearpygui as dpg

class G:
    def __init__(self):
        print('G Imported')

    APP = None
    ROOT = 'root'
    DEBUG_MODE = False
    GPU_MODE = False
    DEVICE = 0
    TEXTURE_TAG = 'main_view_texture'
    TEX_REG_TAG = 'main_texture_registry'
    COLORMAP_TAG = 'app_colormap_registry'
    VALUE_REG_TAG = 'app_value_registry'
    HANDLER_REG_TAG = 'app_mouse_handler_registry'
    ITEM_HANDLER_REG_TAG = 'app_item_handler_registry'
    LOADING_WINDOW_TAG = 'modal_loading_window'
    LOADING_WINDOW_TEXT = 'loading_window_text'
    DATA_SELECTION_WINDOW = 'data_selection_window'
    FILE_INFORMATION_WINDOW = 'file_information_window'
    FILE_INFORMATION_TABLE = 'file_information_table'
    SELECTED_ITEMS_TABLE = 'selected_items_table'
    LANDMARKS_TABLE_TAG = 'landmarks_table'
    TAB_BAR_TAG = 'view_tab_bar'
    VOLUME_TAB_TAG = 'volume_tab'
    ANALYSIS_TAB_TAG = 'analysis_tab'
    LEFT_TAB_BAR = 'left_tab_bar'
    NAVIGATION_TAB_TAG = 'navigation_tab'
    FILE_EXPLORER_TAB_TAG = 'file_explorer_tab'
    GROUP_LAYER_CONTROL_BUTTON = 'group_layer_control_button'
    GROUP_LAYER_RESET_BUTTON = 'group_layer_reset_button'
    DEFAULT_GROUP_LAYER_CONTROL = 'Group'
    MASK_TEXTURE_TAG = 'mask_texture'
    MAX_SELECTABLE_ITEMS = 100
    TEXTURE_IMAGE_TAG = 'Texture_Image'
    TEXTURE_MASK_TAG = 'Mask_Texture_Image'
    MIN_NUMBER_OF_INCREMENTS = 25
    VOLUME_FILE_DIALOG = 'MenuBar_volume_file_dialog'

    if GPU_MODE:
        cp.cuda.Device(DEVICE).use()
        print(f'GPU Mode enabled. Device: {DEVICE}, {cp.cuda.Device() = }')
    
    # Themes
    LINE_THEME = 'LINE_THEME'

    # Sliders
    ORIGIN_X_SLIDER = 'origin_x_slider'
    ORIGIN_Y_SLIDER = 'origin_y_slider'

    ### CONFIGURATION ###
    OPERATING_SYSTEM = f'{sys.platform}'

    HOME_PATH_DICT = {'win32': 'HOMEPATH',
                      'linux': 'HOME', 
                      'darwin': 'HOME'}
    
    USERHOME = Path(os.getenv(HOME_PATH_DICT[OPERATING_SYSTEM]))
    CONFIG_DIR = USERHOME.joinpath('.ct_viewer')
    CONFIG_FILE = CONFIG_DIR.joinpath('config.ini')
    CONFIG_PARSER = configparser.ConfigParser(allow_no_value=True)

    if not CONFIG_FILE.exists():
        CONFIG_DICT = {'app_settings': {'app_width': 1850,
                                        'app_height': 1050,
                                        'tab_pane_width': 1020,
                                        'tab_pane_height': 970,
                                        'main_pane_width': 1005,
                                        'main_pane_height': 930,
                                        'main_plot_width': 913,
                                        'main_plot_height': 913,
                                        'option_panel_width': 425,
                                        'option_panel_height': 483,
                                        'info_box_width': 350,
                                        'info_box_height': 970},
                        'directories': {'image_dir': str(USERHOME)},
                        'default_colors': {'default_landmark_color': (113, 237, 235, 255),
                                           'default_crosshair_color': (113, 237, 235, 125)},
                        'plot_settings': {'default_view': 'axial',
                                          'default_cmap': 'Fire'},
                        'landmark_settings': {'circle_radius': 2},
                        'gpu_settings':{'use_gpu': True, 'device': 0}
                        }
        
        print(f'Creating configuration file at {CONFIG_FILE}.')
        CONFIG_DIR.mkdir(parents = True, exist_ok = True)
        CONFIG_PARSER.read_dict(CONFIG_DICT)
        with open(str(CONFIG_FILE), 'w') as config_file:
            CONFIG_PARSER.write(config_file)

    else:
        print(f'Reading configuration file at {CONFIG_FILE}')
        CONFIG_DICT = {}
        
        CONFIG_PARSER.read(CONFIG_FILE)

        for section in CONFIG_PARSER.sections():
            config_section = CONFIG_PARSER[section]
            CONFIG_DICT[section] = {}
            print(f'[{section}]')
            for setting in config_section.keys():
                setting_value = config_section[setting]

                if section == 'app_settings':
                    setting_value = int(setting_value)

                if section == 'default_colors':
                    setting_value = tuple([int(color_ele_str.strip()) for color_ele_str in setting_value[1:-1].split(',')])
                
                CONFIG_DICT[section][setting] = setting_value
                print(f'    {setting} = {setting_value}')
    

    def save_config():
        G.CONFIG_PARSER.read_dict(G.CONFIG_DICT)
        
        with open(G.CONFIG_FILE, 'w') as config_file:
            G.CONFIG_PARSER.write(config_file)
        
        print('Configuration saved.')

    # Dictionary for resetting everything to default when closing a volume or set of volumes. 
    GLOBAL_DEFAULTS = {'TEXTURE_DIM': 0, 
                       'CURRENT_FILE': '', 
                       'FILE_LOADED': False, 
                       'VIEW': CONFIG_DICT['plot_settings']['default_view'], 
                       'VOLUME_KEYS': [], 
                       'N_VOLUMES': 0}
    
    INFORMATION_BOX = 'information_box'
    MAIN_PLOT_VIEW = 'main_plot_view'
    ANALYSIS_PLOT_VIEW = 'analysis_plot_view'
    CURRENT_TAB = 'volume_tab'
    
    TEXTURE_DIM = 0
    TEXTURE_CENTER = 0
    
    CURRENT_FILE = ''
    FILE_LOADED = False
    VIEW = 'axial'
    VOLUME_KEYS = []
    
    N_VOLUMES = 0
    
    VIEW_DICT = {'axial': 0,
                 'coronal': 1,
                 'sagittal': 2}
    
    sqrt2 = np.sqrt(2)/2

    QTN_DICT = {'axial': qtn.array([1, 0, 0, 0]),
                'coronal': qtn.array([sqrt2, 0, 0, -sqrt2]),
                'sagittal': qtn.array([sqrt2, 0, -sqrt2, 0])}
    
    ROTATION_DICT = {'initial_pitch': qtn.array([sqrt2, 0, -sqrt2, 0]), 
                     'initial_yaw':   qtn.array([sqrt2, 0, 0, -sqrt2]), 
                     'initial_roll':  qtn.array([sqrt2, sqrt2, 0, 0]), 
                     'current_pitch': qtn.array([sqrt2, 0, -sqrt2, 0]), 
                     'current_yaw':   qtn.array([sqrt2, 0, 0, -sqrt2]), 
                     'current_roll':  qtn.array([sqrt2, sqrt2, 0, 0])}
    
    # {display_name, {name: call_name, module: module, colormap: interp_cmap, colormap_r: interp_cmap_r]}
    COLORMAP_DICT = {'Fire': {'name': 'm_fire', 'module': colorcet},
                     'Gray': {'name': 'm_gray', 'module': colorcet},
                     'Jet': {'name': 'jet', 'module': cm},
                     'Viridis': {'name': 'viridis', 'module': cm},
                     'Black, Green, Yellow': {'name': 'm_kgy', 'module': colorcet},
                     'Blue, Magenta, Yellow': {'name': 'm_bmy', 'module': colorcet}, 
                     'Blues': {'name': 'm_blues', 'module': colorcet},
                     'Blue, Green, Yellow, White': {'name': 'm_bgyw', 'module': colorcet},
                     'Blue, Green, Yellow': {'name': 'm_bgy', 'module': colorcet},
                     'Blue, Black, Red': {'name': 'm_bkr', 'module': colorcet},
                     'Cool Warm': {'name': 'm_coolwarm', 'module': colorcet},
                     'Green, White, Violent': {'name': 'm_gwv', 'module': colorcet},
                     'Blue, Gray, Yellow': {'name': 'm_bjy', 'module': colorcet},
                     'Blue, White, Yellow': {'name': 'm_bwy', 'module': colorcet},
                     'Cyan, White, Red': {'name': 'm_cwr', 'module': colorcet},
                     'Rainbow': {'name': 'm_rainbow', 'module': colorcet},
                     'Colorwheel': {'name': 'm_colorwheel', 'module': colorcet}}
    
    COLORMAP_SCALES = ['Linear',
                       'Absolute',
                       'Log']

    def initialize_rgba_interp(colormap_module, colormap_name):

        print(f'Loading {colormap_name}, {type(getattr(colormap_module, colormap_name))}')
        
        start = 0
        stop = 1
        step = 1/255
        order = 1

        if G.GPU_MODE:
            
            # color_rgba needs to be a list here due to RegularGridInterpolator
            color_rgba = cp.array([getattr(colormap_module, colormap_name)(list(range(256)))])
            # print(f'{color_rgba.shape = }, {color_rgba[:,:,0].T.shape = }, {color_rgba[:,:,0].flatten().shape = }')
            red_interp = RegularGridInterpolator((cp.linspace(0, 1, 256),), color_rgba[:,:,0].flatten(), bounds_error = False, fill_value = None) # (256,)
            green_interp = RegularGridInterpolator((cp.linspace(0, 1, 256),), color_rgba[:,:,1].flatten(), bounds_error = False, fill_value = None)
            blue_interp = RegularGridInterpolator((cp.linspace(0, 1, 256),), color_rgba[:,:,2].flatten(), bounds_error = False, fill_value = None)

            # interp_test = cp.linspace(0, 0.85, 100)
            # print(f'{interp_test.shape = }')
            # print(f'{red_interp(interp_test.T).shape = }, {interp_test.shape = }')

        else:
            color_rgba = getattr(colormap_module, colormap_name)(list(range(256)))
            red_interp = interp1d(start, stop, step, color_rgba[:,0], k = order)
            green_interp = interp1d(start, stop, step, color_rgba[:,1], k = order)
            blue_interp = interp1d(start, stop, step, color_rgba[:,2], k = order)

        return [red_interp, green_interp, blue_interp]
    
    def initialize_colormaps():

        for cmap_key in list(G.COLORMAP_DICT.keys()): # eg: Fire

            cmap_name = f'{G.COLORMAP_DICT[cmap_key]["name"]}' # eg: m_fire
            cmap_name_r = f'{cmap_name}_r'
            
            # G.COLORMAP_DICT[cmap_key][2] is the module the colormap lives in. 
            G.COLORMAP_DICT[cmap_key][f'colormap'] = G.initialize_rgba_interp(G.COLORMAP_DICT[cmap_key]['module'], cmap_name)
            G.COLORMAP_DICT[cmap_key][f'colormap_r'] = G.initialize_rgba_interp(G.COLORMAP_DICT[cmap_key]['module'], cmap_name_r)
        
        default_cmap = G.CONFIG_DICT['plot_settings']['default_cmap']
        
        # Need to set this here so that we call initialize_colormaps first, which is gone in ct_viewer.py
        G.DEFAULT_IMAGE_SETTINGS = {'colormap_combo': default_cmap,
                                    'colormap_scale': f'colormap_{G.COLORMAP_DICT[default_cmap]["name"]}',
                                    'colormap': G.COLORMAP_DICT[default_cmap]['colormap'],
                                    'view': G.CONFIG_DICT['plot_settings']['default_view'],
                                    'min_value': 0,
                                    'max_value': 1200,
                                    'image_size_multiplier': 1}
        
        print(f'Default colormap set to {default_cmap}.')


    # ['Linear', 'Nearest Neighbor', 'Spline Linear', 'Cubic', 'Quintic', 'PCHIP']
    INTERPOLATION_OPTIONS = ['Linear', 'Nearest Neighbor']# 'Spline Linear', 'Cubic', 'Quintic', 'PCHIP']
    INTERPOLATION_DICT = {'Linear': 'linear',
                          'Nearest Neighbor': 'nearest'}
    
    # INTERPOLATION_DICT = {'Linear': 'linear',
    #                       'Nearest Neighbor': 'nearest', 
    #                       'Spline Linear': 'splinear', 
    #                       'Cubic': 'cubic', 
    #                       'Quintic': 'quintic',
    #                       'PCHIP': 'pchip'}


    OPTION_TAG_DICT = {'img_index': 'img_index_slider', 
                       'origin_x': 'origin_x_slider', 
                       'origin_y': 'origin_y_slider', 
                       'norm': 'norm_slider', 
                       'pitch': 'pitch_slider', 
                       'yaw': 'yaw_slider',
                       'roll': 'roll_slider',
                       'min_intensity': 'min_intensity_slider', 
                       'max_intensity': 'max_intensity_slider', 
                       'colormap': 'colormap_combo'}
    
    
    OPTIONS_DICT = {'img_index_slider': {}, 
                    'origin_x_slider': {},
                    'origin_y_slider': {},
                    'norm_slider': {}, 
                    'pitch_slider': {}, 
                    'yaw_slider': {}, 
                    'roll_slider': {}, 
                    'min_intensity_slider': {}, 
                    'max_intensity_slider': {}}
    
    
    OPTIONS_INFO = {'label': ['Image Number  ', 'Origin X      ', 'Origin Y      ', 'Slice Location', 'Pitch Angle   ', 'Yaw Angle     ', 'Roll Angle    ',
                              'Min Intensity ', 'Max Intensity '], 
                    'default_value': [1, 0, 0, 0, 0, 0, 0, 0, 1200], 
                    'previous_value': [1, 0, 0, 0, 0, 0, 0, 0, 1200],
                    'current_value': [1, 0, 0, 0, 0, 0, 0, 0, 1200],
                    'difference_value': [0, 0, 0, 0, 0, 0, 0, 0, 0],
                    'min_value': [1, -400, -400, -400, -180, -180, -180, -1e6, -1e6 + 1],
                    'max_value': [1, 400, 400, 400, 180, 180, 180, 1e6 - 1, 1e6],
                    'group_tag': ['img_index_slider_group', 'origin_x_slider_group', 'origin_y_slider_group','norm_slider_group', 
                                 'pitch_slider_group', 'yaw_slider_group', 'roll_slider_group', 'min_intensity_slider_group', 'max_intensity_slider_group'],
                    'label_tag': ['img_index_slider_label', 'origin_x_slider_label', 'origin_y_slider_label', 'norm_slider_label', 
                                 'pitch_slider_label', 'yaw_slider_label', 'roll_slider_label', 'min_intensity_slider_label', 'max_intensity_slider_label'],
                    'slider_tag': ['img_index_slider', 'origin_x_slider', 'origin_y_slider', 'norm_slider', 
                                  'pitch_slider', 'yaw_slider', 'roll_slider', 'min_intensity_slider', 'max_intensity_slider']}
    
    for option_index, option_key in enumerate(OPTIONS_DICT.keys()):
        for info_key in OPTIONS_INFO.keys():
            
            OPTIONS_DICT[option_key][info_key] = OPTIONS_INFO[info_key][option_index]
            
    ORIENTATION_OPTIONS = ['origin_x_slider',
                           'origin_y_slider',
                           'norm_slider', 
                           'pitch_slider', 
                           'yaw_slider', 
                           'roll_slider']
                           
    OPTION_TAGS = ['img_index_slider', 
                   'origin_x_slider',
                   'origin_y_slider',
                   'norm_slider', 
                   'pitch_slider', 
                   'yaw_slider', 
                   'roll_slider', 
                   'min_intensity_slider', 
                   'max_intensity_slider', 
                   'orientation_group_layer_control_button', 
                   'orientation_group_layer_reset_button',
                   'intensity_group_layer_control_button', 
                   'colormap_combo', 
                   'colormap_scale_combo',
                   'mask_combo',
                   'enable_mask_checkbox',
                   'mask_opacity_slider',
                   'mask_color_picker',
                   'reverse_colormap_checkbox',
                   'interpolation_combo_box',
                   'mask_exclude_low_float',
                   'enable_mask_low_exclude_checkbox',
                   'mask_exclude_high_float',
                   'enable_mask_high_exclude_checkbox']
    
    IMAGE_TOOL_TAGS = ['add_drag_point_button']
    
    MASK_DICT = {'Air': 0,
                 'Body': 1,
                 'Bones': 2,
                 'Spine': 3,
                 'Ribs': 4,
                 'Lungs, Vasculature, Trachea': 5,
                 'Left Vasculature': 6,
                 'Right Vasculature': 7, 
                 'Lungs, Trachea': 8,
                 'Trachea': 9, 
                 'Lungs': 10,
                 'Left Lung': 11,
                 'Right Lung': 12}
    
    DEBUG_INFO_TAGS = ['current_volume',
                       'current_group_info',
                       'current_volume_info',
                       'current_volume_name',
                       'current_group_name',
                       'current_volume_index',
                       'initial_origin_vector',
                       'initial_norm_vector',
                       'initial_quaternion',
                       'current_origin_vector',
                       'current_norm_vector',
                       'current_quaternion',
                       'current_view_slice']