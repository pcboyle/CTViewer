from .Globals import *

class MenuBar:
    def __init__(self):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        with dpg.menu_bar(tag = 'MenuBar'):
            with dpg.menu(label = 'File', tag = 'MenuBarFile'):
                dpg.add_menu_item(label = 'Open Volumes', tag = 'MenuBarFile_open', callback = self.open_files)
                dpg.add_menu_item(label = 'Add Volumes', tag = 'MenuBarFile_add_volume', callback = self.open_files)
                dpg.add_menu_item(label = 'Close All', tag = 'MenuBarFile_close', callback = self.close_all)
                
            with dpg.menu(label = 'Layers', tag = 'MenuBarLayers'):
                dpg.add_menu_item(label = 'New Group', tag = 'MenuBarLayers_create_new_group', callback = self.create_new_group)
            
            with dpg.menu(label = 'Analysis', tag = 'MenuBarAnalysis'):
                dpg.add_menu_item(label = 'Open Analysis Window', tag = 'MenuBarAnalysis_open_analysis_window', callback = self.open_analysis_window)

            with dpg.menu(label = 'Settings', tag = 'MenuBarSettings'):
                dpg.add_menu_item(label='Configuration', tag = 'MenuBarSettings_open_config_menu', callback = self.open_configuration)

        # with dpg.file_dialog(file_count = 15,
        #                      tag = G.VOLUME_FILE_DIALOG, 
        #                      height = 500, width = 800, 
        #                      show = False,
        #                      default_path = G.CONFIG_DICT['directories']['image_dir'],
        #                      callback = self.read_file, 
        #                      cancel_callback = self.cancel_read):
        #     dpg.add_file_extension(".*")
        #     dpg.add_file_extension("Image Files (.mat, .h5, .nii){.mat,.h5,.nii}")
    
    def open_files(self, sender, app_data):
        G.APP.FileDialog.show()

    def close_all(self):
        print('Closing All Volumes')
        print(f'{G.FILE_LOADED = }')
        if G.FILE_LOADED:
            dpg.set_value('InfoBoxTab_layers_text', '')
            
            G.APP.main_view.close_image()
            G.APP.info_box.close_image()
            G.APP.options_panel.disable_options()
            G.APP.image_tools.disable_options()
            dpg.configure_item('save_landmarks_button', enabled = False)

            G.APP.VolumeLayerGroups.remove_all_groups()
            G.APP.Volumes.clear()
        
            setattr(self, 'VOLUME_LOADED', False)
            for GLOBAL_KEY in G.GLOBAL_DEFAULTS.keys():
                setattr(G, GLOBAL_KEY, G.GLOBAL_DEFAULTS[GLOBAL_KEY])
        
            print(f'{G.FILE_LOADED}, False')
            cp.get_default_memory_pool().free_all_blocks()
            cp.get_default_pinned_memory_pool().free_all_blocks()
            print(f'{G.FILE_LOADED = }')
    
    def create_new_group(self):
        pass
    
    def open_analysis_window(self):
        if G.FILE_LOADED:
            pass
            
        else:
            pass
        

    def open_configuration(self):

        pass
    
    def _cleanup_(self):
        pass