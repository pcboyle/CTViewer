class CTViewer:
    # Main window chosen in ct_viewer.py, which contains the main() class. 
    def __init__(self, main_window):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        from . import MenuBar
        from . import CTVolume
        from . import OptionsPanel
        # from . import OptionValue
        from . import MainView
        from . import AnalysisView
        from . import FileDialog
        from . import FileIO
        from . import InformationBox
        from . import VolumeLayer
        from . import ImageTools
        from . import Themes

        # Set this instance as the ct_viewer. 
        print('Initialized')
        G.APP = self
        self.FileIO = FileIO.FileIO()

        self.Volumes = []
        self.VolumeLayerGroups = VolumeLayer.VolumeLayerGroups()
        
        self.texture_registry = dpg.add_texture_registry(tag = G.TEX_REG_TAG) # 'main_texture_registry'
        self.colormap_registry = dpg.add_colormap_registry(tag = G.COLORMAP_TAG)
        self.value_registry = dpg.add_value_registry(tag = G.VALUE_REG_TAG)
        self.handler_registry = dpg.add_handler_registry(tag = G.HANDLER_REG_TAG)
        self.item_handler_registry = dpg.add_item_handler_registry(tag = G.ITEM_HANDLER_REG_TAG)
        self.themes = Themes.Themes()
        
        self.FileDialog = FileDialog.FileDialog(G.CONFIG_DICT['directories']['image_dir'], parent = G.APP,
                                                debug = False, show = False)

        # Set up slider value registry. This is used with the mouse wheel which can otherwise extend past the 
        # slider limits. 
        for option_key in G.OPTIONS_DICT.keys():
            slider_tag = G.OPTIONS_DICT[option_key]['slider_tag']
            slider_value = G.OPTIONS_DICT[option_key]['default_value']
            dpg.add_int_value(tag = f'{slider_tag}_current_value', default_value = slider_value, parent = G.VALUE_REG_TAG)
        
        # Load up interpolators.
        CTVolume._initialize_interps()
        
        with main_window:
            self.menu_bar = MenuBar.MenuBar()
            with dpg.group(horizontal = True):
                with dpg.child_window(width = 440, height = 970,
                                      border = True):
                    with dpg.tab_bar(tag = G.LEFT_TAB_BAR, callback = self.print_current_tab):
                        with dpg.tab(label = 'Navigation', tag = G.NAVIGATION_TAB_TAG):
                            with dpg.group():
                                self.options_panel = OptionsPanel.OptionsPanel()
                                self.image_tools = ImageTools.ImageTools()
                        # with dpg.tab(label = 'File Explorer', tag = G.FILE_EXPLORER_TAB_TAG):
                        #     self.file_explorer = FileExplorer.FileExplorer()
                with dpg.child_window(width = G.CONFIG_DICT['app_settings']['tab_pane_width'], #G.MAIN_TAB_VIEW_WINDOW_DEFAULTS['WINDOW_WIDTH'],
                                      height = G.CONFIG_DICT['app_settings']['tab_pane_height'], #G.MAIN_TAB_VIEW_WINDOW_DEFAULTS['WINDOW_HEIGHT'],
                                      border = True):
                    with dpg.tab_bar(tag = G.TAB_BAR_TAG, callback = self.print_current_tab):
                        with dpg.tab(label = 'Volume Tab', tag = G.VOLUME_TAB_TAG):
                            self.main_view = MainView.MainView()
                        with dpg.tab(label = 'Analysis Tab', tag = G.ANALYSIS_TAB_TAG):
                            self.analysis_view = AnalysisView.AnalysisView()
                
                self.info_box = InformationBox.InformationBox()
                
        self.FileDialog.initialize(debug = G.DEBUG_MODE)

    def print_current_tab(self, sender, app_data):
        print('Tab clicked!')
        print('Sender: ', sender)
        print('App Data: ', app_data)

    def _cleanup_(self):
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys) > 0:
            attrib_key = dict_keys.pop()
            try: 
                getattr(self, attrib_key)._cleanup_()
            except:
                pass
            finally:
                setattr(self, attrib_key, None)
                delattr(self, attrib_key)
        
from .Globals import *