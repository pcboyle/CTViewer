from .Globals import *

if G.GPU_MODE:
    cp.cuda.Device(G.DEVICE).use()

class Landmarks(object):
    mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
    mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: np.array(x)
    mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
    mode_value = lambda x: getattr(cp, x.__str__()) if G.GPU_MODE else getattr(np, x.__str__())
    cp_to_np = lambda x: cp.asnumpy(x) if G.GPU_MODE else lambda x: x
    np_to_cp = lambda x: cp.asarray(x) if G.GPU_MODE else lambda x: x

    def __init__(self, parent_volume, max_landmarks = 2**16):
        self.parent_volume = parent_volume, 
        self.max_landmarks = max_landmarks

        self.landmark_image_coords = Landmarks.mode_function(np.zeros)((self.max_landmarks, 3), dtype = np.float32) #(x, y, z)
        self.landmark_viewport_coords = Landmarks.mode_function(np.zeros)((self.max_landmarks, 3), dtype = np.float32) #(x, y, z)
        self.landmark_viewport_locs = Landmarks.mode_function(np.zeros)((self.max_landmarks, 2), dtype = np.float32) #(x, y)
        self.landmark_sizes = Landmarks.mode_function(np.zeros)(self.max_landmarks, dtype = np.float32)
        self.landmark_rgba = Landmarks.mode_function(np.zeros)((self.max_landmarks, 4), dtype = np.float32) #(r, g, b, a)
        self.landmark_show = Landmarks.mode_function(np.zeros)(self.max_landmarks, dtype = np.int8) #(true, false)
        self.landmark_dict = {} # {landmark_circle_dpg_id: array_index}

        self.landmark_index = int(0)
        self.number_of_landmarks = int(0)
        self.number_of_landmarks_visible = int(0)

    def add_landmark(self, 
                     image_coords, 
                     viewport_coords = None,
                     viewport_loc = None,
                     color = dpg.get_value('landmark_color_picker'),
                     size = 2, 
                     show_landmark = True,
                     parent = G.MAIN_PLOT_VIEW,
                     option = 'spacebar'):
        """
        image_coords: 
            [x, y, z, hu]

        color:
            [r, g, b, a]

        size: float

        """
        if option == 'mouse':
            image_coords = G.APP.main_view.mouse_position_information[:4] # [x, y, z, hu] in the image coordinates
            landmark_point_viewport = G.APP.main_view.mouse_position_information[4:6] # Position on screen
            landmark_point_view = G.APP.main_view.mouse_position_information[6:9] # [x, y, z] in the viewport coordinates. 
            landmark_quaternion = G.APP.main_view.mouse_position_information[9] # 
            landmark_view = G.APP.main_view.mouse_position_information[-1] # 11 x 11 array of the view when we captured this point. 

        elif option == 'spacebar':
            image_coords = G.APP.main_view.crosshair_position_information[:4] # [x, y, z, hu] in the image coordinates
            landmark_point_viewport = G.APP.main_view.crosshair_position_information[4:6] # Always [0, 0] since the crosshair defines that location.
            landmark_point_view = G.APP.main_view.crosshair_position_information[6:9] # [x, y, z] in the viewport coordinates. 
            landmark_quaternion = G.APP.main_view.crosshair_position_information[9]
            landmark_view = G.APP.main_view.crosshair_position_information[-1] # 11 x 11 array of the view when we captured this point. 

        elif option == 'file':
            image_coords = image_coords #  [x, y, z, hu] in the image coordinates
            landmark_quaternion = G.QTN_DICT[G.VIEW]
            image_coords[:3] = landmark_quaternion.rotate(image_coords[:3])
            landmark_point_viewport = [0.0, 0.0] # Always [0, 0] since the crosshair defines that location.
            landmark_point_view = np.array([image_coords[0] - self.parent_volume.ctvolume.volume_center.get()[0].item(), 
                                            image_coords[1] - self.parent_volume.ctvolume.volume_center.get()[1].item(), 
                                            image_coords[2] - self.parent_volume.ctvolume.volume_center.get()[2].item()]) + 0 # [x, y, z] in the viewport coordinates. 
            landmark_view = np.zeros((11, 11)) # 11 x 11 array of the view when we captured this point. 

        if type(viewport_coords) == type(None):
            viewport_coords = image_coords - G.TEXTURE_CENTER + 0
        # (parallel_dist, parallel_proj, orthogonal_proj, point_proj_plane, viewport_x, viewport_y)
        landmark_projection_info = self.parent_volume.orientation.calculate_point_projection_on_viewplane(viewport_coords)

        if type(viewport_loc) == type(None):
            viewport_loc = landmark_projection_info[4:]

        alpha_fade = (2.0 / size)
        color[-1] = 255.0 * np.exp(-alpha_fade * landmark_projection_info[0] / np.round(dpg.get_value('landmark_opacity_factor_input'), decimals = 1) + 0)

        self.landmark_image_coords[self.landmark_index] = image_coords
        self.landmark_viewport_coords[self.landmark_index] = viewport_coords
        self.landmark_rgba[self.landmark_index] = color
        self.landmark_sizes[self.landmark_index] = 1*size
        self.landmark_show[self.landmark_index] = Landmarks.mode_value(int(show_landmark))
        self.landmark_viewport_locs[self.landmark_index] = [viewport_loc[0], viewport_loc[1]]

        dpg.draw_circle(self.landmark_viewport_locs[self.landmark_index],
                        radius = self.landmark_sizes[self.landmark_index],
                        show = self.landmark_show[self.landmark_index],
                        color = self.landmark_rgba[self.landmark_index],
                        parent = parent)
        
        self.landmark_dict[dpg.last_item()] = int(1*self.landmark_index)

        self.landmark_index += 1
        self.number_of_landmarks += 1
        self.number_of_landmarks_visible = Landmarks.mode_function(np.sum)(self.landmark_show)

    def update_landmarks(self):
        landmark_projection_info = self.parent_volume.orientation.calculate_point_projection_on_viewplane(self.landmark_viewport_coords)
        self.landmark_rgba[:,3] = self.calculate_landmark_fade(landmark_projection_info[0])
        self.landmark_viewport_locs[:,0] = landmark_projection_info[4]
        self.landmark_viewport_locs[:,1] = landmark_projection_info[5]

        del landmark_projection_info

    def calculate_landmark_fade(self, landmark_distance):
        return 255.0 * Landmarks.mode_function(np.exp)(-(2.0 / self.landmark_sizes) * landmark_distance / Landmarks.mode_function(np.round)(dpg.get_value('landmark_opacity_factor_input'), decimals = 1) + 0)

    def set_landmark_opacity(self, view_plane, override = None, override_value = 0):

        if type(override) != type(None):
            self.landmark_rgba[:,3] *= override_value

    def delete_landmark(self, ):
        pass