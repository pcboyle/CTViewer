from .Globals import *

class AnalysisView:
    def __init__(self):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.plot_x_axis = 'analysis_view_plot_x_axis'
        self.plot_y_axis = 'analysis_view_plot_y_axis'
        self.colormap_scale = 'analysis_view_colormap_scale'
        self.mouse_hover_handler = 'analysis_view_mouse_hover_handler'
        self.information_box = 'analysis_view_information_box'
        self.mouse_position_text = 'analysis_view_mouse_position_text'


        with dpg.group(horizontal = True):
            with dpg.child_window(width = G.CONFIG_DICT['app_settings']['main_pane_width'], # G.MAIN_PLOT_VIEW_WINDOW_DEFAULTS['WINDOW_WIDTH'], 
                                  height =G.CONFIG_DICT['app_settings']['main_pane_height']): # G.MAIN_PLOT_VIEW_WINDOW_DEFAULTS['WINDOW_HEIGHT']
                with dpg.group(horizontal = True):
                    with dpg.plot(label = '', tag = G.ANALYSIS_PLOT_VIEW, equal_aspects = True,
                                  # width = G.MAIN_PLOT_VIEW_WINDOW_DEFAULTS['PLOT_WIDTH'], height = G.MAIN_PLOT_VIEW_WINDOW_DEFAULTS['PLOT_HEIGHT']
                                  width = G.CONFIG_DICT['app_settings']['main_plot_width'], height = G.CONFIG_DICT['app_settings']['main_plot_width']
                                ):
                        dpg.add_plot_axis(dpg.mvXAxis, tag=self.plot_x_axis, 
                                              no_gridlines = True, no_tick_marks = True, no_tick_labels = True)
                        dpg.add_plot_axis(dpg.mvYAxis, tag=self.plot_y_axis,
                                              no_gridlines = True, no_tick_marks = True, no_tick_labels = True)
                    
                    dpg.add_colormap_scale(min_scale=0, max_scale=1200, width=65, height=-1, tag = self.colormap_scale, colormap='colormap_m_fire')


    def initialize_view(self):
        self.colormap = G.DEFAULT_IMAGE_SETTINGS['colormap']
        self.default_orientation = G.DEFAULT_IMAGE_SETTINGS['view'] # axial, coronal, sagittal
        
        self.min_value = self.current_volume_info.intensity.min_intensity.default_value
        self.max_value = self.current_volume_info.intensity.max_intensity.default_value
        
        # view_plane is the texture plane, not the interpolated location plane. 
        self.view_plane_shape = (G.TEXTURE_DIM, G.TEXTURE_DIM)

        if G.GPU_MODE:
            self.interp_gpu = cp.zeros(G.TEXTURE_DIM*G.TEXTURE_DIM)

        self.windowed_view = np.zeros(self.view_plane_shape)
        self.current_view = np.zeros(self.view_plane_shape)

        self.current_norm_vector = self.initial_quaternion.rotate(self.initial_norm_vector, axis = 0)
        
        return
    

    def initialize_volume_texture(self):
        
        print(G.TEXTURE_DIM, G.TEXTURE_DIM**2)
        
        self.texture = np.zeros(G.TEXTURE_DIM * G.TEXTURE_DIM * 4, dtype = np.float32)
        self.texture_red = np.zeros(G.APP.main_view.view_plane_shape, dtype = np.float32)
        self.texture_green = np.zeros(G.APP.main_view.view_plane_shape, dtype = np.float32)
        self.texture_blue = np.zeros(G.APP.main_view.view_plane_shape, dtype = np.float32)
        self.texture_alpha = np.zeros(G.APP.main_view.view_plane_shape, dtype = np.float32)
        
        self.alpha_mask = np.zeros(G.TEXTURE_DIM * G.TEXTURE_DIM, dtype = bool)

        return


    def update_alpha_mask(self):
         # self.alpha_mask is a boolean array
        self.alpha_mask = (self.current_view_plane >= -1.0*self.current_volume.volume_center) & (self.current_view_plane < 1.0*self.current_volume.volume_center)
        self.alpha_mask = np.sum(self.alpha_mask, axis = 0) == 3


    def calculate_sum_view(self):
        n_slices = 5 # including current location

        current_view_plane = 1.0*G.APP.main_view.current_view_plane
        current_norm_vector = 1.0*G.APP.main_view.current_norm_vector

        self.current_view[:] = 1.0*G.APP.main_view.current_view[:]

        for n_slice in range(1, n_slices):
            view_plane = current_view_plane + n_slice*current_norm_vector
            slice_alpha = (view_plane >= -1.0*G.APP.main_view.current_volume.volume_center) & (view_plane < 1.0*G.APP.main_view.current_volume.volume_center)
            slice_alpha = np.sum(slice_alpha, axis = 0) == 3
            self.current_view[slice_alpha.reshape(self.view_plane_shape)] += self.interpolate_view(view_plane, slice_alpha)

        self.current_view /= n_slices

        pass


    def interpolate_view(self, view_plane, slice_alpha):
        
        if G.GPU_MODE:
            self.interp_gpu[:] = getattr(G.APP.main_view.current_volume, 'interpolator')(view_plane.T)[:]
            return self.interp_gpu.get().reshape(self.view_plane_shape)[slice_alpha.reshape(self.view_plane_shape)]
            
        else:
            return getattr(G.APP.main_view.current_volume, 'interpolator')(view_plane[0][slice_alpha],
                                                                           view_plane[1][slice_alpha],
                                                                           view_plane[2][slice_alpha])
        
        return


    def window_and_normalize_image(self):
        
        self.windowed_view = (self.current_view - self.min_value)/(self.max_value - self.min_value)
        
        return
    

    def interpolate_rgba_view(self):

        self.red_interp, self.green_interp, self.blue_interp = G.APP.main_view.current_volume_info.intensity.colormap

        flat_normalized_view = self.windowed_view.flatten()
        
        self.texture_red[:] = self.red_interp(flat_normalized_view).reshape(self.view_plane_shape)[:]
        self.texture_green[:] = self.green_interp(flat_normalized_view).reshape(self.view_plane_shape)[:]
        self.texture_blue[:] = self.blue_interp(flat_normalized_view).reshape(self.view_plane_shape)[:]
        self.texture_alpha[:] = self.alpha_mask.reshape(self.view_plane_shape)[:]
        
        for index, rgba in enumerate([self.texture_red, self.texture_green, self.texture_blue, self.texture_alpha]):
            self.texture[index::4] = rgba.flatten()


    def _cleanup_(self):
        pass
    