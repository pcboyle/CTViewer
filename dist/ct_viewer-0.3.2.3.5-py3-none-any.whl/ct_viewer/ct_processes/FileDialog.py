from .Globals import *
from . import CTVolume

INDENT_STEP = 14    # actually depends on font size

def on_row_clicked(sender, value, user_data, selected_leaves:list = None):
    # Make sure it happens quickly and without flickering
    with dpg.mutex():
        table, row, leaf = user_data
        root_level, node, node_label = dpg.get_item_user_data(row)
        # Get selected data and add it to the table's user data. 
        if leaf:

            if type(selected_leaves) == type(None):
                current_indent, selected_leaves = dpg.get_item_user_data(table)

            else:
                selected_leaves = []
                current_indent = 0

            if value:
                selected_leaves.append(row)
            else:
                try:
                    selected_leaves.remove(row)
                except:
                    pass
            
            dpg.set_item_user_data(table, [current_indent, selected_leaves])

            print('FileDialog Message: Selected leaves:')
            for row_leaf in selected_leaves:
                print(f'FileDialog Message: \t{row_leaf}, {dpg.get_item_user_data(dpg.get_item_user_data(row_leaf)[1])[0]}')

            return

        # We don't want to highlight the selectable as "selected"
        dpg.set_value(sender, False)
        root_level, node, node_label = dpg.get_item_user_data(row)

        # First of all let's toggle the node's "expanded" status
        is_expanded = not dpg.get_value(node)
        dpg.set_value(node, is_expanded)
        # All children *beyond* this level (but not on this level) will be hidden
        hide_level = 10000 if is_expanded else root_level

        # Now manage the visibility of all the children as necessary
        rows = dpg.get_item_children(table, slot=1)
        root_idx = rows.index(row)
        # We don't want to look at rows preceding our current "root" node
        rows = rows[root_idx + 1:]
        for child_row in rows:
            child_level, child_node, child_label = dpg.get_item_user_data(child_row)
            if child_level <= root_level:
                break
            if child_level > hide_level:
                dpg.hide_item(child_row)
            else:
                dpg.show_item(child_row)
                hide_level = 10000 if dpg.get_value(child_node) else child_level


def delete_node(parent_table, parent_row):
    with dpg.mutex():
        root_level, node, node_label = dpg.get_item_user_data(parent_row)
        print(f'FileDialog Message: Deleting {parent_row}')

        rows = dpg.get_item_children(parent_table, slot = 1)
        root_idx = rows.index(parent_row)

        rows = rows[root_idx + 1:]
        for child_row in rows:
            child_level, child_node, child_label = dpg.get_item_user_data(child_row)
            if child_level <= root_level:
                break
            else:
                dpg.delete_item(child_row)
                current_indent, selected_leaves = dpg.get_item_user_data(parent_table)
                try:
                    selected_leaves.remove(child_row)
                except:
                    pass
                dpg.set_item_user_data(parent_table, [current_indent, selected_leaves])


        dpg.delete_item(parent_row)


def toggle_node(parent_table, parent_row):
    with dpg.mutex():
        root_level, node, node_label = dpg.get_item_user_data(parent_row)

        is_expanded = not dpg.get_value(node)
        dpg.set_value(node, is_expanded)

        hide_level = 10000 if is_expanded else root_level

        rows = dpg.get_item_children(parent_table, slot=1)
        root_idx = rows.index(parent_row)

        rows = rows[root_idx + 1:]
        for child_row in rows:
            child_level, child_node, child_label = dpg.get_item_user_data(child_row)
            if child_level <= root_level:
                break
            if child_level > hide_level:
                dpg.hide_item(child_row)
            else:
                dpg.show_item(child_row)
                hide_level = 10000 if dpg.get_value(child_node) else child_level

@contextmanager
def table_tree_node(*cells: str, leaf: bool = False, 
                    tag: int|str = None, parent_table: int|str = None, node_user_data = None,
                    add_popup: bool = False) -> Generator[Union[int, str], None, None]:
    if type(parent_table) == type(None):
        parent_table = dpg.top_container_stack()
    current_indent_level, current_selected_list = dpg.get_item_user_data(parent_table) or [0, []]
    node = dpg.generate_uuid() if type(tag) == type(None) else tag
    
    with dpg.table_row(user_data=(current_indent_level, node, cells[0]), parent = parent_table) as row:
        with dpg.group(horizontal=True, horizontal_spacing=0):
            dpg.add_selectable(span_columns=True, callback=on_row_clicked, user_data=(parent_table, row, leaf))
            if add_popup:
                with dpg.popup(dpg.last_item()):
                    dpg.add_text(f'Popup on row {row}.')
            dpg.add_tree_node(
                    tag=node,
                    label=cells[0],
                    indent=current_indent_level*INDENT_STEP,
                    leaf=leaf,
                    bullet=leaf,
                    default_open=True,
                    user_data = node_user_data
                    )

        for label in cells[1:]:
            dpg.add_text(label)

    try:
        dpg.set_item_user_data(parent_table, [current_indent_level + 1, current_selected_list])
        # print(f'FileDialog Message: {"\t"*(cur_level + 1)}Try    : User Data for {parent_table}-{cells[0]}: {cur_level + 1}')
        yield node, row, cells[0]

    finally:
        dpg.set_item_user_data(parent_table, [current_indent_level, current_selected_list])
        # print(f'FileDialog Message: {"\t"*cur_level}Finally: User Data for {parent_table}-{cells[0]}: {cur_level}')


def add_table_tree_leaf(*cells: str, parent_table: int|str = None, tag: int|str = None, node_user_data = None) -> Union[int, str]:
    with table_tree_node(*cells, leaf = True, parent_table = parent_table, tag = tag, node_user_data = node_user_data) as node:
        pass
    return node


def create_tree_node(node_dict:dict, parent_table: int|str = None, tag: int|str = None, 
                     row_list = [], add_popup = False, node_user_data:list = ['', dict()]):
    """
    Expects a dictionary of form: 

    {'Name': name,
     'Type': 'Node'|'Leaf', 'Group'|'Dataset',
     'Data': {'Data_key_1': {'Name': name,
                             'Type': 'Node'|'Leaf', 'Group'|'Dataset',
                             'Data': ...,
                             'Attributes': ...}}}
    """
     # t_node = (node, row, cells[0])
    if node_dict['Type'] in ['Node','Group']:
        if node_user_data[0] == '':
            node_user_data = [f'{node_dict['Name']}', node_dict['Attributes']]
        else:
            node_user_data = [f'{node_user_data[0]}|{node_dict['Name']}', node_dict['Attributes']]
        with table_tree_node(node_dict['Name'], '', '', parent_table = parent_table, add_popup = add_popup) as t_node:
            for node_data in node_dict['Data'].values():
                create_tree_node(node_data, parent_table = parent_table, row_list = row_list, add_popup = add_popup, node_user_data = node_user_data)
        toggle_node(parent_table, t_node[1])
        node_dict['Row'] = t_node[1]

    elif node_dict['Type'] in ['Leaf','Dataset']:
        node_user_data = [f'{node_user_data[0]}|{node_dict['Name']}', node_dict['Attributes']]
        t_node = add_table_tree_leaf(node_dict['Name'], 
                                     f'{node_dict['Attributes']['shape']}', 
                                     f'{node_dict['Attributes']['dtype']}',
                                     parent_table = parent_table,
                                     node_user_data = node_user_data)
        row_list.append(t_node[1])
        node_dict['Row'] = t_node[1]

    else:
        print(f'FileDialog Message: Unknown object type {node_dict["Type"]}')

    return row_list

class FileDialog(object):
    
    size_string_dict = {0.0: 'B',
                        1.0: 'B',
                        2.0: 'B',
                        3.0: 'KB',
                        4.0: 'KB',
                        5.0: 'KB',
                        6.0: 'MB',
                        7.0: 'MB',
                        8.0: 'MB',
                        9.0: 'GB',
                        10.0: 'GB',
                        11.0: 'GB',
                        12.0: 'TB',
                        13.0: 'TB',
                        14.0: 'TB'}

    file_type_dict = {'.txt': 'Text File',
                      '.py': 'Python Source File',
                      '.mat': 'Matlab File',
                      '.h5': 'HDF5 File', 
                      '.hdf5': 'HDF5 File',
                      '.nii': 'Nifti File',
                      '.nii.gz': 'gzipped Nifti File'}
    
    matfile_version_dict = {'(0, 0)': ['v4', 'mat'],
                            '(1, 0)': ['v5', 'mat'],
                            '(2, 0)': ['v7.3', 'hdf5']}
    
    file_info_formatter = {'File': lambda x: x.as_posix(),
                           'Parent': lambda x: x.as_posix(),
                           'Grandparent': lambda x: x.as_posix(),
                           'Relative Path': lambda x: x.as_posix(),
                           'Permissions': lambda x: oct(x)[2:],
                           'Size': lambda x: FileDialog.format_file_size(x), 
                           'Last Accessed': lambda x: f'{x[1]}',
                           'Last Modified': lambda x: f'{x[1]}',
                           'Creation Time': lambda x: f'{x[1]}'}
    
    file_info_object = {'File': lambda x: x,
                        'Parent': lambda x: x.parent,
                        'Grandparent': lambda x: x.parent.parent,
                        'Relative Path': lambda x: x.relative_to(x.parent.parent),
                        'Name': lambda x: x.name,
                        'Stem': lambda x: FileDialog.parse_file_suffix(x)[0],
                        'Suffix': lambda x: FileDialog.parse_file_suffix(x)[1],
                        'Is File': lambda x: x.is_file(),
                        'Is Dir': lambda x: x.is_dir(),
                        'Permissions': lambda x: x.stat().st_mode,
                        'File ID': lambda x: FileDialog.get_file_id(x),
                        'Size': lambda x: x.stat().st_size,
                        'Formatted Size': lambda x: FileDialog.format_file_size(x.stat().st_size),
                        'Last Accessed': lambda x: (x.stat().st_atime, datetime.datetime.fromtimestamp(np.round(x.stat().st_atime))),
                        'Last Modified': lambda x: (x.stat().st_mtime, datetime.datetime.fromtimestamp(np.round(x.stat().st_mtime))),
                        'Creation Time': lambda x: FileDialog.get_creation_time(x),
                        'File Type': lambda x: FileDialog.determine_file_type(x),
                        'Dicom Dir': lambda x: FileDialog.detect_dicom_dir(x)}
    
    file_info_list = ['Relative Path', 'Name', 'Suffix', 'Size', 'Formatted Size', 'Last Modified']

    column_names_to_index = {'File': 0,
                             'Parent': 1,
                             'Grandparent': 2,
                             'Relative Path': 3,
                             'Name': 4,
                             'Stem': 5,
                             'Suffix': 6,
                             'Is File': 7,
                             'Is Dir': 8,
                             'Permissions': 9,
                             'File ID': 10,
                             'Size': 11,
                             'Formatted Size': 11,
                             'Last Accessed': 13,
                             'Last Modified': 14,
                             'Creation Time': 15,
                             'File Type': 16,
                             'Dicom Dir': 17}

    def detect_dicom_dir(file_path: Path):
        with dpg.mutex():
            dcm_files = sorted(list(file_path.glob('*.dcm')))
            n_files = len(dcm_files)
            dcm_dir_contents = {}
            # print(f'FileDialog Message: {file_path}\n\t{n_files}')
            if n_files > 0:
                print(f'FileDialog Message: {file_path.name}: {n_files}')
                gdcm_dir = gdcm.Directory()
                gdcm_dir.Load(f'{file_path}')
                file_names = sorted(gdcm_dir.GetFilenames())
                scanner = gdcm.Scanner.New()
                scanner.AddTag(gdcm.Tag(0x0020,0x000e)) # SeriesUID
                scanner.AddTag(gdcm.Tag(0x0020,0x1002)) # Images in Acquisition
                scanner.AddTag(gdcm.Tag(0x0020,0x0012)) # Acquisition Number
                scanned = scanner.Scan(file_names)

                for file_index, file in enumerate(file_names):
                    seriesUID = scanner.GetValue(file, gdcm.Tag(0x0020,0x000e))
                    if f'{seriesUID}' not in dcm_dir_contents:
                        dcm_dir_contents[f'{seriesUID}'] = []
                    dcm_dir_contents[f'{seriesUID}'].append(file)

                del gdcm_dir
                del scanner
        return dcm_dir_contents


    def format_file_size(f_size):
        if float(f_size) == 0.0:
            f_size_power_of_ten = 0.0
        else:
            f_size_power_of_ten = np.floor(np.log10(float(f_size)))
        f_size_suffix = FileDialog.size_string_dict[f_size_power_of_ten]
        f_size_string = ''.join(f'{fs} ' for fs in [float(np.round(float(f_size) / np.power(10, f_size_power_of_ten), decimals = 3)), f_size_suffix])
        return f_size_string.rstrip()

    def format_file_info_string(file_info_dict):
        info_string = ''
        for key, value in file_info_dict.items():
            info_string = f'{info_string}\n{key:<16}: {value}'
        
        return info_string
    
    def parse_file_suffix(file_path:Path):
        """
        Returns
        """
        if file_path.is_file():
            for file_extension in FileDialog.file_type_dict.keys():
                if file_extension in file_path.name:
                    if file_extension == file_path.name[-len(file_extension):]:
                        return file_path.name.split(file_extension)[0], file_extension
            return file_path.stem, file_path.suffix
        else:
            return file_path.stem, ''
        
    def get_creation_time(file_path:Path):
        if file_path.stat().__contains__('st_birthtime'):
            return (file_path.stat().st_birthtime, datetime.datetime.fromtimestamp(np.round(file_path.stat().st_birthtime)))
        else:
            return (file_path.stat().st_ctime, datetime.datetime.fromtimestamp(np.round(file_path.stat().st_ctime)))

    def determine_file_type(file_path:Path):
        if file_path.is_file():
            suffix = FileDialog.parse_file_suffix(file_path)[1]
            match suffix:
                case '.mat':
                    return FileDialog.matfile_version_dict[f'{matfile_version(file_path)}'][1]
                case '.h5':
                    return 'hdf5'
                case '.hdf5':
                    return 'hdf5'
                case '.dcm':
                    return 'dicom'
                case '.nii':
                    return 'nifti'
                case '.nii.gz':
                    return 'nifti'
                case _:
                    return suffix
                
        elif file_path.is_dir():
            return 'dir'
        
        return ''
    
    def get_file_id(path: Path):
        return f'{path.stat().st_ino}-{path.stat().st_dev}'

    def __init__(self, path: Path, parent: bool = False, debug: bool = True,
                 show: bool = True):
        self.current_directory = Path(path)
        self.parent = parent
        self.debug = debug
        self.current_directory_file_dict = {}
        self.selected_files_dict = {}
        self.file_extension_dict = {"All Files (*)": [[''], []],
                                    "Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)": [['.mat', '.dcm', '.h5', '.hdf5', '.nii', '.nii.gz'], []],
                                    "MATLab Files (.mat)": [['.mat'], []],
                                    "DICOM Files (.dcm)": [['.dcm'], []],
                                    "HDF5 Files (.h5, .hdf5)": [['.h5', '.hdf5'], []],
                                    "Nifti Files (.nii, .nii.gz)": [['.nii', '.nii.gz'], []]}

        self.parse_files_in_path(self.current_directory)
        
        self.table_row_index_to_tag = {} # Row index: row_tag
        self.table_row_tag_to_index = {} # Row_tag: row_index

        self.separator = '|'
        self.dpg_items = []
        self.file_table_columns = ['Name', 'Formatted Size', 'Last Modified', 'Suffix']
        self.file_dialog_table_tag = self.create_tag('Table', 'FileDialog')
        self.chosen_files_table_tag = self.create_tag('Table', 'ChosenFiles')
        self.item_handler_registry_tag = self.create_tag('ItemHandlerRegistry', 'TableRows')
        self.double_click_handler_tag = self.create_tag('DoubleClickHandler', 'TableRows')
        self.single_click_handler_tag = self.create_tag('SingleClickHandler', 'TableRows')
        self.value_registry_tag = self.create_tag('ValueRegistry', 'Strings')
        self.current_directory_text_tag = self.create_tag('Text', 'CurrentDirectory')
        self.go_up_directory_button_tag = self.create_tag('Button', 'GoUpDirectory')
        self.refresh_directory_button_tag = self.create_tag('Button', 'RefreshDirectory')
        self.file_filter_combobox_tag = self.create_tag('ComboBox', 'FileExtensions')
        self.selected_rows_info_string = ''
        self.selected_rows_info_text_tag = self.create_tag('Text', 'SelectedRowsInfo')
        self.selected_rows_info_string_value_tag = self.create_tag('StringValue', 'SelectedRowsInfo')
        self.selected_rows_dict = {}
        self.directory_theme = self.create_tag('Theme', 'DirectoryTheme')
        self.mat_theme = self.create_tag('Theme', 'MatTheme')
        self.hdf5_theme = self.create_tag('Theme', 'HDF5Theme')
        self.nifti_theme = self.create_tag('Theme', 'NiftiTheme')
        self.dicom_theme = self.create_tag('Theme', 'DicomTheme')
        self.theme_dict = {'dir': self.directory_theme,
                           'mat': self.mat_theme,
                           'hdf5': self.hdf5_theme,
                           'dicom': self.dicom_theme,
                           'nifti': self.nifti_theme}
        self.default_table_size = [0.56, 0.1, 0.215, 0.125]
        self.chosen_file_nodes = {}
        self.chosen_table_theme = self.create_tag('Theme', 'ChosenFilesTable')
        self.current_sort_app_data = []
        self.current_filter_app_data = []
        self.chosen_table_user_data = [0, []] # current_indent_level, [selected_rows]

        self.last_selected_file = None
        self.parsed_file = None
        self.load_file_dict = None

    def __del__(self):
        if not self.parent:
            dpg.destroy_context()

    def bind_theme_value(self, item, file_dict):
        file_type = file_dict['File Type']
        if file_type in self.theme_dict.keys():
            dpg.bind_item_theme(item, self.theme_dict[file_type])

    def initialize(self, debug = False):
        if not self.parent:
            dpg.create_context()

        dpg.add_item_double_clicked_handler(button = dpg.mvMouseButton_Left, tag = self.double_click_handler_tag, callback = self.change_current_directory_double_click, parent = G.ITEM_HANDLER_REG_TAG)
        dpg.add_item_clicked_handler(button = dpg.mvMouseButton_Left, tag = self.single_click_handler_tag, callback = self.item_single_clicked, parent = G.ITEM_HANDLER_REG_TAG)

        dpg.add_string_value(default_value = self.selected_rows_info_string, tag = self.selected_rows_info_string_value_tag, parent = G.VALUE_REG_TAG)

        # with dpg.item_handler_registry(tag = self.item_handler_registry_tag):
        #     dpg.add_item_double_clicked_handler(button = dpg.mvMouseButton_Left, tag = self.double_click_handler_tag, callback = self.change_current_directory)
        #     dpg.add_item_clicked_handler(button = dpg.mvMouseButton_Left, tag = self.single_click_handler_tag, callback = self.item_single_clicked)

        # with dpg.value_registry(tag = self.value_registry_tag):
        #     dpg.add_string_value(default_value = self.selected_rows_info_string, tag = self.selected_rows_info_string_value_tag)

        dpg.add_theme(tag = self.directory_theme)

        with dpg.theme_component(dpg.mvSelectable, parent = self.directory_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [220, 0, 40])

        dpg.add_theme(tag = self.mat_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.mat_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [220, 220, 40])

        dpg.add_theme(tag = self.hdf5_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.hdf5_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [0, 220, 40])

        dpg.add_theme(tag = self.nifti_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.nifti_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [40, 220, 220])

        dpg.add_theme(tag = self.dicom_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.dicom_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [40, 220, 0])

        dpg.add_theme(tag = self.chosen_table_theme)
        with dpg.theme_component(dpg.mvAll, parent = self.chosen_table_theme):
            dpg.add_theme_style(dpg.mvStyleVar_FramePadding, 4, 0)

        with dpg.window(label='File Dialog', tag = self.create_tag('Window', 'FileDialog'), 
                        width = -1, height = 720, show = False, menubar = False, modal = True) as self.file_dialog_window:
            
            with dpg.group(horizontal=True, tag = self.create_tag('Group', 'FileDialogContents')):
                with dpg.child_window(tag = self.create_tag('Window', 'CurrentDirectoryContents'), 
                                      width = 725, height = 350):
                    with dpg.group(horizontal = True, tag = self.create_tag('Group', 'NavigationButtons')):
                        dpg.add_button(label = '', width = 19, height = 19, tag = self.go_up_directory_button_tag, 
                                       arrow = True, direction = dpg.mvDir_Up,
                                       callback = self.change_current_directory)
                        dpg.add_button(label = 'R', width = 19, height = 19, tag = self.refresh_directory_button_tag,
                                       callback = self.refresh_current_directory)
                        dpg.add_text(f'{self.format_displayed_path(self.current_directory)}', tag = self.current_directory_text_tag)
                    with dpg.table(tag = self.file_dialog_table_tag, 
                                   sortable = True, 
                                   sort_multi = True, 
                                   header_row = True, 
                                   freeze_rows = 1,
                                   callback = self.sort_files_callback,
                                   user_data = self.current_directory_file_dict,
                                   resizable = True, 
                                   width = -1, 
                                   height = 275, 
                                   scrollY = True):
                        
                        dpg.add_table_column(label = 'Name', tag = self.create_tag('TableColumn', 'Name'),
                                             width_stretch=True, init_width_or_weight = self.default_table_size[0])
                        dpg.add_table_column(label = 'Size', tag = self.create_tag('TableColumn', 'Size'), 
                                             no_resize = False, init_width_or_weight = self.default_table_size[1])
                        dpg.add_table_column(label = 'Last Modified', tag = self.create_tag('TableColumn', 'Last Modified'), 
                                             no_resize = False, init_width_or_weight = self.default_table_size[2])
                        dpg.add_table_column(label = 'Extension', tag = self.create_tag('TableColumn', 'Suffix'), 
                                             no_resize = False, init_width_or_weight = self.default_table_size[3])

                    self.populate_table_rows(self.file_dialog_table_tag, self.current_directory_file_dict)
                    self.bind_table_rows(G.ITEM_HANDLER_REG_TAG, self.file_dialog_table_tag)

                    with dpg.group(horizontal = True, tag = self.create_tag('HorizontalGroup', 'FileSelectionParams')):
                        dpg.add_combo(items = list(self.file_extension_dict.keys()), # app_data of form [selected_string]
                                      tag = self.file_filter_combobox_tag,
                                      width = -0, default_value = list(self.file_extension_dict.keys())[0],
                                      callback = self.filter_table_results_callback) 
                        self.filter_combobox_app_data = list(self.file_extension_dict.keys())[0]
                        dpg.add_button(label = 'Deselect All', tag = self.create_tag('Button', 'DeselectAll'),
                                       width=-1, callback = self.deselect_all)
                        
                if self.debug:
                    with dpg.child_window(tag = self.create_tag('Window', 'SelectedRowInfo'), width = 940, height = 350, 
                                          resizable_x = True, horizontal_scrollbar = True):
                        dpg.add_text(default_value = '', 
                                     source = self.selected_rows_info_string_value_tag, 
                                     tag = self.selected_rows_info_text_tag)
                    
            with dpg.child_window(tag = self.create_tag('Window', 'ChosenFiles'), width = 720, height = 350):
                with dpg.table(tag = self.chosen_files_table_tag, resizable = True, width = -1, height = 275, 
                               scrollY = True, user_data = self.chosen_table_user_data):
                    dpg.add_table_column(label = 'Name', tag = 'Chosen|Name', init_width_or_weight = 0.70)
                    dpg.add_table_column(label = 'Shape', tag = 'Chosen|Shape', init_width_or_weight = 0.20)
                    dpg.add_table_column(label = 'Type', tag = 'Chosen|Type', init_width_or_weight = 0.10)
                dpg.bind_item_theme(self.chosen_files_table_tag, self.chosen_table_theme)
                
                with dpg.group(horizontal = True, tag = self.create_tag('HorizontalGroup', 'VolumeIOButtons')):
                    dpg.add_button(label = f'Load Selected', tag = self.create_tag('Button', 'LoadSelectedVolumes'), 
                                   callback = self.load_selected_volumes)

        if not self.parent:
            dpg.create_viewport(title='Custom File Dialog', width = 1720, height = 1080, x_pos = 10, y_pos = 10)
            dpg.setup_dearpygui()
            dpg.set_primary_window(self.file_dialog_window, True)
            dpg.show_viewport()
            dpg.start_dearpygui()

            dpg.destroy_context()
    
    def load_selected_volumes(self):
        indent, leaves = self.chosen_table_user_data
        if len(leaves) < 1:
            return
        print(f'FileDialog Message: Loading {self.chosen_table_user_data}')
        load_file_dict = {}
        for row_leaf in leaves:
            print(f'FileDialog Message: {dpg.get_item_user_data(dpg.get_item_user_data(row_leaf)[1])[0] = }') # Gets node_user_data
            row_user_data = dpg.get_item_user_data(dpg.get_item_user_data(row_leaf)[1])
            row_id_info = row_user_data[0]
            row_attrib_dict = row_user_data[1]
            file_id = row_id_info.split('|')[0]
            file_name = row_id_info.split('|')[1]
            file_volume = row_id_info.split('|')[-1]
            if file_id in load_file_dict.keys():
                load_file_dict[file_id]['volumes'][file_volume] = {'Attributes': dict(row_attrib_dict)}
            else:
                load_file_dict[file_id] = {}
                load_file_dict[file_id]['Attributes'] = dict(self.chosen_file_nodes[file_id]['Attributes'])
                load_file_dict[file_id]['volumes'] = {file_volume: {'Attributes': dict(row_attrib_dict)}}

        # load_file_dict[file_id] = {'Attributes': {}, 
        #                            'volumes': 
        #                                      {volume_1: 
        #                                                {'Attributes': 
        #                                                              {'affine': ...
        #                                                               }
        #                                                 }
        #                                       }
        #                             }

        self.load_file_dict = dict(load_file_dict)
        data_loader = DataLoader(self.load_file_dict)
        data_loader.load_selected_files()
        data_loader.finalize_load_volumes()
        self.deselect_all()

    def close(self):
        if self.parent:
            dpg.destroy_context()
        else:
            self.hide()

    def show(self):
        dpg.show_item(self.file_dialog_window)

    def hide(self):
        dpg.hide_item(self.file_dialog_window)

    def multisort(self, x_list, sort_specs, make_copy = True, return_sorted_list = False):
        if make_copy:
            return_list = [val for val in x_list]
        else:
            return_list = x_list
    
        # Reverse sort specs so we work our way out of the sorting appropriately, 
        # where we sort the last key first. 
        
        for index, reverse in reversed(sort_specs):
            return_list.sort(key = itemgetter(index), reverse = reverse <= 0)
    
        new_indices = []
        
        for new_index, row_tuple in enumerate(return_list):
            new_indices.append(row_tuple[-2]) # internal dpg item number, row id
        
        if return_sorted_list:
            return return_list, new_indices
        else:
            return new_indices

    def sort_files_callback(self, sender, app_data, user_data):
        """
        sender: Table|FileDialog, etc
        app_data:
            no sorting -> app_data == None
            single sorting -> app_data = [[column_id, direction]]
            multi sorting -> app_data = [[column_id, direction], [column_id, direction], ... ]
            direction == +1 -> ascending
            direction == -1 -> descending
        user_data: self.current_directory_file_dict or similar
        """

        print(f'FileDialog Message: Sort files callback:\n{sender = }\n{app_data = }')
    
        if app_data is None: 
            return

        self.current_sort_app_data = [data for data in app_data]

        sort_columns = []
        s_specs = [[8, -1]] # [File info column number, ascending/descending], starts with is_dir
        values_to_sort = []
        for child_index, child in enumerate(dpg.get_item_children(sender, 1)):
            file_id = dpg.get_item_alias(child).split('|')[1]
            c_list = [value for value in user_data[file_id].values()]
            c_list.extend([child, child_index])
            values_to_sort.append(c_list)

        for a_data in app_data:
            alias = dpg.get_item_alias(a_data[0]).split('|')[1]
            col_number = FileDialog.column_names_to_index[alias]
            
            sort_columns.append([alias, '\u2191' if a_data[1] > 0 else '\u2193'])
            s_specs.append([col_number, a_data[1]])

        logger_info = f'Sorting file dialog: {sender = }, {app_data = }, {sort_columns = }'

        sorted_indices = self.multisort(values_to_sort, s_specs, make_copy = True, return_sorted_list = False)
        
        dpg.reorder_items(sender, 1, sorted_indices)
        print('FileDialog Message: Sorting done')
    

    def filter_table_results_callback(self, sender, app_data):
        # app_data = "Nifti Files (.nii, .nii.gz)" or other key in self.file_extension_dict
        # self.file_extension_dict[app_data][1] this is a list of files matching the appropriate extension.
        self.filter_combobox_app_data = app_data
        for table_row in dpg.get_item_children(self.file_dialog_table_tag, 1):
            # self.table_row_index_to_tag[table_row].split(self.separator)[1] returns rel_path
            # row_tag = 'TableRow|file_id|parent_table'
            # parent_table user_data has the full dict of file info
            file_id = self.table_row_index_to_tag[table_row].split(self.separator)[1]
            is_dir = self.current_directory_file_dict[file_id]['Is Dir']
            if (file_id in self.file_extension_dict[app_data][1]) or is_dir:
                dpg.show_item(table_row)
            else:
                dpg.hide_item(table_row)

    
    def get_table_contents(self, parent_table):
        table_contents = {}
        if len(dpg.get_item_children(parent_table, 1)) == 0:
            print(f'FileDialog Message: No children found in {parent_table}')
            return
        for row_id in dpg.get_item_children(parent_table, 1):
            table_contents[dpg.get_item_alias(row_id)] = dpg.get_item_children(row_id, 1)
            print(f'FileDialog Message: {row_id = }, {dpg.get_item_alias(row_id) = }, {dpg.get_item_children(row_id, 1) = }')


    def populate_table_rows(self, parent_table, file_dict:dict, row_type = 'selectable'):
        """
        file_dict -> None or file dictionary to add as rows.
        """

        for file_id in file_dict.keys():
            row_tag = self.create_tag('TableRow', f'{file_id}', suffix = parent_table)
            with dpg.table_row(tag = row_tag, parent = parent_table):
                self.table_row_index_to_tag[dpg.last_item()] = row_tag
                self.table_row_tag_to_index[row_tag] = dpg.last_item()
                self.bind_theme_value(row_tag, file_dict[file_id])
                for f_info in self.file_table_columns: # [Name', 'Formatted Size', 'Last Modified', 'Extension']
                    tag = self.create_tag('SelectableRow', f'{file_id}', suffix = f'{parent_table}{self.separator}{f_info}')
                    dpg.add_selectable(label = f'{file_dict[file_id][f_info]}',
                                       tag = tag,
                                       user_data = (file_id, file_dict[file_id]),
                                       span_columns = True,
                                       callback = self.update_selected_rows)
    

    def bind_table_rows(self, handler, table_tag):
        # print(f'FileDialog Message: Binding items to {handler = }.')
        for row in dpg.get_item_children(table_tag, 1):
            if len(dpg.get_item_children(row, 1)) > 0:
                for row_child in dpg.get_item_children(row, 1):
                    # print(f'FileDialog Message: \tBinding {row_child = }, {dpg.get_item_alias(row_child) = }, {dpg.get_item_type(row_child) = }')
                    dpg.bind_item_handler_registry(row_child, handler)


    def reset_table_rows(self, parent_table):
        dpg.delete_item(parent_table, children_only = True, slot = 1)
    

    def item_single_clicked(self, sender, app_data, user_data):
        # print(f'FileDialog Message: Single item clicked!\n----------\n{sender = }\n{app_data = }\n{user_data = }\n----------')
        pass


    def refresh_current_directory(self):
        with dpg.mutex():
            self.reset_table_rows(self.file_dialog_table_tag)

            self.current_directory_file_dict.clear()
            self.table_row_tag_to_index.clear()
            self.table_row_index_to_tag.clear()

            self.parse_files_in_path(self.current_directory) # self.current_directory_file_dict, self.file_extension_dict
            self.populate_table_rows(self.file_dialog_table_tag, self.current_directory_file_dict)
            self.bind_table_rows(G.ITEM_HANDLER_REG_TAG, self.file_dialog_table_tag)

            for file_id in self.selected_rows_dict.keys():
                for table_row in self.table_row_tag_to_index.keys():
                    if file_id in table_row:
                        dpg_id = self.table_row_tag_to_index[table_row]
                        # We only need the first column since that selectable covers the entire row. 
                        for row_child in dpg.get_item_children(dpg_id, 1)[:1]:
                            dpg.set_value(row_child, True)

            self.filter_table_results_callback(self.file_filter_combobox_tag, dpg.get_value(self.file_filter_combobox_tag))
            self.sort_files_callback(self.file_dialog_table_tag, self.current_sort_app_data, dpg.get_item_user_data(self.file_dialog_table_tag))
        print(f'FileDialog Message: Directory {self.current_directory} refreshed.')

    def change_current_directory_double_click(self, sender, app_data, user_data):
        if dpg.is_item_shown(self.file_dialog_window):
            self.change_current_directory(sender, app_data, user_data)

    def change_current_directory(self, sender, app_data, user_data):
        print('FileDialog Message: Changing Directory.')
        with dpg.mutex():
            if sender == self.go_up_directory_button_tag:
                self.current_directory = self.current_directory.parent

            else:
                item_tag = dpg.get_item_alias(app_data[1])
                print(f'FileDialog Message: \t{item_tag = }')
                rel_path = item_tag.split('|')[1]
                if self.current_directory_file_dict[rel_path]['Is Dir']:
                    self.current_directory = Path(self.current_directory_file_dict[rel_path]['File'])
                else:
                    pass
            
            displayed_path = self.format_displayed_path(self.current_directory, max_length=415, scale_factor=7.0)

            dpg.set_value(self.current_directory_text_tag, f'{displayed_path}')

        self.refresh_current_directory()
        G.CONFIG_DICT['directories']['image_dir'] = Path(self.current_directory).as_posix()

    def format_displayed_path(self, path:Path, max_length = 415, scale_factor = 7.0):
        
        displayed_path = '.../'
        displayed_text_length = scale_factor*len(displayed_path)
        parts_list = []

        for part in reversed(list(path.parts)):
            if displayed_text_length + scale_factor*(len(part) + 1) >= max_length:
                break
            parts_list.append(part)
            displayed_text_length += scale_factor*(len(part) + 1)
            
        displayed_path = Path(displayed_path)
        for part in reversed(parts_list):
            displayed_path = displayed_path.joinpath(part)

        return displayed_path.as_posix()

    def update_selected_rows(self, sender, app_data, user_data):
        """
        sender is of form: 'SelectableRow|562949953663636|Name'
        app_data is of form: True
        user_data is of form: (file_id, current_directory_file_dict[file_id])
        """
        self.selected_rows_info_string = ''

        file_id, file_dict = user_data

        # if file_dict['File Type'] == 'dir':
        #     dpg.set_value(sender, False)
        #     return

        if app_data and (file_id not in self.selected_rows_dict.keys()):
            self.selected_rows_dict[file_id] = file_dict

        if (not app_data) and (file_id in self.selected_rows_dict.keys()):
            self.selected_rows_dict.pop(file_id, None)
            self.selected_files_dict.pop(file_id, None)
        
        for selected_row_key in self.selected_rows_dict.keys():
            formatted_file_info = FileDialog.format_file_info_string(self.selected_rows_dict[selected_row_key])
            self.selected_rows_info_string = f'{self.selected_rows_info_string}{"-"*50}{formatted_file_info}\n'

        dpg.set_value(self.selected_rows_info_string_value_tag, self.selected_rows_info_string)

        self.update_selected_files(self.selected_rows_dict)
        self.update_chosen_file_nodes(self.selected_files_dict)
        self.populate_chosen_rows(self.chosen_files_table_tag, self.chosen_file_nodes)
        self.chosen_files_table_user_data = dpg.get_item_user_data(self.chosen_files_table_tag)


    def update_selected_files(self, selected_row_dict:dict):
        for key, value in selected_row_dict.items():
            if (key not in self.selected_files_dict.keys()) and value['Is File']:
                self.selected_files_dict[key] = value

    
    def update_chosen_file_nodes(self, selected_file_dict:dict):
        file_dict = {}
        for key, value in selected_file_dict.items():
            file_dict[value['File ID']] = value['Name']
            if value['File ID'] not in self.chosen_file_nodes.keys():
                if value['File Type'] in ['mat','hdf5','dicom','nifti']:
                    self.last_selected_file = FileParser(value)
                    # print(self.last_selected_file.print())
                    self.chosen_file_nodes[value['File ID']] = self.last_selected_file.file_contents

            else: 
                pass
            
        chosen_keys = list(self.chosen_file_nodes.keys())
        for key in chosen_keys:
            if key not in list(file_dict.keys()):
                print(f'FileDialog Message: Deleting {key} at row {self.chosen_file_nodes[key]["Row"]}')
                delete_node(self.chosen_files_table_tag, self.chosen_file_nodes[key]['Row'])
                del self.chosen_file_nodes[key]


    def populate_chosen_rows(self, parent_table: int|str, node_dict:dict):
        for file_node in node_dict.keys():
            if 'Row' in node_dict[file_node].keys():
                continue
            else:
                r_list = []
                #self.chosen_file_nodes[value['File ID']] = self.last_selected_file.file_contents
                create_tree_node(node_dict[file_node], 
                                 parent_table = parent_table, 
                                 row_list = r_list, 
                                 add_popup=True, 
                                 node_user_data = [f'{file_node}', node_dict[file_node]['Attributes']])


    def deselect_all(self):
        self.selected_rows_dict.clear()
        self.selected_files_dict.clear()
        self.update_chosen_file_nodes(self.selected_files_dict)

        self.selected_rows_info_string = ''

        for row_id in dpg.get_item_children(self.file_dialog_table_tag, 1):
            for row_child in dpg.get_item_children(row_id, 1):
                dpg.set_value(row_child, False)

        for row_id in dpg.get_item_children(self.chosen_files_table_tag, 1):
            dpg.delete_item(row_id, slot = 1)

        dpg.set_value(self.selected_rows_info_string_value_tag, self.selected_rows_info_string)


    def create_tag(self, dpg_object_designation: str, tag_name: str, separator: str = '|', suffix: str = ''):
        """
        dpg_object_name <separator> tag_name <separator> suffix
        dpg_object, tag_name, suffix = tag.split(separator)
        """
        
        tag = f'FileDialog{dpg_object_designation}{separator}{tag_name}{separator}{suffix}' if suffix != '' else f'FileDialog{dpg_object_designation}{separator}{tag_name}'
        
        return tag

    
    def get_file_info(self, filepath: Path, format_file_info = True, exclude = ['Size']):
        """
        Exclude can be:
            'File'
            'Parent'
            'Grandparent'
            'Relative Path'
            'Permissions'
            'Size'
            'Last Accessed'
            'Last Modified'
            'Creation Time'
        """
        f_info_dict = {}
        for f_info in FileDialog.file_info_object.keys():
            f_info_dict[f_info] = FileDialog.file_info_object[f_info](filepath)
        if format_file_info:
            for f_info in FileDialog.file_info_formatter.keys():
                if f_info in exclude:
                    continue
                else:
                    f_info_dict[f_info] = FileDialog.file_info_formatter[f_info](f_info_dict[f_info])
            
        return f_info_dict
    
    
    def parse_files_in_path(self, path: Path):
        
        for file in path.glob('*'):
            print(f'FileDialog Message: FILE_PARSER: {file.name}')
            file_id = FileDialog.get_file_id(file)
            self.current_directory_file_dict[f'{file_id}'] = self.get_file_info(file, format_file_info = True, exclude = ['Size'])
            match self.current_directory_file_dict[f'{file_id}']['Suffix']:
                case '.mat':
                    self.file_extension_dict["MATLab Files (.mat)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
                case '.dcm':
                    self.file_extension_dict["DICOM Files (.dcm)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
                case '.h5' | '.hdf5':
                    self.file_extension_dict["HDF5 Files (.h5, .hdf5)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
                case '.nii' | '.nii.gz': 
                    self.file_extension_dict["Nifti Files (.nii, .nii.gz)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
        
        self.file_extension_dict["All Files (*)"][1].extend(list(self.current_directory_file_dict.keys()))
        
        return


class FileParser(object):
    default_dict = {'Name': 'DEFAULT', 'Type': '', 'Data': {}, 'Attributes': {'DEFAULT': 'DEFAULT'}}

    def __init__(self, file_info_object, suffix_4d = '__'):

        """
        file_info_object = {'File': lambda x: x,
                            'Parent': lambda x: x.parent,
                            'Grandparent': lambda x: x.parent.parent,
                            'Relative Path': lambda x: x.relative_to(x.parent.parent),
                            'Name': lambda x: x.name,
                            'Stem': lambda x: x.stem,
                            'Suffix': lambda x: FileDialog.parse_file_suffix(x),
                            'Is File': lambda x: x.is_file(),
                            'Is Dir': lambda x: x.is_dir(),
                            'Permissions': lambda x: x.stat().st_mode,
                            'File ID': lambda x: x.stat().st_ino,
                            'Size': lambda x: x.stat().st_size,
                            'Formatted Size': lambda x: FileDialog.format_file_size(x.stat().st_size),
                            'Last Accessed': lambda x: (x.stat().st_atime, datetime.datetime.fromtimestamp(np.round(x.stat().st_atime))),
                            'Last Modified': lambda x: (x.stat().st_mtime, datetime.datetime.fromtimestamp(np.round(x.stat().st_mtime))),
                            'Creation Time': lambda x: (x.stat().st_birthtime, datetime.datetime.fromtimestamp(np.round(x.stat().st_birthtime))),
                            'File Type': lambda x: FileDialog.determine_file_type(x)}

        file_info_formatter = {'File': lambda x: x.as_posix(),
                               'Parent': lambda x: x.as_posix(),
                               'Grandparent': lambda x: x.as_posix(),
                               'Relative Path': lambda x: x.as_posix(),
                               'Permissions': lambda x: oct(x)[2:],
                               'Size': lambda x: FileDialog.format_file_size(x), 
                               'Last Accessed': lambda x: f'{x[1]}',
                               'Last Modified': lambda x: f'{x[1]}',
                               'Creation Time': lambda x: f'{x[1]}'}
        """

        self.parse_dict = {'mat': self.parse_mat_file,
                           'hdf5': self.parse_hdf5_file,
                           'dicom': self.parse_dicom_files,
                           'nifti': self.parse_nifti_file}
        
        self.matfile_version_dict = {'(0, 0)': ['v4', 'mat'],
                                     '(1, 0)': ['v5', 'mat'],
                                     '(2, 0)': ['v7.3', 'h5']}

        # We want a new dictionary made from the old one, not just a pointer. 
        self.file_info_object = dict(file_info_object) 
        self.file_contents = {'Name': file_info_object['Name'], 'Type': 'Group', 'Data': {}, 'Attributes': {'four_d': False, 
                                                                                                            'file_type': self.file_info_object['File Type'],
                                                                                                            'file_path': Path(self.file_info_object['File']),
                                                                                                            'file_id': self.file_info_object['File ID'],
                                                                                                            'file_name': self.file_info_object['Name']}}
        self.array4D = False
        self.suffix_4d = suffix_4d
        self.parse_file(self.file_info_object, self.file_contents)

    def print(self):
        print(self.file_contents)

    def parse_file(self, file_info_object, file_contents):

        return self.parse_dict[file_info_object['File Type']](file_info_object, file_contents)

    def parse_mat_file(self, file_info_object: dict, file_content_dict: dict = None): 
        mat_version, updated_file_type = self.matfile_version_dict[f'{matfile_version(file_info_object["File"])}']
        if updated_file_type == 'hdf5':
            self.parse_hdf5_file(file_info_object, file_content_dict)
            return

        mat_variables = whosmat(file_info_object['File'])

        if type(file_content_dict) == type(None):
            file_content_dict = dict(FileParser.default_dict)

        for var_name, var_shape, var_dtype in mat_variables:
            if len(var_shape) <= 3:
                file_content_dict['Data'][var_name] = {'Name': var_name, 'Type': 'Dataset', 'Attributes': {'shape': var_shape, 'dtype': var_dtype}}
            
            elif len(var_shape) == 4:
                file_content_dict['Attributes']['four_d'] = True
                for index in range(var_shape[0]):
                    zfilled_index = f'{index}'.zfill(len(f'{var_shape[0]}'))
                    name = f'{var_name}{self.suffix_4d}{zfilled_index}'
                    file_content_dict['Data'][var_name] = {'Name': name, 'Type': 'Dataset', 'Attributes': {'shape': var_shape[1:], 'dtype': var_dtype}}

            else: 
                pass
        
        if type(file_content_dict) == type(dict()):
            return file_content_dict


    def parse_hdf5_file(self, file_info_object: dict, file_content_dict: dict = None):

        with h5py.File(file_info_object['File'], mode = 'r', swmr = True, track_order = True) as hdf5_stream:
            self.retrieve_hdf5_info(hdf5_stream, file_content_dict = file_content_dict)

        if type(file_content_dict) == type(None):
            return file_content_dict


    def retrieve_hdf5_info(self, hdf5_object:h5py.Group|h5py.Dataset, file_content_dict:dict = None):
        """
        Recursively finds all information in an hdf5 file and stores it in a hierarchical dictionary.
        
        Uses retrieve hdf5_attrs.
        """

        return_dict = False
        if type(file_content_dict) == type(None):
            file_content_dict = {'Name': hdf5_object.file.filename, 'Type': 'Group', 'Data': {}, 'Attributes': self.retrieve_hdf5_attrs(hdf5_object)}
            return_dict = True

        else:
            file_content_dict['Attributes'].update(self.retrieve_hdf5_attrs(hdf5_object))
                
        if isinstance(hdf5_object, h5py.Group):
            file_content_dict['Type'] = 'Group'
            for key, value in hdf5_object.items():
                if isinstance(value, h5py.Group):
                    file_content_dict['Data'][key] = {'Name': key, 'Type': 'Group', 'Data': {}, 'Attributes': {}}
                    self.retrieve_hdf5_info(value, file_content_dict = file_content_dict['Data'][key])
                
                else:
                    attrs = self.retrieve_hdf5_attrs(value)
                    attrs['shape'] = value.shape
                    attrs['dtype'] = value.dtype
                    if len(value.shape) == 4:
                        self.array4D = True
                        attrs['shape'] = value.shape[1:]
                        for index in range(len(value)):
                            zfilled_index = f'{index}'.zfill(len(f'{value.shape[0]}'))
                            name = f'{value.name}{self.suffix_4d}{zfilled_index}'
                            file_content_dict['Data'][name] = {'Name': name,
                                                               'Type': 'Dataset',
                                                               'Attributes': attrs}

                    else:
                        file_content_dict['Data'][key] = {'Name': value.name, 
                                                          'Type': 'Dataset',
                                                          'Attributes': attrs}



        elif isinstance(hdf5_object, h5py.Dataset):
            file_content_dict['Type'] = 'Dataset'
        
        if return_dict:
            return file_content_dict

    def retrieve_hdf5_attrs(self, hdf5_object:h5py.Group|h5py.Dataset):
        """
        Function to retrieve attribute keys and values and return them as a dict. 
        """
        
        attrs_dict = {}
        
        for key, value in hdf5_object.attrs.items():
            attrs_dict[key] = value
            
        return attrs_dict

    def parse_dicom_files(self, file_info_object, file_content_dict):

        if type(file_content_dict) == type(dict()):
            return file_content_dict

    def parse_dicom_dir(self, directory_info_object, file_content_dict):
        pass

    def parse_nifti_file(self, file_info_object, file_content_dict):

        if type(file_content_dict) == type(None):
            file_content_dict = dict(FileParser.default_dict)

        nib_file = nib.load(file_info_object['File'])
        var_affine = nib_file.affine
        var_shape = nib_file.shape
        var_dtype = nib_file.header.get_data_dtype()

        file_content_dict['Data']['volume'] = {'Name': 'volume', 'Type': 'Dataset', 'Attributes': {'shape': var_shape, 'affine': var_affine, 'dtype': var_dtype}}

        if type(file_content_dict) == type(dict()):
            return file_content_dict


class DataLoader(object):
    """
    The purpose of this class is to pass the selected files and data to G.APP.Volumes and G.APP.VolumeLayerGroups using CTVolume.CTVolume. 
    """
    def __init__(self, files_to_be_loaded_dict):
        
        self.load_type_dict = {'mat': self.load_mat_file,
                               'hdf5': self.load_hdf5_file,
                               'dicom': self.load_dicom_files,
                               'nifti': self.load_nifti_file}
        # load_file_dict[file_id] = {'Attributes': {}, 
        #                            'volumes': 
        #                                      {volume_1: 
        #                                                {'Attributes': 
        #                                                              {'affine': ...
        #                                                               }
        #                                                 }
        #                                       }
        #                             }
        self.files_to_be_loaded_dict = files_to_be_loaded_dict

    def finalize_load_volumes(self):
        if len(G.APP.Volumes) > 0:
            if not G.FILE_LOADED:
                G.APP.VolumeLayerGroups.add_group(group_name = 'AllVolumes', 
                                                  default_orientation = [0, 0, 0, 0, 0, 0, 0], 
                                                  default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire'],
                                                  default_histogram = [-0.5, 1200.5, 1, 'Linear'],
                                                  default_limits_origin = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                                                  default_limits_norm = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                                                  default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]])

                G.FILE_LOADED = True
                G.APP.VolumeLayerGroups.add_volumes_to_group('AllVolumes', 
                                                             G.APP.Volumes)
                G.N_VOLUMES = len(G.APP.Volumes)
                G.OPTIONS_DICT['img_index_slider']['max_value'] = G.N_VOLUMES
                dpg.configure_item(G.OPTIONS_DICT['img_index_slider']['slider_tag'], max_value = G.OPTIONS_DICT['img_index_slider']['max_value'])
                G.APP.main_view.load_image()
                G.APP.info_box.load_image()
                G.APP.options_panel.enable_options()
                G.APP.image_tools.enable_options()
                dpg.configure_item('save_landmarks_button', enabled = True)
                dpg.configure_item('load_landmarks_button', enabled = True)
        
            else:
                G.APP.VolumeLayerGroups.add_volumes_to_group('AllVolumes', 
                                                             G.APP.Volumes)
                G.N_VOLUMES = len(G.APP.Volumes)
                G.OPTIONS_DICT['img_index_slider']['max_value'] = G.N_VOLUMES
                dpg.configure_item(G.OPTIONS_DICT['img_index_slider']['slider_tag'], max_value = G.OPTIONS_DICT['img_index_slider']['max_value'])
                G.APP.image_tools.update_selector_lists()

        layers_tab_text = f'{G.APP.Volumes[0].name}'
        for vol in G.APP.Volumes[1:]:
            layers_tab_text = f'{layers_tab_text}\n{vol.name}'
        
        dpg.set_value('InfoBoxTab_layers_text', layers_tab_text)
        dpg.configure_item(G.LOADING_WINDOW_TAG, show=False)
        dpg.configure_item(G.LOADING_WINDOW_TAG, modal=False)
        dpg.set_value(G.LOADING_WINDOW_TEXT, '')

    def load_selected_files(self, files_to_be_loaded_dict = None):
        
        G.APP.FileDialog.hide()
        dpg.configure_item(G.LOADING_WINDOW_TAG, show=True)

        if type(files_to_be_loaded_dict) == type(None):
            files_to_be_loaded_dict = dict(self.files_to_be_loaded_dict)

        for file_id in list(files_to_be_loaded_dict.keys()):
            
            file_name = files_to_be_loaded_dict[file_id]['Attributes']['file_name']
            file_type = files_to_be_loaded_dict[file_id]['Attributes']['file_type']

            load_message = f'Loading {file_name}\n\tFile ID: {file_id}'
            dpg.set_value(G.LOADING_WINDOW_TEXT, load_message)

            self.load_type_dict[file_type](files_to_be_loaded_dict, file_id, file_name = file_name)

    def load_mat_file(self, files_to_be_loaded_dict, file_id, file_name = ''):
        for volume_name in files_to_be_loaded_dict[file_id]['volumes']:
            if file_name == '':
                file_name = files_to_be_loaded_dict[file_id]['Attributes']['file_name']
            if volume_name[0] == '/':
                volume_name = volume_name[1:]
            G.APP.Volumes.append(CTVolume.CTVolume(f'{file_name}/{volume_name}', 
                                                   files_to_be_loaded_dict[file_id]['Attributes']['file_path'],
                                                   loadmat(files_to_be_loaded_dict[file_id]['Attributes']['file_path'], 
                                                           appendmat = False, 
                                                           variable_names = volume_name, 
                                                           squeeze_me = True)[volume_name]))

    def load_hdf5_file(self, files_to_be_loaded_dict, file_id, file_name = ''):
        with h5py.File(files_to_be_loaded_dict[file_id]['Attributes']['file_path'], mode = 'r', swmr=True, track_order=True) as h5_file:
            for volume_name in files_to_be_loaded_dict[file_id]['volumes']:
                if file_name == '':
                    file_name = files_to_be_loaded_dict[file_id]['Attributes']['file_name']
                affine = None
                if 'affine' in files_to_be_loaded_dict[file_id]['volumes'][volume_name]['Attributes'].keys():
                    affine = files_to_be_loaded_dict[file_id]['volumes'][volume_name]['Attributes']['affine']
                if volume_name[0] == '/':
                    volume_name = volume_name[1:]
                G.APP.Volumes.append(CTVolume.CTVolume(f'{file_name}/{volume_name}', 
                                                       files_to_be_loaded_dict[file_id]['Attributes']['file_path'],
                                                       h5_file[volume_name][()],
                                                       affine = affine,
                                                       pixel_dims = affine[[0, 1, 2], [0, 1, 2]]))

    def load_dicom_files(self, files_to_be_loaded_dict, file_name):
        pass

    def load_nifti_file(self, files_to_be_loaded_dict, file_id, file_name = ''):
        for volume_name in files_to_be_loaded_dict[file_id]['volumes']:
            print(f'FileDialog Message: Nifti Load: {volume_name}')
            if file_name == '':
                file_name = files_to_be_loaded_dict[file_id]['Attributes']['file_name']
            nib_file = nib.load(files_to_be_loaded_dict[file_id]['Attributes']['file_path'])
            if volume_name[0] == '/':
                volume_name = volume_name[1:]
            G.APP.Volumes.append(CTVolume.CTVolume(f'{file_name}/{volume_name}', 
                                                    files_to_be_loaded_dict[file_id]['Attributes']['file_path'],
                                                    np.array(nib_file.get_fdata()),
                                                    affine = nib_file.affine,
                                                    pixel_dims = nib_file.affine[[0, 1, 2], [0, 1, 2]]))