from .Globals import *

class FileDialog(object):
    
    size_string_dict = {0.0: 'B',
                        1.0: 'B',
                        2.0: 'B',
                        3.0: 'KB',
                        4.0: 'KB',
                        5.0: 'KB',
                        6.0: 'MB',
                        7.0: 'MB',
                        8.0: 'MB',
                        9.0: 'GB',
                        10.0: 'GB',
                        11.0: 'GB',
                        12.0: 'TB',
                        13.0: 'TB',
                        14.0: 'TB'}

    file_type_dict = {'.txt': 'Text File',
                      '.py': 'Python Source File',
                      '.mat': 'Matlab File',
                      '.h5': 'HDF5 File', 
                      '.hdf5': 'HDF5 File',
                      '.nii': 'Nifti File',
                      '.nii.gz': 'gzipped Nifti File'}
    
    file_info_formatter = {'File': lambda x: x.as_posix(),
                           'Parent': lambda x: x.as_posix(),
                           'Grandparent': lambda x: x.as_posix(),
                           'Relative Path': lambda x: x.as_posix(),
                           'Permissions': lambda x: oct(x)[2:],
                           'Size': lambda x: FileDialog.format_file_size(x), 
                           'Last Accessed': lambda x: f'{x[1]}',
                           'Last Modified': lambda x: f'{x[1]}',
                           'Creation Time': lambda x: f'{x[1]}'}
    
    file_info_desired = {'File': lambda x: x,
                         'Parent': lambda x: x.parent,
                         'Grandparent': lambda x: x.parent.parent,
                         'Relative Path': lambda x: x.relative_to(x.parent.parent),
                         'Name': lambda x: x.name,
                         'Stem': lambda x: x.stem,
                         'Suffix': lambda x: FileDialog.parse_file_suffix(x),
                         'Is File': lambda x: x.is_file(),
                         'Is Dir': lambda x: x.is_dir(),
                         'Permissions': lambda x: x.stat().st_mode,
                         'File ID': lambda x: x.stat().st_ino,
                         'Size': lambda x: x.stat().st_size,
                         'Formatted Size': lambda x: FileDialog.format_file_size(x.stat().st_size),
                         'Last Accessed': lambda x: (x.stat().st_atime, datetime.datetime.fromtimestamp(x.stat().st_atime)),
                         'Last Modified': lambda x: (x.stat().st_mtime, datetime.datetime.fromtimestamp(x.stat().st_mtime)),
                         'Creation Time': lambda x: (x.stat().st_birthtime, datetime.datetime.fromtimestamp(x.stat().st_birthtime)),
                         'File Type': lambda x: FileDialog.determine_file_type(x)}

    file_info_list = ['Relative Path', 'Name', 'Suffix', 'Size', 'Formatted Size', 'Last Modified']

    column_names_to_index = {'File': 0,
                             'Parent': 1,
                             'Grandparent': 2,
                             'Relative Path': 3,
                             'Name': 4,
                             'Stem': 5,
                             'Suffix': 6,
                             'Is File': 7,
                             'Is Dir': 8,
                             'Permissions': 9,
                             'File ID': 10,
                             'Size': 11,
                             'Formatted Size': 11,
                             'Last Accessed': 13,
                             'Last Modified': 14,
                             'Creation Time': 15,
                             'File Type': 16}

    def format_file_size(f_size):
        if float(f_size) == 0.0:
            f_size_power_of_ten = 0.0
        else:
            f_size_power_of_ten = np.floor(np.log10(float(f_size)))
        f_size_suffix = FileDialog.size_string_dict[f_size_power_of_ten]
        f_size_string = ''.join(f'{fs} ' for fs in [float(np.round(float(f_size) / np.pow(10, f_size_power_of_ten), decimals = 3)), f_size_suffix])
        return f_size_string.rstrip()

    def format_file_info_string(file_info_dict):
        info_string = ''
        for key, value in file_info_dict.items():
            info_string = f'{info_string}\n{key:<16}: {value}'
        
        return info_string
    
    def parse_file_suffix(file_path:Path):
        if file_path.is_file():
            for file_extension in FileDialog.file_type_dict.keys():
                if len(file_path.name.split(file_extension)[-1]) == 0:
                    return file_extension
                else:
                    return file_path.suffix
        else:
            return ''
    
    def determine_file_type(file_path:Path):
        if file_path.is_file():
            suffix = FileDialog.parse_file_suffix(file_path)
            match suffix:
                case '.mat':
                    return 'mat'
                case '.h5':
                    return 'hdf5'
                case '.hdf5':
                    return 'hdf5'
                case '.dcm':
                    return 'dicom'
                case '.nii':
                    return 'nifti'
                case '.nii.gz':
                    return 'nifti'
                case _:
                    return suffix
                
        elif file_path.is_dir():
            return 'dir'
        
        return ''

    def __init__(self, path):
        self.current_directory = path
        self.current_directory_file_dict = {}
        self.selected_files_dict = {}
        self.file_extension_dict = {"All Files (.*)": [['.'], []],
                                    "Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)": [['.mat', '.dcm', '.h5', '.hdf5', '.nii', '.nii.gz'], []],
                                    "MATLab Files (.mat)": [['.mat'], []],
                                    "DICOM Files (.dcm)": [['.dcm'], []],
                                    "HDF5 Files (.h5, .hdf5)": [['.h5', '.hdf5'], []],
                                    "Nifti Files (.nii, .nii.gz)": [['.nii', '.nii.gz'], []]}
        self.parse_files_in_path(self.current_directory)
        
        self.table_row_index_to_tag = {} # Row index: row_tag
        self.table_row_tag_to_index = {} # Row_tag: row_index

        self.separator = '|'
        self.dpg_items = []
        self.file_table_columns = ['Name', 'Formatted Size', 'Last Modified', 'Suffix']
        self.file_dialog_table_tag = self.create_tag('Table', 'FileDialog')
        self.chosen_files_table_tag = self.create_tag('Table', 'ChosenFiles')
        self.item_handler_registry_tag = self.create_tag('ItemHandlerRegistry', 'TableRows')
        self.double_click_handler_tag = self.create_tag('DoubleClickHandler', 'TableRows')
        self.single_click_handler_tag = self.create_tag('SingleClickHandler', 'TableRows')
        self.hover_handler_tag = self.create_tag('HoverHandler', 'TableRows')
        self.value_registry_tag = self.create_tag('ValueRegistry', 'Strings')
        self.selected_rows_info_string = ''
        self.selected_rows_info_text_tag = self.create_tag('Text', 'SelectedRowsInfo')
        self.selected_rows_info_string_value_tag = self.create_tag('StringValue', 'SelectedRowsInfo')
        self.selected_rows_dict = {}
        self.directory_theme = self.create_tag('Theme', 'DirectoryTheme')
        self.mat_theme = self.create_tag('Theme', 'MatTheme')
        self.hdf5_theme = self.create_tag('Theme', 'HDF5Theme')
        self.nifti_theme = self.create_tag('Theme', 'NiftiTheme')
        self.dicom_theme = self.create_tag('Theme', 'DicomTheme')
        self.theme_dict = {'dir': self.directory_theme,
                           'mat': self.mat_theme,
                           'hdf5': self.hdf5_theme,
                           'dicom': self.dicom_theme,
                           'nifti': self.nifti_theme}
        self.default_table_size = [0.5, 0.1, 0.275, 0.125]

    def __del__(self):
        dpg.destroy_context()

    def bind_theme_value(self, item, file_dict):
        file_type = file_dict['File Type']
        if file_type in self.theme_dict.keys():
            dpg.bind_item_theme(item, self.theme_dict[file_type])

    def open_window(self, debug = False):
        
        dpg.create_context()
        if debug:
            # dpg.show_style_editor()
            dpg.show_debug()
            dpg.show_item_registry()

        with dpg.item_handler_registry(tag = self.item_handler_registry_tag):
            dpg.add_item_double_clicked_handler(button = dpg.mvMouseButton_Left, tag = self.double_click_handler_tag, callback = self.change_current_directory)
            dpg.add_item_clicked_handler(button = dpg.mvMouseButton_Left, tag = self.single_click_handler_tag, callback = self.item_single_clicked)
            # dpg.add_item_hover_handler(tag = self.hover_handler_tag, callback = self.change_row_color)

        with dpg.value_registry(tag = self.value_registry_tag):
            dpg.add_string_value(default_value = self.selected_rows_info_string, tag = self.selected_rows_info_string_value_tag)

        dpg.add_theme(tag = self.directory_theme)

        with dpg.theme_component(dpg.mvSelectable, parent = self.directory_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [220, 0, 40])

        dpg.add_theme(tag = self.mat_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.mat_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [220, 220, 40])

        dpg.add_theme(tag = self.hdf5_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.hdf5_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [0, 220, 40])

        dpg.add_theme(tag = self.nifti_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.nifti_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [40, 220, 220])

        dpg.add_theme(tag = self.dicom_theme)
        with dpg.theme_component(dpg.mvSelectable, parent = self.dicom_theme):
            dpg.add_theme_color(dpg.mvThemeCol_Text, [40, 220, 0])

        with dpg.window(label='Custom File Dialog', tag = 'root', 
                        width = -1, height = 720,
                        menubar = True) as win:
            with dpg.group(horizontal=True, tag = 'file_dialog_group'):
                with dpg.child_window(tag = 'current_directory_contents', width = 720, height = 350):
                    with dpg.group(horizontal = True, tag = 'file_dialog_go_up_group'):
                        dpg.add_button(label = '', width = 50, height = 50, tag = 'file_dialog_button_go_up_directory', 
                                       arrow = True, direction = dpg.mvDir_Up,
                                       callback = self.change_current_directory)
                        dpg.add_text(f'{self.current_directory}', tag = 'current_directory_text')
                    with dpg.table(tag = self.file_dialog_table_tag, 
                                   sortable = True, 
                                   sort_multi = True, 
                                   header_row = True, 
                                   freeze_rows = 1,
                                   callback = self.sort_files_callback,
                                   user_data = self.current_directory_file_dict,
                                   resizable = True, 
                                   width = -1, 
                                   height = 275, 
                                   scrollY = True):
                        
                        dpg.add_table_column(label = 'Name', tag = 'Name', init_width_or_weight = self.default_table_size[0])
                        dpg.add_table_column(label = 'Size', tag = 'Size', init_width_or_weight = self.default_table_size[1])
                        dpg.add_table_column(label = 'Last Modified', tag = 'Last Modified', init_width_or_weight = self.default_table_size[2])
                        dpg.add_table_column(label = 'Extension', tag = 'Suffix', init_width_or_weight = self.default_table_size[3])

                    self.populate_table_rows(self.file_dialog_table_tag, self.current_directory_file_dict)
                    self.bind_table_rows(self.item_handler_registry_tag, self.file_dialog_table_tag)

                    with dpg.group(horizontal = True, tag = self.create_tag('HorizontalGroup', 'FileSelectionParams')):
                        tag = self.create_tag('ComboBox', 'FileExtensions')
                        dpg.add_combo(items = list(self.file_extension_dict.keys()), 
                                      tag = tag,
                                      width = -0, default_value = list(self.file_extension_dict.keys())[0],
                                      callback = self.filter_table_results_callback)
                        dpg.add_button(label = 'Deselect All', tag = self.create_tag('Button', 'DeselectAll'),
                                       width=-1, callback = self.deselect_all)
                with dpg.child_window(tag = 'chosen_file_info', width = 940, height = 350, 
                                      resizable_x = True, horizontal_scrollbar = True):
                    dpg.add_text(default_value = '', 
                                 source = self.selected_rows_info_string_value_tag, 
                                 tag = self.selected_rows_info_text_tag)

            with dpg.child_window(tag = 'chosen_files_group', width = 720, height = 350):
                with dpg.table(tag = self.chosen_files_table_tag, resizable = True, width = -1, height = 275, scrollY = True):
                    dpg.add_table_column(label = 'Name', tag = 'Chosen|Name', init_width_or_weight = self.default_table_size[0])
                    dpg.add_table_column(label = 'Size', tag = 'Chosen|Size', init_width_or_weight = self.default_table_size[1])
                    dpg.add_table_column(label = 'Last Modified', tag = 'Chosen|Last Modified', init_width_or_weight = self.default_table_size[2])
                    dpg.add_table_column(label = 'Extension', tag = 'Chosen|Suffix', init_width_or_weight = self.default_table_size[3])

        dpg.create_viewport(title='Custom File Dialog', width = 1720, height = 1080, x_pos = 10, y_pos = 10)
        dpg.setup_dearpygui()
        dpg.set_primary_window(win, True)
        dpg.show_viewport()
        dpg.start_dearpygui()

        dpg.destroy_context()
        
    def close(self):
        dpg.destroy_context()

    def multisort(self, x_list, sort_specs, make_copy = True, return_sorted_list = False):
        if make_copy:
            return_list = [val for val in x_list]
        else:
            return_list = x_list
    
        # Reverse sort specs so we work our way out of the sorting appropriately, 
        # where we sort the last key first. 
        
        for index, reverse in reversed(sort_specs):
            return_list.sort(key = itemgetter(index), reverse = reverse <= 0)
    
        new_indices = []
        
        for new_index, row_tuple in enumerate(return_list):
            new_indices.append(row_tuple[-2]) # internal dpg item number, row id
        
        if return_sorted_list:
            return return_list, new_indices
        else:
            return new_indices

    def sort_files_callback(self, sender, app_data, user_data):
        """
        sender: Table|FileDialog, etc
        app_data:
            no sorting -> app_data == None
            single sorting -> app_data = [[column_id, direction]]
            multi sorting -> app_data = [[column_id, direction], [column_id, direction], ... ]
            direction == +1 -> ascending
            direction == -1 -> descending
        user_data: self.current_directory_file_dict or similar
        """

        print(f'Sort files callback:\n{sender = }\n{app_data = }')
    
        if app_data is None: 
            return
    
        sort_columns = []
        s_specs = []
        values_to_sort = []
        for child_index, child in enumerate(dpg.get_item_children(sender, 1)):
            file_id = dpg.get_item_alias(child).split('|')[1]
            c_list = [value for value in user_data[file_id].values()]
            c_list.extend([child, child_index])
            values_to_sort.append(c_list)

        for a_data in app_data:
            alias = dpg.get_item_alias(a_data[0])
            col_number = FileDialog.column_names_to_index[alias]
            
            sort_columns.append([alias, '\u2191' if a_data[1] > 0 else '\u2193'])
            s_specs.append([col_number, a_data[1]])

        logger_info = f'Sorting file dialog: {sender = }, {app_data = }, {sort_columns = }'

        sorted_indices = self.multisort(values_to_sort, s_specs, make_copy = True, return_sorted_list = False)
        
        dpg.reorder_items(sender, 1, sorted_indices)
    

    def filter_table_results_callback(self, sender, app_data):
        # app_data = "Nifti Files (.nii, .nii.gz)" or other key in self.file_extension_dict
        # self.file_extension_dict[app_data][1] this is a list of files matching the appropriate extension.
        for table_row in dpg.get_item_children(self.file_dialog_table_tag, 1):
            # self.table_row_index_to_tag[table_row].split(self.separator)[1] returns rel_path
            if self.table_row_index_to_tag[table_row].split(self.separator)[1] in self.file_extension_dict[app_data][1]:
                dpg.show_item(table_row)
            else:
                dpg.hide_item(table_row)

    
    def get_table_contents(self, parent_table):
        table_contents = {}
        if len(dpg.get_item_children(parent_table, 1)) == 0:
            print(f'No children found in {parent_table}')
            return
        for row_id in dpg.get_item_children(parent_table, 1):
            table_contents[dpg.get_item_alias(row_id)] = dpg.get_item_children(row_id, 1)
            print(f'{row_id = }, {dpg.get_item_alias(row_id) = }, {dpg.get_item_children(row_id, 1) = }')
    

    def populate_table_rows(self, parent_table, file_dict:dict, row_type = 'selectable'):
        """
        file_dict -> None or file dictionary to add as rows.
        """
        # if type(file_dict) == type(None):
        #     file_dict = dict(**self.current_directory_file_dict)

        for file_id in file_dict.keys():
            row_tag = self.create_tag('TableRow', f'{file_id}', suffix = parent_table)
            with dpg.table_row(tag = row_tag, parent = parent_table):
                self.table_row_index_to_tag[dpg.last_item()] = row_tag
                self.table_row_tag_to_index[row_tag] = dpg.last_item()
                self.bind_theme_value(row_tag, file_dict[file_id])
                for f_info in self.file_table_columns: # [Name', 'Formatted Size', 'Last Modified', 'Extension']
                    tag = self.create_tag('SelectableRow', f'{file_id}', suffix = f'{parent_table}{self.separator}{f_info}')
                    dpg.add_selectable(label = f'{file_dict[file_id][f_info]}',
                                       tag = tag,
                                       user_data = (file_id, file_dict[file_id]),
                                       span_columns = True,
                                       callback = self.update_selected_rows)
    
    def bind_table_rows(self, handler, table_tag):
        # print(f'Binding items to {handler = }.')
        for row in dpg.get_item_children(table_tag, 1):
            if len(dpg.get_item_children(row, 1)) > 0:
                for row_child in dpg.get_item_children(row, 1):
                    # print(f'\tBinding {row_child = }, {dpg.get_item_alias(row_child) = }, {dpg.get_item_type(row_child) = }')
                    dpg.bind_item_handler_registry(row_child, handler)


    def reset_table_rows(self, parent_table):
        dpg.delete_item(parent_table, children_only = True, slot = 1)
    

    def item_single_clicked(self, sender, app_data, user_data):
        print(f'Single item clicked!\n----------\n{sender = }\n{app_data = }\n{user_data = }\n----------')


    def refresh_current_directory(self):

        self.reset_table_rows(self.file_dialog_table_tag)

        self.current_directory_file_dict.clear()
        self.table_row_tag_to_index.clear()
        self.table_row_index_to_tag.clear()

        self.parse_files_in_path(self.current_directory) # self.current_directory_file_dict, self.file_extension_dict
        self.populate_table_rows(self.file_dialog_table_tag, self.current_directory_file_dict)
        self.bind_table_rows(self.item_handler_registry_tag, self.file_dialog_table_tag)

        for file_id in self.selected_rows_dict.keys():
            for table_row in self.table_row_tag_to_index.keys():
                if file_id in table_row:
                    dpg_id = self.table_row_tag_to_index[table_row]
                    # We only need the first column since that selectable covers the entire row. 
                    for row_child in dpg.get_item_children(dpg_id, 1)[:1]:
                        dpg.set_value(row_child, True)


    def change_current_directory(self, sender, app_data, user_data):

        if sender == 'file_dialog_button_go_up_directory':
            self.current_directory = self.current_directory.parent

        else:
            item_tag = dpg.get_item_alias(app_data[1])
            rel_path = item_tag.split('|')[1]
            if self.current_directory_file_dict[rel_path]['Is Dir']:
                self.current_directory = Path(self.current_directory_file_dict[rel_path]['File'])
            else:
                return
 
        print(f'{sender = }\n{app_data = }\n{user_data = }\n{self.current_directory = }')
        dpg.set_value('current_directory_text', f'{self.current_directory}')

        self.refresh_current_directory()
    

    def update_selected_rows(self, sender, app_data, user_data):
        """
        sender is of form: 'SelectableRow|562949953663636|Name'
        app_data is of form: True
        user_data is of form: (file_id, current_directory_file_dict[file_id])
        """
        self.selected_rows_info_string = ''

        print(f'Updating row {sender}')

        file_id, file_dict = user_data

        if app_data and (file_id not in self.selected_rows_dict.keys()):
            self.selected_rows_dict[file_id] = file_dict

        if (not app_data) and (file_id in self.selected_rows_dict.keys()):
            # print(f'Removing {sender} from selected_rows_dict')
            self.selected_rows_dict.pop(file_id, None)
            self.selected_files_dict.pop(file_id, None)
        
        for selected_row_key in self.selected_rows_dict.keys():
            formatted_file_info = FileDialog.format_file_info_string(self.selected_rows_dict[selected_row_key])
            self.selected_rows_info_string = f'{self.selected_rows_info_string}{"-"*50}{formatted_file_info}\n'

        dpg.set_value(self.selected_rows_info_string_value_tag, self.selected_rows_info_string)
        
        self.update_selected_files(self.selected_rows_dict)
        self.reset_table_rows(self.chosen_files_table_tag)
        self.populate_table_rows(self.chosen_files_table_tag, self.selected_files_dict)
        self.bind_table_rows(self.item_handler_registry_tag, self.chosen_files_table_tag)


    def update_selected_files(self, selected_row_dict):
        for key, value in selected_row_dict.items():
            if value['Is File']:
                self.selected_files_dict[key] = value
    

    def deselect_all(self):
        self.selected_rows_dict.clear()
        self.selected_files_dict.clear()

        self.selected_rows_info_string = ''

        for row_id in dpg.get_item_children(self.file_dialog_table_tag, 1):
            for row_child in dpg.get_item_children(row_id, 1):
                dpg.set_value(row_child, False)

        for row_id in dpg.get_item_children(self.chosen_files_table_tag, 1):
            dpg.delete_item(row_id, slot = 1)

        dpg.set_value(self.selected_rows_info_string_value_tag, self.selected_rows_info_string)


    def create_tag(self, dpg_object_designation: str, tag_name: str, separator: str = '|', suffix: str = ''):
        """
        dpg_object_name <separator> tag_name <separator> suffix
        dpg_object, tag_name, suffix = tag.split(separator)
        """
        
        tag = f'{dpg_object_designation}{separator}{tag_name}{separator}{suffix}' if suffix != '' else f'{dpg_object_designation}{separator}{tag_name}'
        
        return tag

    
    def get_file_info(self, filepath: Path, format_file_info = True, exclude = ['Size']):
        """
        Exclude can be:
            'File'
            'Parent'
            'Grandparent'
            'Relative Path'
            'Permissions'
            'Size'
            'Last Accessed'
            'Last Modified'
            'Creation Time'
        """
        f_info_dict = {}
        for f_info in FileDialog.file_info_desired.keys():
            f_info_dict[f_info] = FileDialog.file_info_desired[f_info](filepath)
        if format_file_info:
            for f_info in FileDialog.file_info_formatter.keys():
                if f_info in exclude:
                    continue
                else:
                    f_info_dict[f_info] = FileDialog.file_info_formatter[f_info](f_info_dict[f_info])
            
        return f_info_dict
    
    
    def parse_files_in_path(self, path: Path):
        
        for file in path.glob('*'):
            file_id = file.stat().st_ino
            self.current_directory_file_dict[f'{file_id}'] = self.get_file_info(file, format_file_info = True, exclude = ['Size'])
            match self.current_directory_file_dict[f'{file_id}']['Suffix']:
                case '.mat':
                    self.file_extension_dict["MATLab Files (.mat)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
                case '.dcm':
                    self.file_extension_dict["DICOM Files (.dcm)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
                case '.h5' | '.hdf5':
                    self.file_extension_dict["HDF5 Files (.h5, .hdf5)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
                case '.nii' | '.nii.gz': 
                    self.file_extension_dict["Nifti Files (.nii, .nii.gz)"][1].append(f'{file_id}')
                    self.file_extension_dict["Image Files (.mat, .dcm, .h5, .hdf5, .nii, .nii.gz)"][1].append(f'{file_id}')
        
        self.file_extension_dict["All Files (.*)"][1].extend(list(self.current_directory_file_dict.keys()))
        
        return

    
    def parse_selected_file(self, path: Path):
        pass

    def parse_h5_file(self, h5_path: Path):
        pass

    def parse_mat_file(self, mat_path: Path):
        pass

    def parse_nifti_file(self, nifti_path: Path):
        pass

    def parse_dcm_directory(self, dcm_path: Path):
        pass

    def parse_dcm_file(self, dcm_path: Path):
        pass


class FileParser(object):
    def __init__(self):
        pass

    def parse_h5_file(self):
        pass

    def parse_mat_file(self):
        pass

    def parse_dicom_files(self):
        pass

    def parse_nifti_file(self):
        pass