from .Globals import *
from . import OptionValue
from . import CTVolume
from . import Textures
from . import Landmarks

class VolumeLayer(object):
    """
    default_orientation = [0, 0, 0, 0, 0, 0] -> [origin_x, origin_y, norm, pitch, yaw, roll]
    
    """

    mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
    mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: x
    mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
    mode_value = lambda x: getattr(cp, x.__str__()) if G.GPU_MODE else getattr(np, x.__str__())
    cp_to_np = lambda x: cp.asnumpy(x) if G.GPU_MODE else lambda x: x
    np_to_cp = lambda x: cp.asarray(x) if G.GPU_MODE else lambda x: x


    def __init__(self, 
                 group, 
                 ctvolume: CTVolume.CTVolume,
                 volume_name: str = None, 
                 default_orientation = [0, 0, 0, 0, 0, 0], 
                 default_quaternion = G.QTN_DICT[G.VIEW], 
                 default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire', 'Linear'], # Min, Max, Colormap, Colormap Name, Colormap Scale
                 default_histogram = [0, 1200, 1, 'Linear'], # Bins min, max, step, scale
                 default_limits_origin = [-350, 350],
                 default_limits_norm = [-350, 350], 
                 default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]],
                 default_drawlayer_tag = ''):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.group:VolumeLayerGroup = group
        self.ctvolume:CTVolume.CTVolume = ctvolume
        self.pixel_steps:list[float,float,float] = [1.0*p_dim for p_dim in ctvolume.pixel_steps]
        self.name:str = self.ctvolume.name if volume_name is not None else volume_name
        self.file:Path = self.ctvolume.file
        self.group_name:str = self.group.group_name

        self.intensity_limits = default_limits_intensity
        self.control_list = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll', 'min_intensity', 'max_intensity', 'colormap']
        self.orientation_control_list = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll', 'pixel_spacing_x', 'pixel_spacing_y', 'slice_thickness']
        self.intensity_control_list = ['min_intensity', 'max_intensity'] #, colormap]
        self.geometry_control_list = ['pixel_spacing_x', 'pixel_spacing_y', 'slice_thickness']
        self.histogram_control_list = ['min_value', 'max_value', 'step', 'scale']
        self.texture_control_list = ['zoom_level']
        self.orientation_control = G.DEFAULT_GROUP_LAYER_CONTROL
        self.intensity_control = G.DEFAULT_GROUP_LAYER_CONTROL
        self.geometry_control = 'Layer'
        self.is_volume_viewed = False
        
        
        self.layer_control = []
        self.group_control = [control_option for control_option in self.control_list]
        
        self.orientation: OptionValue.OrientationInfo = OptionValue.OrientationInfo(tag = f'{self.name}|VolumeLayer|Orientation',
                                                                                    default_orientation = default_orientation, 
                                                                                    default_quaternion = default_quaternion, 
                                                                                    default_geometry = ctvolume.pixel_steps,
                                                                                    default_limits_origin = default_limits_origin,
                                                                                    default_limits_norm = default_limits_norm,
                                                                                    default_limits_geometry = [0.25, 10.0],
                                                                                    default_texture_dim = G.TEXTURE_DIM, #self.ctvolume.texture_dim,
                                                                                    default_texture_center = G.TEXTURE_CENTER, #self.ctvolume.texture_center)
                                                                                    default_drawlayer_tag = default_drawlayer_tag)
        
        self.intensity: OptionValue.IntensityInfo = OptionValue.IntensityInfo(tag = f'{self.name}|VolumeLayer|Intensity',
                                                                              default_intensity = default_intensity, 
                                                                              default_limits = default_limits_intensity)
        
        #TODO fill out saved points variable. This will be a record of Orientation and Intensity objects
        # that are associated with a custom tag
        self.saved_points = {} # dict of form {tag_1: [OrientationInfo, IntensityInfo], 
                               #               ...}

        # self.geometry = OptionValue.GeometryInfo(default_geometry = ctvolume.pixel_steps,
        #                                          default_limits = [0.25, 10.0])

        # print(self.geometry)
        
        self.histogram: OptionValue.HistogramInfo = OptionValue.HistogramInfo(default_histogram = default_histogram)

        self.view_plane: OptionValue.ViewPlane = self.orientation.view_plane
        self.interpolator: RegularGridInterpolator = self.ctvolume.interpolator
        self.mask_interpolator = self.ctvolume.mask_interpolator
        self.volume_center = self.ctvolume.volume_center
        self.volume_shape = self.ctvolume.shape
        self.texture_dim = G.TEXTURE_DIM # self.ctvolume.texture_dim

        self.colormap = self.intensity.colormap
        self.colormap_name = self.intensity.colormap_name
        self.colormap_string = self.intensity.get_colormap_string()
        self.colormap_reversed = self.intensity.colormap_reversed

        self.landmarks:Landmarks.Landmarks = Landmarks.Landmarks(self)
        
        self.landmark_points = {} # Landmark_Index : Landmark_Dict

        self.n_landmarks = 0

        self.texture: Textures.Texture = Textures.Texture(self.ctvolume, 
                                                          create_tag('NewMainView', 
                                                                     'DrawList', 
                                                                     'TextureDrawList'))

        self.interpolate_texture()
        self.window_and_normalize_texture()
        self.texture.update_draw_image()
        self.assign_texture()
        self.texture.create_static_texture()
        
    def add_landmark(self, image_coords, viewport_coords = None, viewport_loc = None, color = dpg.get_value('landmark_color_picker'),
                     size = 2, show_landmark = True, parent = G.MAIN_PLOT_VIEW):
        self.landmarks.add_landmark(image_coords, viewport_coords = viewport_coords, viewport_loc = viewport_loc,
                                    color = color, size = size, show_landmark = show_landmark, parent = parent)
        
        
        #self.transformation_history = [] # inverse_rotation, current_origin_vector, current_origin_difference, current_norm_direction

    def set_texture(self):
        self.texture = Textures.Texture(self.ctvolume)


    def set_ctvolume(self, volume_name:str, volume_data:CTVolume.CTVolume):
        self.ctvolume = volume_data
        self.name = self.ctvolume.name if volume_name is not None else volume_name
        self.file = self.ctvolume.file


    def set_is_volume_viewed(self, volume_viewed_bool:bool = False):
        self.is_volume_viewed = volume_viewed_bool


    def add_to_group(self, group: "VolumeLayerGroup"):
        if self.name not in group.volume_names:
            group.set_volume(self)

    def update_all(self, 
                   orientation_info: dict, 
                   intensity_info: dict):
        
        with dpg.mutex():
            print(f'VolumeLayer Message: Updating Orientation')
            self.update_orientation(**orientation_info)
            print(f'VolumeLayer Message: Updating Intensity')
            self.update_intensity(**intensity_info)
            print(f'VolumeLayer Message: Updating Texture')
            self.update_texture()
            dpg.set_value('OptionPanel_quaternion_display', 
                          self.print_orientation_value('quaternion'))
            dpg.set_value('OptionPanel_origin_vector_display', 
                          self.print_orientation_value('origin_vector'))
            dpg.set_value('OptionPanel_norm_vector_display', 
                          self.print_orientation_value('norm_vector'))


    def set_control_options(self, option_class:str, update:bool = False):
        
        if option_class not in ['geometry', 'orientation', 'intensity']:
            print(f'VolumeLayer Message: Option class {option_class} not recognized. Only "orientation" or "intensity" accepted.')
            return

        for control_option_name in getattr(self, f'{option_class}_control_list'):
            option_tag = G.OPTION_TAG_DICT[control_option_name]
            if getattr(self, f'{option_class}_control') == 'Group':
                control_option = getattr(getattr(self.group, option_class), control_option_name)
            else:
                control_option = getattr(getattr(self, option_class), control_option_name)
            if not update:
                dpg.configure_item(option_tag, min_value = control_option.limit_low, 
                                   max_value = control_option.limit_high, 
                                   default_value = control_option.default_value)
            dpg.set_value(f'{option_tag}_current_value', control_option.current_value)
            dpg.set_value(option_tag, control_option.current_value)


    def get_attribute(self, attribute_name: str):
        if attribute_name not in list(self.__dict__.keys()):
            print(f'VolumeLayer Message: {attribute_name} not in {self.name}.')
            return
        return getattr(self, attribute_name)
    
    
    def set_attribute(self, attribute_name, attribute_value, make_copy = True):
        setattr(self, attribute_name, attribute_value)
    
    
    def reset_orientation(self):
        if self.orientation_control == 'Group':
            self.group.orientation.reset_orientation()

        else:
            self.orientation.reset_orientation()

    def update_intensity(self, 
                         colormap_name: str = None,
                         colormap_reversed: bool = None,
                         min_intensity: float | int = None,
                         max_intensity: float | int = None,
                         window_size: float | int = 1, 
                         colormap_rescaled: bool = None,
                         colormap_scale_type: str = '',
                         colormap_scale_tag: str = ''):
        
        print(f'VolumeLayer Message: Updating Colormap')
        self.update_colormap(colormap_name = colormap_name,
                             colormap_reversed = colormap_reversed,
                             colormap_scale_type = colormap_scale_type,
                             colormap_scale_tag = colormap_scale_tag,
                             colormap_rescaled = colormap_rescaled)
        
        print(f'VolumeLayer Message: Updating Window')                     
        self.update_window(min_intensity = min_intensity,
                           max_intensity = max_intensity,
                           window_size = window_size)

    def update_orientation(self, **kwargs):
        if self.orientation_control == 'Group':
            self.group.orientation.update_orientation(**kwargs)
        
        else:
            self.orientation.update_orientation(**kwargs)

        print(f'VolumeLayer Message: Update Orientation: {self.orientation.geometry_vector = }')

    
    # def reset_geometry(self):
    #     self.geometry.reset_geometry()
    

    # def update_geometry(self):
    #     self.geometry.update_geometry()
    #     self.pixel_steps = self.geometry.get_pixel_steps()

    def update_colormap(self, 
                        colormap_name: str = None,
                        colormap_reversed: bool = None,
                        colormap_scale_tag: str = None,
                        colormap_scale_type: str = None,
                        colormap_rescaled: bool = None):
        
        if self.intensity_control == 'Group':
            self.group.intensity.update_colormap(colormap_name = colormap_name,
                                                 colormap_reversed = colormap_reversed, 
                                                 colormap_scale_type = colormap_scale_type,
                                                 colormap_scale_tag = colormap_scale_tag,
                                                 colormap_rescaled = colormap_rescaled)
        else:
            self.intensity.update_colormap(colormap_name = colormap_name,
                                           colormap_reversed = colormap_reversed, 
                                           colormap_scale_type = colormap_scale_type,
                                           colormap_scale_tag = colormap_scale_tag,
                                           colormap_rescaled = colormap_rescaled)
        
        self.colormap = self.intensity.colormap
        self.colormap_reversed = self.intensity.colormap_reversed
        self.colormap_name = self.intensity.colormap_name
        self.colormap_string = self.intensity.get_colormap_string()


    def update_window(self, 
                      min_intensity: float|int = None, 
                      max_intensity: float|int = None, 
                      window_size: float|int = 1): #np.min([dpg.get_value(f'{G.OPTIONS_DICT["min_intensity_slider"]["slider_tag"]}_increment_input_float'),
                                       #     dpg.get_value(f'{G.OPTIONS_DICT["max_intensity_slider"]["slider_tag"]}_increment_input_float')])):

        if min_intensity == None:
            min_intensity = dpg.get_value(G.OPTION_TAG_DICT['min_intensity'])
        if max_intensity == None:
            max_intensity = dpg.get_value(G.OPTION_TAG_DICT['max_intensity'])

        print(f'VolumeLayer Message: update_window: {min_intensity = }, {max_intensity = }, {window_size = }')

        if self.intensity_control == 'Group':
            self.group.intensity.update_window(min_intensity, max_intensity, window_size)
        else:
            self.intensity.update_window(min_intensity, max_intensity, window_size)


    def set_dpg_window(self):
        if self.intensity_control == 'Group':
            dpg.set_value(G.OPTION_TAG_DICT['min_intensity'], self.group.intensity.min_intensity.current_value)
            dpg.set_value(G.OPTION_TAG_DICT['max_intensity'], self.group.intensity.max_intensity.current_value)
            
        else:
            dpg.set_value(G.OPTION_TAG_DICT['min_intensity'], self.intensity.min_intensity.current_value)
            dpg.set_value(G.OPTION_TAG_DICT['max_intensity'], self.intensity.max_intensity.current_value)

    def set_colormap_scale_tag(self, 
                               colormap_scale_tag: str):
        self.intensity.set_colormap_scale_tag(colormap_scale_tag)
        self.texture.set_colormap_scale_tag(colormap_scale_tag)

    def set_drawlayer_tag(self, 
                         drawlayer_tag: str):
        self.orientation.set_drawlayer_tag(drawlayer_tag)

    def update_texture(self):
        
        # colormap = self.intensity.colormap
        # colormap_scale_type = self.intensity.colormap_scale_type
        # colormap_scale_tag = self.intensity.colormap_scale_tag
        # x_shift = self.orientation.origin_x
        # y_shift = self.orientation.origin_y
        pixel_start = [0, 0]
        pixel_end = [G.TEXTURE_DIM, G.TEXTURE_DIM]
        uv_min = [0, 0]
        uv_max = [1, 1]
        # drawlist = self.orientation.drawlayer

        if self.orientation_control == 'Group':
            x_shift = self.group.orientation.origin_x.current_value
            y_shift = self.group.orientation.origin_y.current_value
            drawlayer = self.group.orientation.drawlayer.current_value

        else:
            x_shift = self.orientation.origin_x.current_value
            y_shift = self.orientation.origin_y.current_value
            drawlayer = self.orientation.drawlayer.current_value

        if self.intensity_control == 'Group':
            colormap = self.group.intensity.colormap
            colormap_scale_tag = self.group.intensity.colormap_scale_tag.current_value
            colormap_scale_type = self.group.intensity.colormap_scale_type.current_value

        else:
            colormap = self.intensity.colormap
            colormap_scale_tag = self.intensity.colormap_scale_tag.current_value
            colormap_scale_type = self.intensity.colormap_scale_type.current_value

        self.interpolate_texture()
        self.texture.update_texture(colormap = colormap,
                                    colormap_scale_type = colormap_scale_type,
                                    colormap_scale_tag = colormap_scale_tag,
                                    x_shift = x_shift,
                                    y_shift = y_shift,
                                    pixel_start = pixel_start,
                                    pixel_end = pixel_end,
                                    uv_min = uv_min,
                                    uv_max = uv_max,
                                    drawlist = drawlayer)


    def update_control(self):
        
        # This will make it so we copy the group intensity to the current volume when 
        # we go from Layer -> Group, aligning the layer to the Group it, and from Group -> Layer, 
        # making the Layer independent of the Group. 
        if G.FILE_LOADED:
            self.orientation.copy_orientation(self.group.orientation)
            self.intensity.copy_intensity(self.group.intensity)
            self.histogram.copy_histogram(self.group.histogram)
            
        self.orientation_control = dpg.get_item_label(f'orientation_{G.GROUP_LAYER_CONTROL_BUTTON}')
        self.intensity_control = dpg.get_item_label(f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}')
        self.histogram_control = dpg.get_item_label(f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}')


    def window_and_normalize_texture(self):
        self.texture.window_and_normalize()


    def assign_texture(self):
        if self.intensity_control == 'Group':
            self.texture.assign_texture(self.group.intensity.colormap)
        else:
            self.texture.assign_texture(self.intensity.colormap)


    def interpolate_texture(self):
        self.texture.texture_content.fill(VolumeLayer.mode_value(np.nan))
        
        if G.GPU_MODE:
            self.interpolate_view(out_array = self.texture.texture_content, 
                                  view_plane = (self.view_plane if self.orientation_control == 'Layer' 
                                                else self.group.orientation.view_plane).current_value.round(decimals = 2))
            
        else:
            print('Must use GPU!')
        
        return
    
    def delete_texture(self):
        self.texture.delete_texture()

    def remove_texture_from_drawlist(self):
        self.texture.delete_drawn_texture()

    def add_texture_to_drawlist(self, 
                                pixel_start:list[float|int, float|int] = [None, None], 
                                pixel_end:list[float|int, float|int] = [None, None],
                                uv_min:list[float|int, float|int] = [0, 0],
                                uv_max:list[float|int, float|int] = [1, 1], 
                                drawlist:str = ''):
        
        if pixel_start == [None, None]:
            pixel_start = [0, 0]

        if pixel_end == [None, None]:
            pixel_end = [self.texture_dim, self.texture_dim]
        
        self.texture.add_texture_to_drawlist(pixel_start = pixel_start,
                                             pixel_end = pixel_end,
                                             uv_min = uv_min,
                                             uv_max = uv_max,
                                             drawlist = drawlist)
       
    def interpolate_view(self, 
                         out_array = None, 
                         out_mask = None, 
                         view_plane = None, 
                         decimals = 2):
        """
        
        """
        if type(out_array) == type(None):
            return self.interpolator(cp.round(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T, decimals = decimals),
                                     method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:]
        
            # return self.ctvolume.interpolate(self.orientation.view_plane, 
            #                                  method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])
         
        else:
            if type(out_mask) == type(None):
                out_array[:] = self.interpolator(cp.round(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T, decimals = decimals),
                                                 method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)
            else:
                out_array[out_mask] = self.interpolator(cp.round(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T, decimals = decimals),
                                                        method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)[out_mask]

    
    def interpolate_mask(self, 
                         out_array = None, 
                         out_mask = None, 
                         view_plane = None):
        if type(out_array) == type(None):
            return self.mask_interpolator(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T,
                                      method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:]
        else:
            if type(out_mask) == type(None):
                out_array[:] = self.mask_interpolator(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T,
                                                      method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)
            else:
                out_array[out_mask] = self.mask_interpolator(self.orientation.view_plane.current_value.T if type(view_plane) == type(None) else view_plane.T,
                                                             method = G.INTERPOLATION_DICT[dpg.get_value('interpolation_combo_box')])[:].reshape(out_array.shape)[out_mask]
    
    def print_orientation_value(self, value: str, check_control = True):
        """
        value: string
            Can be any of the OptionValue.OrientationInfo attributes. 
        """
        if check_control and (self.orientation_control == 'Group'):
            return f"{getattr(self.group.orientation, f'{value}')}"
        
        return f"{getattr(self.orientation, f'{value}')}"

    
    def get_orientation_value(self, value: str, modifier: str = 'current_value', check_control = True):
        """
        value:
        modifier: string
            Can be ['default_value', 'current_value', 'previous_value', 'difference_value']
            Default is 'current_value'
        """

        if check_control and (self.orientation_control == 'Group'):
            return getattr(getattr(self.group.orientation, f'{value}'), f'{modifier}')
        
        return getattr(getattr(self.orientation, f'{value}'), f'{modifier}')
    
    def get_intensity_value(self, value: str, modifier:str, check_control = True):
        
        if check_control and (self.intensity_control == 'Group'):
            return getattr(getattr(self.group.intensity, f'{value}'), f'{modifier}')

        return getattr(getattr(self.intensity, f'{value}'), f'{modifier}')
    
    
    def set_dpg_histogram_values(self):
        dpg.set_value('InfoBoxTab_histogram_volume_bins_min', self.histogram.bins_min())
        dpg.set_value('InfoBoxTab_histogram_volume_bins_max', self.histogram.bins_max())
        dpg.set_value('InfoBoxTab_histogram_volume_bin_step', self.histogram.bin_step())


    def get_histogram(self, update_histogram = True, return_order = 'reversed', asnumpy = True):

        min_enabled = dpg.get_value('InfoBoxTab_histogram_volume_bins_min_checkbox')
        max_enabled = dpg.get_value('InfoBoxTab_histogram_volume_bins_max_checkbox')
        step_enabled = dpg.get_value('InfoBoxTab_histogram_volume_bin_step_checkbox')

        bin_min = dpg.get_value('InfoBoxTab_histogram_volume_bins_min') if min_enabled else None
        bin_max = dpg.get_value('InfoBoxTab_histogram_volume_bins_max') if max_enabled else None
        bin_step = dpg.get_value('InfoBoxTab_histogram_volume_bin_step') if step_enabled else None

        if update_histogram:
            self.histogram.update_histogram_params(min_value = bin_min, max_value = bin_max, bin_step = bin_step)
            self.histogram.update_histogram_counts(self.interpolator.values[~self.mask_interpolator.values.astype(bool)])
        
        return self.histogram.get_histogram(return_order = return_order, asnumpy = asnumpy)


    def set_dpg_histogram_limits(self, 
                                 x_axis, y_axis, unlock_axes = True,
                                 min_x = None, max_x = None, 
                                 min_y = None, max_y = None):
        
        dpg.set_axis_limits(x_axis, 
                            self.histogram.bins_min() if min_x is None else min_x,
                            self.histogram.bins_max() if max_x is None else max_x)
        
        dpg.set_axis_limits(y_axis, 
                            self.histogram.bin_counts().min() if min_y is None else min_y,
                            self.histogram.bin_counts().max() if max_y is None else max_y)
        
        if unlock_axes:
            dpg.set_axis_limits_auto(x_axis)
            dpg.set_axis_limits_auto(y_axis)


    def show_landmarks(self):
        for landmark_dict in self.landmark_points.values():
            dpg.show_item(landmark_dict['viewport_circle'])


    def hide_landmarks(self):
        for landmark_dict in self.landmark_points.values():
            dpg.hide_item(landmark_dict['viewport_circle'])

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_name = attrib_list.pop()
            if attrib_name == 'group':
                setattr(self, attrib_name, None)
                delattr(self, attrib_name)

            elif '_cleanup_' in dir(getattr(self, attrib_name)):
                try:
                    getattr(self, attrib_name)._cleanup_()
                finally:
                    setattr(self, attrib_name, None)
                    delattr(self, attrib_name)
            else:
                setattr(self, attrib_name, None)
                delattr(self, attrib_name)


class VolumeLayerGroup(object):

    """
    Each VolumeLayerGroup can hold volume information, but does not hold any volumes themselves. 
    
    Instead, it holds the orientation and rendering information for each volume in the group:
        
        Origin X
        Origin Y
        Origin Z
        Norm location
        Pitch
        Yaw
        Roll
        Min Intensity
        Max Intensity
        Colormap
        Quatnernion (Current, Previous, Default)
        Drag Points
        
    It can also hold global values for each of the above. The global values do not influence the local values, 
    except when adding a new volume to the group. When selecting between the two, the MainView will simply render 
    the appropriate image and send it to the texture. 
    
    """
    def __init__(self, 
                 group_name, 
                 default_orientation = [0, 0, 0, 0, 0, 0], 
                 default_quaternion = G.QTN_DICT[G.VIEW], 
                 default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire', 'Linear'],
                 default_histogram = [-0.5, 1200.5, 1, 'Linear'], # Bins min, max, step, scale
                 default_limits_origin = [-350, 350],
                 default_limits_norm = [-350, 350],
                 default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]],
                 default_drawlayer_tag = ''):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
        
        self.volume_names:list[str] = []
        self.n_volumes:int = 0
        self.group_name:str = group_name
        self.intensity_limits = default_limits_intensity
        self.control_list:list[str] = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll', 'min_intensity', 'max_intensity', 'colormap']
        self.orientation_control_list:list[str] = ['origin_x', 'origin_y', 'norm', 'pitch', 'yaw', 'roll']
        self.intensity_control_list:list[str] = ['min_intensity', 'max_intensity', 'colormap']
        self.histogram_control_list:list[str] = ['min_value', 'max_value', 'step', 'scale']
        self.current_volume: VolumeLayer = None
        self.volume_reference_dict:dict = {}
        
        self.orientation: OptionValue.OrientationInfo = OptionValue.OrientationInfo(tag = f'{self.group_name}|VolumeLayerGroup|Orientation',
                                                       default_orientation = default_orientation, 
                                                       default_quaternion = default_quaternion, 
                                                       default_limits_origin = default_limits_origin,
                                                       default_limits_norm = default_limits_norm,
                                                       default_drawlayer_tag = default_drawlayer_tag)
        
        self.intensity: OptionValue.IntensityInfo = OptionValue.IntensityInfo(tag = f'{self.group_name}|VolumeLayerGroup|Intensity',
                                                   default_intensity = default_intensity, 
                                                   default_limits = default_limits_intensity)

        self.histogram: OptionValue.HistogramInfo = OptionValue.HistogramInfo(default_histogram = default_histogram)

    def get_volume_by_name(self, volume_name: str) -> VolumeLayer:
        if volume_name not in self.volume_names:
            print(f'VolumeLayer Message: {volume_name} not in {self.group_name}')
            return
        return getattr(self, volume_name)
    
    def get_volume_by_index(self, volume_index: int) -> VolumeLayer:
        if volume_index < 0:
            print(f'VolumeLayer Message: {volume_index} is a negative value!')
            return getattr(self, self.volume_names[0])
        
        if volume_index > self.n_volumes:
            print(f'VolumeLayer Message: {volume_index} larger than number of volumes ({self.n_volumes}) in {self.group_name}!')
            return getattr(self, self.volume_names[-1])
        
        return getattr(self, self.volume_names[volume_index - 1])

    def get_volume_attribute(self, volume_name: str, attribute_name: str):
        return self.get_volume_by_name(volume_name).get_attribute(attribute_name)
    
    def set_volume_attribute(self, volume_name: str, attribute_name: str, attribute_value):
        self.get_volume_by_name(volume_name).set_attribute(attribute_name, attribute_value)

    def set_colormap_scale_tag(self, 
                               colormap_scale_tag: str):
        self.intensity.set_colormap_scale_tag(colormap_scale_tag)

    def set_drawlayer_tag(self, 
                         drawlayer_tag: str):
        self.orientation.set_drawlayer_tag(drawlayer_tag)

    def set_intensity_limits(self):
        for volume in self.volume_names:
            for index in [0, 1]: #[Min, Max]
                if self.intensity_limits[index][0] > self.get_volume_attribute(volume, 'intensity_limits')[index][0]:
                    self.intensity_limits[index][0] = self.get_volume_attribute(volume, 'intensity_limits')[index][0] * 1
            
                if self.intensity_limits[index][1] < self.get_volume_attribute(volume, 'intensity_limits')[index][1]:
                    self.intensity_limits[index][1] = self.get_volume_attribute(volume, 'intensity_limits')[index][1] * 1

    def set_volume(self, volumeLayer: VolumeLayer):
        if volumeLayer.name not in self.volume_names:
            print(f'VolumeLayer Message: Adding Volume {volumeLayer.name} to Group {self.group_name}')
            self.volume_names.append(volumeLayer.name)
            setattr(self, volumeLayer.name, volumeLayer)
        else:
            print(f'VolumeLayer Message: Volume {volumeLayer.name} already in Group {self.group_name}')

    def add_volume(self, 
                   ctvolume:CTVolume.CTVolume,
                   volume_name = None, 
                   default_orientation = [0, 0, 0, 0, 0, 0, 0], 
                   default_quaternion = G.QTN_DICT[G.VIEW], 
                   default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire', 'Linear'], 
                   default_histogram = [0, 1200, 1, 'Linear'], # [min, max, step, scale]
                   default_limits_origin = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER],
                   default_limits_norm = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                   default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]]): # [[min_low, min_high], [max_low, max_high]]

        temp_name = ctvolume.name if volume_name is None else volume_name
        if temp_name in self.volume_names:
            print(f'VolumeLayer Message: Volume {temp_name} already in Group {self.group_name}.')
            return
        
        print(f'VolumeLayer Message: Adding Volume {temp_name} to Group {self.group_name}.')
        
        self.volume_names.append(temp_name)

        setattr(self, temp_name, VolumeLayer(self, # This Group
                                             ctvolume,
                                             volume_name = temp_name,
                                             default_orientation = default_orientation, 
                                             default_quaternion = default_quaternion, 
                                             default_intensity = [0, #ctvolume.rounded_min_max[0], 
                                                                  1200, #ctvolume.rounded_min_max[1], 
                                                                  G.DEFAULT_IMAGE_SETTINGS['colormap'], 
                                                                  'Fire',
                                                                  'Linear'],
                                             default_histogram = [ctvolume.unique_values[0] - ctvolume.histogram_step/2,
                                                                  ctvolume.unique_values[-1] + ctvolume.histogram_step/2, 
                                                                  ctvolume.histogram_step, 
                                                                  'Linear'],
                                             default_limits_origin = default_limits_origin, 
                                             default_limits_norm = default_limits_norm, 
                                             default_limits_intensity = default_limits_intensity))
        self.n_volumes += 1


    def update_view(self):
        pass


    def set_current_volume(self, volume_index):
        self.current_volume: VolumeLayer = self.get_volume_by_index(volume_index)


    def get_orientation_info(self, control_mode = 'Group'):
        if control_mode == 'Group':
            return self.orientation.view_plane(), self.orientation.norm_vector(), self.orientation.norm()
        
        else:
            pass

    def update_current_volume(self, 
                              orientation_info, 
                              intensity_info):
        
        self.current_volume.update_all(orientation_info, 
                                       intensity_info)
        

    def get_intensity_info(self, control_mode = 'Group'):
        pass


    def remove_volume(self, volume_name, clean_up = True):
        print(f'VolumeLayer Message: Removing {volume_name} from Group {self.group_name}.')
        # if volume_name == self.current_view_volume.name:
        #     pass
        # Doing this so we can simply use this function in remove_all_volumes below.
        if volume_name in self.volume_names:
            self.volume_names.remove(volume_name)

        if clean_up:
            getattr(self, volume_name)._cleanup_()

        setattr(self, volume_name, None)
        delattr(self, volume_name)

        self.n_volumes -= 1

    def remove_all_volumes(self):
        while len(self.volume_names):
            volume_name = self.volume_names[-1]
            self.remove_volume(volume_name)

    def _cleanup_(self):
        self.remove_all_volumes()
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys):
            attrib_key = dict_keys[-1]
            # print(attrib_key)
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)
            dict_keys.remove(attrib_key)
                
    def reorder_volumes(self):
        pass
    

class VolumeLayerGroups(object):
    def __init__(self):
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
        self.group_dict = {}
        self.group_names = []
        self.volume_names = {}  # {Group_1: [Volume_1, Volume_2, ...], 
                                #  Group_2: [Volume_1, Volume_2, ...], 
                                #  ...}
        self.current_group_and_volume: tuple[int, int] = (None, None)

    def get_group_by_name(self, group_name) -> VolumeLayerGroup:
        return getattr(self, group_name)
    
    def get_group_by_index(self, group_index) -> VolumeLayerGroup:
        return getattr(self, self.group_names[group_index])
    
    def get_volume_by_index(self, group_index, volume_index) -> VolumeLayer:
        return self.get_group_by_index(group_index).get_volume_by_index(volume_index)

    def get_volume_by_name(self, group_name, volume_name) -> VolumeLayer:
        return self.get_group_by_name(group_name).get_volume_by_name(volume_name)

    def set_current_volume_by_index(self, group_index, volume_index):
        self.get_group_by_index(group_index).set_current_volume(volume_index)
        print(f'VolumeLayerGroups Message: Before setting: {self.current_group_and_volume = }')
        setattr(self, 'current_group_and_volume', tuple([group_index, volume_index]))
        print(f'VolumeLayerGroups Message: After setting: {self.current_group_and_volume = }')

    def set_current_volume_by_name(self, group_name, volume_name):
        group_index = self.group_names.index(group_name)
        volume_index = self.get_group_by_index(group_index).volume_names.index(volume_name)

        self.set_current_volume_by_index(group_index, volume_index)

    def get_current_group(self) -> VolumeLayerGroup:
        return self.get_group_by_index(self.current_group_and_volume[0])
    
    def get_current_volume(self) -> VolumeLayer:
        return self.get_volume_by_index(*self.current_group_and_volume)

    def update_control(self):
        self.get_current_volume().update_control()

    def update_current_volume(self, 
                              orientation_info,
                              intensity_info):
        self.get_current_group().update_current_volume(orientation_info,
                                                       intensity_info)

    # def set_current_volume(self, group_index, volume_index):
    #     self.get_group_by_index(group_index).set_current_volume(volume_index)
    #     setattr(self, 'current_group_and_volume', (group_index, volume_index))
        
    def add_group(self, group_name = 'Group_1', **kwargs):
        if group_name in self.group_names:
            print(f'VolumeLayer Message: {group_name} already added.')
            return
        
        print(f'VolumeLayer Message: Adding {group_name} to groups.')
        setattr(self, group_name, VolumeLayerGroup(group_name, **kwargs))
        self.group_dict[group_name] = []
        self.group_names.append(group_name)

    def add_volume_to_group(self, 
                            group_name, 
                            ctvolume: CTVolume.CTVolume,
                            **kwargs):
        if group_name not in self.group_names:
            self.add_group(group_name = group_name)
            self.group_dict[group_name] = []

        if ctvolume.name not in self.group_dict[group_name]:
            self.get_group_by_name(group_name).add_volume(ctvolume,
                                                          **kwargs)
        
            self.group_dict[group_name].append(ctvolume.name)
        
    def add_volumes_to_group(self, group_name, list_of_ctvolumes, **kwargs):
        for ctvolume in list_of_ctvolumes:
            self.add_volume_to_group(group_name, 
                                     ctvolume,
                                     **kwargs)

    def remove_group(self, group_name):
        print(f'VolumeLayer Message: Removing {group_name}')
        self.get_group_by_name(group_name).remove_all_volumes()
        setattr(self, group_name, None)
        delattr(self, group_name)
        self.group_names.remove(group_name)

    def remove_all_groups(self):
        while len(self.group_names):
            self.remove_group(self.group_names[-1])

    def _cleanup_(self):
        self.remove_all_groups()
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys):
            attrib_key = dict_keys.pop()
            setattr(self, attrib_key, None)
            # delattr(self, attrib_key)