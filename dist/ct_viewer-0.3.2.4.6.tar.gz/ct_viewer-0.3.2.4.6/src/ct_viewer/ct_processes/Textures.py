from .Globals import *
from . import CTVolume


class Texture(object):
    """
    This class holds the actual texture information for each VolumeLayer object. 
    
    """

    mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
    mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: x
    mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
    mode_value = lambda x: getattr(cp, x.__str__()) if G.GPU_MODE else getattr(np, x.__str__())
    cp_to_np = lambda x: cp.asnumpy(x) if G.GPU_MODE else lambda x: x
    np_to_cp = lambda x: cp.asarray(x) if G.GPU_MODE else lambda x: x

    def __init__(self, ct_volume: CTVolume.CTVolume):
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
            print(f'Textures Message: Using CUDA device {G.DEVICE}.')

        self.ct_volume = ct_volume
        self.texture_dim = ct_volume.texture_dim
        self.shape = [ct_volume.texture_dim, ct_volume.texture_dim]
        self.texture_content = Texture.mode_function(np.full)(self.shape, Texture.mode_value(np.nan))
        self.texture = np.zeros(self.texture_dim * self.texture_dim * 4, dtype = np.float32)
        self.colormap = G.DEFAULT_IMAGE_SETTINGS['colormap']
        self.zoom_level = 100 # final_zoom = self.zoom_level*self.zoom_constant
        self.zoom_constant = 0.01 # Percent of original image
        self.x_shift = 0
        self.y_shift = 0
        self.pixel_start = [0, 0]
        self.pixel_end = [self.texture_dim, self.texture_dim]
        self.uv_min = [0.0, 0.0]
        self.uv_max = [1.0, 1.0]
        self.min_value = 0.0
        self.max_value = 1.0
        self.colormap_scale = None
        self.texture_tag = create_tag('Textures', 'Texture', ct_volume.name)
        self.drawlist_tag = create_tag('AnalysisView', 'DrawList', 'Texture')
        self.drawimage_tag = create_tag('Textures', 'DrawImage', ct_volume.name)

        print(f'Textures Message: Added {self.texture_tag}')

    def set_texture_value(self, value):
        self.texture_content[:] = Texture.mode_value(value)

    def create_texture(self):
        if dpg.does_item_exist(self.texture_tag):
            print(f'Texture Message: create_texture(): {self.texture_tag} already exists.')
            return
        dpg.add_static_texture(width = self.texture_dim,
                               height = self.texture_dim,
                               tag = self.texture_tag, 
                               default_value = self.texture,
                               parent = G.TEX_REG_TAG)
        

    def delete_texture(self):
        if dpg.does_item_exist(self.texture_tag):
            dpg.delete_item(self.texture_tag)
            
        if dpg.does_alias_exist(self.texture_tag):
            dpg.remove_alias(self.texture_tag)

        if dpg.does_item_exist(self.drawimage_tag):
            dpg.delete_item(self.drawimage_tag)
            
        if dpg.does_alias_exist(self.drawimage_tag):
            dpg.remove_alias(self.drawimage_tag)
    

    def window_and_normalize(self, colormap_scale_type = dpg.get_value('colormap_scale_combo')):

        match colormap_scale_type:
            case 'Log':
                self.texture_content = self.mode_function(np.log10)(self.texture_content + 1e-6)

            case 'Absolute':
                self.texture_content = self.mode_function(np.abs)(self.texture_content)

            case 'Abs-Log':
                self.texture_content = self.mode_function(np.log10)(self.mode_function(np.abs)(self.texture_content) + 1e-6)

            case _:
                pass
        
        self.texture_content = (self.texture_content - self.min_value)/(self.max_value - self.min_value)
        self.texture_content = Texture.mode_function(np.clip)(self.texture_content, 0, 1)

        return

    
    def get_alpha_mask(self):
        # self.alpha_mask is a boolean array where we don't have nans. 
        return ~self.mode_function(np.isnan)(self.texture_content)


    def assign_texture(self):

        red_interp, green_interp, blue_interp = self.colormap
        # self.color_rgb[:] = self.window_and_normalize_image().clip(0, 1).flatten()[:]

        self.texture[0::4] = Texture.mode_return_type(Texture.cp_to_np(red_interp(self.texture_content.flatten()[:])), 'float32')[:]
        self.texture[1::4] = Texture.mode_return_type(Texture.cp_to_np(green_interp(self.texture_content.flatten()[:])), 'float32')[:]
        self.texture[2::4] = Texture.mode_return_type(Texture.cp_to_np(blue_interp(self.texture_content.flatten()[:])), 'float32')[:]
        self.texture[3::4] = Texture.mode_return_type(Texture.cp_to_np(self.get_alpha_mask().flatten()), 'float32')[:]

    # def update_window(self):
    #     min_intensity = dpg.get_value(G.OPTION_TAG_DICT['min_intensity'])
    #     max_intensity = dpg.get_value(G.OPTION_TAG_DICT['max_intensity'])
    #     window_size = np.min([dpg.get_value(f'{G.OPTIONS_DICT["min_intensity_slider"]["slider_tag"]}_increment_input_float'),
    #                           dpg.get_value(f'{G.OPTIONS_DICT["max_intensity_slider"]["slider_tag"]}_increment_input_float')])
        
    #     self.volume.update_window(min_intensity, max_intensity, window_size)
    #     self.volume.set_dpg_window()

    def set_colormap(self, colormap):
        self.colormap = colormap

    def set_colormap_scale(self, colormap_scale_type):

        self.min_value = dpg.get_value(G.OPTION_TAG_DICT['min_intensity'])
        self.max_value = dpg.get_value(G.OPTION_TAG_DICT['max_intensity'])

        match colormap_scale_type:
            case 'Log':
                self.min_value = np.log10(self.min_value + 1e-6)
                self.max_value = np.log10(self.max_value)

            case 'Absolute':
                self.min_value = np.abs(self.min_value)
                self.max_value = np.abs(self.max_value)

            case 'Abs-Log':
                self.min_value = np.log10(np.abs(self.min_value) + 1e-6)
                self.max_value = np.log10(np.abs(self.max_value))

            case _:
                pass

        dpg.configure_item(self.colormap_scale, min_scale = self.min_value)
        dpg.configure_item(self.colormap_scale, max_scale = self.max_value)

    def update_texture(self):
        # self.update_window()
        # self.volume.update_orientation() # Transformation handled in each VolumeLayer object. 
        # self.update_current_view() # In MainView, this updates current_view_plan, current_norm_vector, current_norm
        # self.interpolate_texture()
        # self.update_alpha_mask() # This sets alpha mask. Replaced by get_alpha_mask() in assign_texture
        self.window_and_normalize()
        self.assign_texture()
        self.delete_texture()
        self.create_texture()
        self.update_draw_image()
        self.delete_drawn_texture()
        self.redraw_texture()

    def update_draw_image(self):
        self.x_shift = dpg.get_value(G.ORIGIN_X_SLIDER)
        self.y_shift = dpg.get_value(G.ORIGIN_Y_SLIDER)
        self.drawlist_tag = dpg.get_item_parent(self.drawlist_tag)
        print(f'Texture Message: update_draw_image(): {self.x_shift = :<5}, {self.y_shift = :<5}, {self.drawlist_tag = }')

    def delete_drawn_texture(self):
        if dpg.does_item_exist(self.drawimage_tag):
            dpg.delete_item(self.drawimage_tag)
        if dpg.does_alias_exist(self.drawimage_tag):
            dpg.remove_alias(self.drawimage_tag)

    def redraw_texture(self, 
                     drawlist:str = None, 
                     pmin: list = None,
                     pmax: list = None,
                     uv_min: list = None, 
                     uv_max: list = None,
                     user_data = None):
        
        dpg.draw_image(self.texture_tag,
                       tag = self.drawimage_tag,
                       pmin = [self.pixel_start[0] - self.x_shift, self.pixel_start[1] - self.y_shift] if type(pmin) == type(None) else pmin,
                       pmax = [self.pixel_end[0] - self.x_shift, self.pixel_end[1] - self.y_shift] if type(pmax) == type(None) else pmax,
                       uv_min = self.uv_min if type(uv_min) == type(None) else uv_min,
                       uv_max = self.uv_max if type(uv_max) == type(None) else uv_max,
                       parent = self.drawlist_tag if type(drawlist) == type(None) else drawlist,
                       user_data = [self.x_shift, self.y_shift] if type(user_data) == type(None) else user_data)

    def add_texture_to_drawlist(self, 
                                pixel_start, 
                                pixel_end,
                                uv_min = [0, 0],
                                uv_max = [1, 1], 
                                shift = [0, 0]):
        
        dpg.draw_image(self.texture_tag, 
                       tag = self.drawimage_tag, 
                       pmin = pixel_start, 
                       pmax = pixel_end, 
                       uv_min = uv_min, 
                       uv_max = uv_max, 
                       parent = self.drawlist_tag,
                       user_data = shift)
    
    def change_zoom_level(self, sender, app_data):
        x_shift, y_shift = dpg.get_item_user_data(self.drawimage_tag)
        dpg.delete_item(self.drawimage_tag)
        x_zoom, y_zoom, _, _ = app_data
        dpg.draw_image(self.texture_tag, 
                       tag = self.drawimage_tag,
                       pmin = [(self.pixel_start[0] - x_shift) - x_zoom*self.zoom_constant, 
                               (self.pixel_start[1] - y_shift) - x_zoom*self.zoom_constant],
                       pmax = [(self.pixel_end[0] + x_shift) - x_zoom*self.zoom_constant, 
                               (self.pixel_end[1] + y_shift) - x_zoom*self.zoom_constant],
                       )