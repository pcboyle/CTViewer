from .Globals import *

class MenuBar:
    def __init__(self):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        with dpg.menu_bar(tag = 'MenuBar'):
            with dpg.menu(label = 'File', tag = 'MenuBarFile'):
                dpg.add_menu_item(label = 'Open Volume', tag = 'MenuBarFile_open', callback = self.open_file)
                dpg.add_menu_item(label = 'Add Volume', tag = 'MenuBarFile_add_volume', callback = self.open_file)
                dpg.add_menu_item(label = 'Close Volume', tag = 'MenuBarFile_close', callback = self.close_file)
                dpg.add_menu_item(label = 'Custom File Dialog', tag = 'MenuBarFile_custom_dialog', callback = self.open_custom)
                
            with dpg.menu(label = 'Layers', tag = 'MenuBarLayers'):
                dpg.add_menu_item(label = 'New Group', tag = 'MenuBarLayers_create_new_group', callback = self.create_new_group)
            
            with dpg.menu(label = 'Analysis', tag = 'MenuBarAnalysis'):
                dpg.add_menu_item(label = 'Open Analysis Window', tag = 'MenuBarAnalysis_open_analysis_window', callback = self.open_analysis_window)

            with dpg.menu(label = 'Settings', tag = 'MenuBarSettings'):
                dpg.add_menu_item(label='Configuration', tag = 'MenuBarSettings_open_config_menu', callback = self.open_configuration)

        with dpg.file_dialog(file_count = 15,
                             tag = G.VOLUME_FILE_DIALOG, 
                             height = 500, width = 800, 
                             show = False,
                             default_path = G.CONFIG_DICT['directories']['image_dir'],
                             callback = self.read_file, 
                             cancel_callback = self.cancel_read):
            dpg.add_file_extension(".*")
            dpg.add_file_extension("Image Files (.mat, .h5, .nii){.mat,.h5,.nii}")
    
    def open_file(self, sender, app_data):
        dpg.show_item(G.VOLUME_FILE_DIALOG)


    def close_file(self):
        print(f'{G.FILE_LOADED = }')
        if G.FILE_LOADED:
            G.APP.FileIO.close()
        print(f'{G.FILE_LOADED = }')
        
        
    def read_file(self, sender, app_data):
        G.APP.FileIO.initialize_read(sender, app_data)
        dpg.hide_item(G.VOLUME_FILE_DIALOG)
    
    def open_custom(self, sender, app_data):
        G.APP.FileDialog.open_window(debug = False)

    # This crashes the program or doesn't work at all, for some reason. The person that added it to dpg likely did a hack job. 
    def cancel_read(self, sender, app_data):
        dpg.hide_item(G.VOLUME_FILE_DIALOG)
    
    
    def create_new_group(self):
        pass
    
    
    def open_analysis_window(self):
        if G.FILE_LOADED:
            pass
            
        else:
            pass
        

    def open_configuration(self):

        pass
    
    def _cleanup_(self):
        pass