from .Globals import *

class OptionsPanel:
    """
    Options panel class. Holds the various functional, geometric, and color options in the leftmost panel. 
    Each option here needs to be added to the G.OPTIONS_DICT and associated lists. 
    """
    def __init__(self, tab = ''):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        with dpg.child_window(width = G.CONFIG_DICT['app_settings']['option_panel_width'], # G.OPTIONS_PANEL_WINDOW_DEFAULTS['WINDOW_WIDTH'], 
                              height = G.CONFIG_DICT['app_settings']['option_panel_height']): # G.OPTIONS_PANEL_WINDOW_DEFAULTS['WINDOW_HEIGHT']):
            option_key = 'img_index_slider'
            
            with dpg.group(horizontal = True, tag = G.OPTIONS_DICT[option_key]['group_tag']):
                dpg.add_text(G.OPTIONS_DICT[option_key]['label'], tag = G.OPTIONS_DICT[option_key]['label_tag'])
                dpg.add_slider_int(label = '', width = 150, height = 25, callback = self.update_image_index,
                                   default_value = G.OPTIONS_DICT[option_key]['default_value'],
                                   min_value = G.OPTIONS_DICT[option_key]['min_value'], 
                                   max_value = G.OPTIONS_DICT[option_key]['max_value'],
                                   tag = G.OPTIONS_DICT[option_key]['slider_tag'])
            
            # Orientation Group
            with dpg.group(horizontal = True, tag = 'orientation_group_options'):
                with dpg.group(tag = 'orientation_group_options_slider_group'):
                    for option_key in G.ORIENTATION_OPTIONS: 
                        with dpg.group(horizontal = True, tag = G.OPTIONS_DICT[option_key]['group_tag']):
                            dpg.add_text(G.OPTIONS_DICT[option_key]['label'], tag = G.OPTIONS_DICT[option_key]['label_tag'])
                            dpg.add_input_float(label = '', callback = self.update_float, width = 100,
                                                step = 1.0, step_fast = 5.0, format = '%.2f',
                                                default_value = G.OPTIONS_DICT[option_key]['default_value'],
                                                min_value = G.OPTIONS_DICT[option_key]['min_value'], 
                                                max_value = G.OPTIONS_DICT[option_key]['max_value'],
                                                min_clamped = True, max_clamped = True,
                                                tag = G.OPTIONS_DICT[option_key]['slider_tag'])
                            with dpg.popup(G.OPTIONS_DICT[option_key]['group_tag'], min_size = [15, 15], 
                                           tag = f'{G.OPTIONS_DICT[option_key]["group_tag"]}_increment_popup'):
                                dpg.add_input_float(label = 'Increment', step = 0.05, step_fast = 0.5, default_value = 1, 
                                                    tag = f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float',
                                                    min_value = 0.01, max_value = 10.0, min_clamped = True, max_clamped = True, callback = self.set_increment_value)
                
                b_height = 135
                tag = f'orientation_{G.GROUP_LAYER_CONTROL_BUTTON}'
                dpg.add_button(label = G.DEFAULT_GROUP_LAYER_CONTROL, tag = tag, height = b_height, callback = self.update_frame_of_reference)
                
                tag = f'orientation_{G.GROUP_LAYER_RESET_BUTTON}'
                dpg.add_button(label = 'Reset', tag = tag, height = b_height, callback = self.reset_orientation)
            
            with dpg.group(horizontal = True, tag = 'intensity_group_options'):
                with dpg.group():
                    for option_key in ['min_intensity_slider', 'max_intensity_slider']:
                        with dpg.group(horizontal = True, tag = G.OPTIONS_DICT[option_key]['group_tag']):
                            dpg.add_text(G.OPTIONS_DICT[option_key]['label'], tag = G.OPTIONS_DICT[option_key]['label_tag'])
                            dpg.add_input_float(label = '', callback = self.update_float, width = 150,
                                                step = 1.0, step_fast = 5.0, format = '%.2f',
                                                default_value = G.OPTIONS_DICT[option_key]['default_value'],
                                                min_value = G.OPTIONS_DICT[option_key]['min_value'], 
                                                max_value = G.OPTIONS_DICT[option_key]['max_value'],
                                                min_clamped = True, max_clamped = True,
                                                tag = G.OPTIONS_DICT[option_key]['slider_tag'])
                            with dpg.popup(G.OPTIONS_DICT[option_key]['group_tag'], min_size = [15, 15], 
                                           tag = f'{G.OPTIONS_DICT[option_key]["group_tag"]}_increment_popup'):
                                dpg.add_input_float(label = 'Increment', step = 0.25, step_fast = 1, default_value = 1, 
                                                    tag = f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float',
                                                    min_value = 0.01, max_value = 10.0, min_clamped = True, max_clamped = True, callback = self.set_increment_value)
                            
                tag = f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}'
                dpg.add_button(label = G.DEFAULT_GROUP_LAYER_CONTROL, tag = tag, height = 42, callback = self.update_frame_of_reference)
            
            with dpg.group(tag = 'colormap_and_colorscale'):
                with dpg.group(horizontal = True):
                    dpg.add_text('Colormap  :')
                    dpg.add_combo(items = list(G.COLORMAP_DICT.keys()), width = 225, 
                                callback = self.update_colormap, default_value = 'Fire',
                                tag = 'colormap_combo')
                    dpg.add_checkbox(label = 'Reverse', tag = 'reverse_colormap_checkbox', callback = self.update_colormap)
                    dpg.set_value('colormap_combo', 'Fire')

                with dpg.group(horizontal = True):
                    dpg.add_text('Colorscale:')
                    dpg.add_combo(items = list(G.COLORMAP_SCALES), width = 225,
                                callback = self.update_colormap, default_value = 'Linear',
                                tag = 'colormap_scale_combo')
                    dpg.add_checkbox(label = 'Rescale', tag = 'rescale_colormap_checkbox', callback = self.update_colormap)
                
            with dpg.group(tag = 'mask_segmentation_options'):
                with dpg.group(horizontal = True, tag = 'mask_segmentation_group'):
                    dpg.add_text('Mask      :')
                    dpg.add_combo(items = list(G.MASK_DICT.keys()), width = 225, 
                                  callback = self.update_mask, default_value = 'Body', 
                                  tag = 'mask_combo')
                    dpg.set_value('mask_combo', 'Body')
                    dpg.add_checkbox(label = 'Enable', tag = 'enable_mask_checkbox', default_value=False, callback = self.update_mask)

                with dpg.group(horizontal = True, tag = 'mask_exclude_low_group'):
                    dpg.add_text('Mask Low  :')
                    dpg.add_input_float(label = '', callback = self.update_mask, width = 150, step = 1, step_fast = 5,
                                  default_value = -3500, tag = 'mask_exclude_low_float')
                    dpg.add_checkbox(label = 'Enable', tag = 'enable_mask_low_exclude_checkbox', default_value=False, callback = self.update_mask)
                
                    with dpg.popup('mask_exclude_low_group', min_size = [15, 15], 
                                   tag = f'mask_exclude_low_increment_popup'):
                        dpg.add_input_float(label = 'Increment', step = 0.05, step_fast = 0.5, default_value = 1, 
                                            tag = f'mask_exclude_low_float_increment_input_float',
                                            min_value = 0.01, max_value = 10.0, min_clamped = True, max_clamped = True, callback = self.set_increment_value)

                with dpg.group(horizontal = True, tag = 'mask_exclude_high_group'):
                    dpg.add_text('Mask High :')
                    dpg.add_input_float(label = '', callback = self.update_mask, width = 150, step = 1, step_fast = 5,
                                        default_value = 3500, tag = 'mask_exclude_high_float')
                    dpg.add_checkbox(label = 'Enable', tag = 'enable_mask_high_exclude_checkbox', default_value=False, callback = self.update_mask)

                    with dpg.popup('mask_exclude_high_group', min_size = [15, 15], 
                                   tag = f'mask_exclude_high_increment_popup'):
                        dpg.add_input_float(label = 'Increment', step = 0.05, step_fast = 0.5, default_value = 1, 
                                            tag = f'mask_exclude_high_float_increment_input_float',
                                            min_value = 0.01, max_value = 10.0, min_clamped = True, max_clamped = True, callback = self.set_increment_value)
                    
                with dpg.group(horizontal = True, tag = 'mask_opacity_group'):
                    dpg.add_text('Opacity   :', tag = 'mask_opacity_label')
                    dpg.add_input_float(label = '', callback = self.update_mask, width = 150, 
                                    step = 0.01, step_fast = 0.1, format = '%.2f', 
                                    default_value = 1.0, min_value = 0.0, max_value = 1.0, 
                                    min_clamped = True, max_clamped = True, tag = 'mask_opacity_slider')
                    
                    dpg.add_color_edit(label = 'Mask Color', tag = 'mask_color_picker', 
                                       default_value=(20, 20, 230, 255), no_inputs = True, 
                                       callback = self.update_mask)
            
            with dpg.group(tag = 'interpolation_options', horizontal=True):
                dpg.add_text('Interpolation:')
                dpg.add_combo(items = G.INTERPOLATION_OPTIONS, width = 225,
                              callback = self.update_interpolation, default_value = G.INTERPOLATION_OPTIONS[0], 
                              tag = 'interpolation_combo_box')
                
            with dpg.group(horizontal = True):
                dpg.add_text('(X, Y, Z, H):')
                dpg.add_text('(0, 0, 0, 0)\n(0, 0, 0, 0)\n(0, 0, 0, 0)', tag = 'mouse_position_text')
            with dpg.group(horizontal=True):
                dpg.add_text('             ')
                dpg.add_text('(0, 0, 0, 0)', tag = 'crosshair_position_text')

                
        dpg.add_mouse_wheel_handler(callback=self.mouse_wheel_slider, tag = 'option_panel_mouse_wheel_handler', parent = G.HANDLER_REG_TAG)
        # dpg.add_key_press_handler(key = -1, callback = self.key_press_handler, tag = 'option_panel_key_press_handler', parent = G.HANDLER_REG_TAG) # all keys
        
        self.disable_options()

  
    def set_increment_value(self, sender, app_data):
        # Sender is of form: f'{G.OPTIONS_DICT[option_key]['slider_tag']}_increment_input_float'
        dpg.configure_item(sender.split('_increment_input_float')[0], step = app_data)
        dpg.configure_item(sender.split('_increment_input_float')[0], step_fast = 5*app_data)


    def update_interpolation(self):
        G.APP.main_view.update_view()


    def update_image_index(self, sender, app_data):
        print(sender, app_data)
        G.APP.main_view.update_view()


    def update_float(self):
        # print(sender, app_data)
        G.APP.main_view.update_view()

       
    def update_colormap(self):
        G.APP.main_view.update_view()

       
    def update_mask(self):
        G.APP.main_view.update_mask()


    def update_axis_of_rotation(self, sender, app_data):
        # G.APP.main_view.update_axis_of_rotation()
        print(sender, app_data)


    def update_origin(self):
        G.APP.main_view.update_view()

       
    def update_frame_of_reference(self, sender):
        # print(sender, app_data)
        current_label = dpg.get_item_label(sender)
        frame_dict = {'Group': 'Layer', 'Layer': 'Group'}
        
        dpg.set_item_label(sender, frame_dict[current_label])
        
        G.APP.main_view.current_volume_info.update_control()
        self.update_option_values(sender)
        G.APP.main_view.update_view()


    def reset_orientation(self):
        print("Resetting orientation.")
        for orientation_option_tag in G.ORIENTATION_OPTIONS:
            dpg.set_value(f'{orientation_option_tag}_current_value', G.OPTIONS_DICT[orientation_option_tag]['default_value'])
            dpg.set_value(G.OPTIONS_DICT[orientation_option_tag]['slider_tag'], G.OPTIONS_DICT[orientation_option_tag]['default_value'])
            
        G.APP.main_view.reset_volume_orientation()


    def update_option_values(self, sender):
        control_category = sender.split(f'_{G.GROUP_LAYER_CONTROL_BUTTON}')[0]
        control_list = getattr(G.APP.main_view.current_volume_info, f'{control_category}_control_list')
        for control_option_name in control_list:            
            option_tag = G.OPTION_TAG_DICT[control_option_name]
            if dpg.get_item_label(sender) == 'Group': # Indicates we've changed from Layer -> Group, so retrieve info from group_info
                control_option = getattr(getattr(G.APP.main_view.current_group_info, control_category), control_option_name)
            else:# Indicates we've changed from Group -> Layer, so retrieve info from volume_info
                control_option = getattr(getattr(G.APP.main_view.current_volume_info, control_category), control_option_name)
            dpg.set_value(f'{option_tag}_current_value', control_option.current_value)
            dpg.set_value(option_tag, control_option.current_value)


    def mouse_wheel_slider(self, sender, app_data):
        for option_key in G.OPTIONS_DICT.keys():
            if dpg.is_item_hovered(G.OPTIONS_DICT[option_key]['group_tag']) and dpg.is_item_enabled(G.OPTIONS_DICT[option_key]['slider_tag']):
                current_value_tag = '{0}_current_value'.format(G.OPTIONS_DICT[option_key]['slider_tag'])
                current_value = dpg.get_value(option_key)

                if option_key != 'img_index_slider':
                    step = 1.0*dpg.get_value(f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float')
                    
                else:
                    step = 1

                new_value = current_value + app_data * step
                
                clipped_new_value = self.clamp_option_value(option_key, new_value)
                
                # G.OPTIONS_DICT[option_key]['current_value'] = clipped_new_value
                dpg.set_value(current_value_tag, clipped_new_value)
                dpg.set_value(G.OPTIONS_DICT[option_key]['slider_tag'], clipped_new_value)
                
                G.APP.main_view.update_view()


    def clamp_option_value(self, option_key, new_value):

        if option_key in G.APP.main_view.current_volume_info.orientation_control_list:
            min_value = getattr(G.APP.main_view.current_volume_info.orientation, option_key).limit_low
            max_value = getattr(G.APP.main_view.current_volume_info.orientation, option_key).limit_high
                    
        elif option_key in G.APP.main_view.current_volume_info.intensity_control_list:
            min_value = getattr(G.APP.main_view.current_volume_info.intensity, option_key).limit_low
            max_value = getattr(G.APP.main_view.current_volume_info.intensity, option_key).limit_high
        
        else:
            min_value = G.OPTIONS_DICT[option_key]['min_value']
            max_value = G.OPTIONS_DICT[option_key]['max_value']

        if new_value < min_value:
            clipped_new_value = min_value
                    
        elif new_value > max_value:
            clipped_new_value = max_value

        else:
            clipped_new_value = new_value

        return clipped_new_value 
    

    def key_press_handler(self, sender, app_data):
        
        """
        app_data is an int corresponding to the key pressed. 
        
        """
        # print(sender, app_data)
        
        if app_data == dpg.mvKey_Right:
            value = 1
                    
        elif app_data == dpg.mvKey_Left:
            value = -1
            
        else:
            value = 0
        
        for option_key in G.OPTIONS_DICT.keys():
            if dpg.is_item_hovered(G.OPTIONS_DICT[option_key]['group_tag']) and dpg.is_item_enabled(G.OPTIONS_DICT[option_key]['slider_tag']):
                current_value_tag = '{0}_current_value'.format(G.OPTIONS_DICT[option_key]['slider_tag'])
                current_value = dpg.get_value(option_key)
                
                if option_key != 'img_index_slider':
                    step = 1*dpg.get_value(f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float')
                    step_fast = 5*dpg.get_value(f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float')
                    
                else:
                    step = 1
                    step_fast = 5
                    
                if dpg.is_key_down(dpg.mvKey_Control):
                    new_value = current_value + value * step_fast
                else:
                    new_value = current_value + value * step

                clipped_new_value = self.clamp_option_value(option_key, new_value)
                
                # G.OPTIONS_DICT[option_key]['current_value'] = clipped_new_value
                dpg.set_value(current_value_tag, clipped_new_value)
                dpg.set_value(G.OPTIONS_DICT[option_key]['slider_tag'], clipped_new_value)
                
                G.APP.main_view.update_view()
            
                
    def enable_options(self):
        for option_tag in G.OPTION_TAGS:
            dpg.enable_item(option_tag)


    def disable_options(self):
        for option_tag in G.OPTION_TAGS:
            print(f'OptionsPanel Message: {option_tag} disabled' )
            dpg.disable_item(option_tag)

    def _cleanup_(self):
        pass