Command line options: 
    To start program, use ct_viewer. 

    Can enter debug mode with -debug

    Can use GPU's with -gpu

    Select GPU with -gpu=<device number>

Config file:

    A configuration file will now be created/loaded at $USERHOME/.config/ct_viewer/config.ini

Navigation: 

REQUIRES IMAGE TO BE LOADED

    a       - Move crosshairs left
    d       - move crosshairs right
    w       - mode crosshairs up
    s       - move crosshairs down

    up      - move camera view forward
    down    - move camera view back

    n       - Decrement Pitch
    m       - Increment Pitch
    k       - Decrement Yaw
    l       - Increment Yaw
    o       - Decrement Roll
    p       - Increment Roll

    minus       - Decrement min intensity
    plus        - Incremenet min intensity
    open brace  - Decrement max intensity
    close brace - Increment max intensity

    mouse scroll - move camera view forward or back

    q - move to previous volume
    e - move to next volume

    tab - Change current volume's control to group or layer (Maybe change this to global and local?)
        Going from Layer -> Group overwrites that volume's orientation with the group Orientation
        Going from Group -> Layer copies the current group's value to the volume's layer 

    spacebar - place landmark at crosshair

    double left click - place landmark at mouse position

To change increment for origin x, origin y, and slice position:
    Right click on them, which will bring up an entry box. 
