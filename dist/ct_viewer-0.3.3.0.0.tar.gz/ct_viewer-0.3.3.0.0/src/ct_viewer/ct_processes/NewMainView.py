from .Globals import *
from . import VolumeLayer

class MainView:
    def __init__(self, 
                 volume_layer_groups:VolumeLayer.VolumeLayerGroups):
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
            print(f'MainView Message: Using CUDA device {G.DEVICE}.')

        self.mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
        self.mode_return_array = lambda x: x.get() if G.GPU_MODE else lambda x: x
        self.mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: np.array(x)
        self.mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
        self.mode_number = lambda x: getattr(cp, x.__str__()) if G.GPU_MODE else getattr(np, x.__str__())

        self.volume_layer_groups:VolumeLayer.VolumeLayerGroups = volume_layer_groups
        self.window_tag:str = ''
        self.drawlist_texture_tag:str = ''
        self.drawlist_colorbar_tag:str = ''
        self.colormap_texture_tag:str = ''
        self.crosshair_vertical_tag:str = ''
        self.crosshair_horizontal_tag:str = ''
        self.crosshar_draw_layer_tag:str = ''
        self.texture_draw_layer_tag:str = ''
        self.window_dict = {}

        # self.drawlist_tag = create_tag('NewMainView', 'DrawList', 'TextureDrawList')
        # self.colormap_scale_tag = create_tag('NewMainView', 'ColormapScale', 'TextureColormap')
        # self.texture_window_tag = create_tag('NewMainView', 'ChildWindow', 'TextureWindow')

        # with dpg.group(horizontal = True):
        #     with dpg.child_window(tag = self.texture_window_tag, 
        #                           width = G.CONFIG_DICT['app_settings']['main_plot_width'],
        #                           height = G.CONFIG_DICT['app_settings']['main_plot_height']):
        #         dpg.add_drawlist(width = G.CONFIG_DICT['app_settings']['main_pane_width'] - 75, 
        #                          height = G.CONFIG_DICT['app_settings']['main_pane_height'] - 75,
        #                          tag = self.drawlist_tag)
        #     dpg.add_colormap_scale(min_scale=0, 
        #                            max_scale=1200, 
        #                            width=65, 
        #                            height=-1, 
        #                            tag = self.colormap_scale_tag, 
        #                            colormap=G.DEFAULT_IMAGE_SETTINGS['colormap_scale'])
        
        # print(f'MainView Message: {self.texture_window_tag} Configuration: \n\n{dpg.get_item_configuration(self.texture_window_tag)}\n')
        # print(f'MainView Message: {self.colormap_scale_tag} Configuration: \n\n{dpg.get_item_configuration(self.colormap_scale_tag)}\n')

    # I am writing these in this way so we can have multiple draw windows at some point. 
    # These should really be classes of their own. 
    def return_texture_drawlist_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureDrawList']
    
    def return_colormap_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureColormap']
    
    def return_texture_drawlayer_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureDrawLayer']
    
    def return_colormap_drawlayer_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['ColormapDrawList']
    
    def create_draw_window(self, 
                           window_tag:str, 
                           parent_window:str):
        
        self.window_tag = create_tag('NewMainView', 'ChildWindow', window_tag)
        self.drawlist_texture_tag = create_tag(self.window_tag, 'DrawList', 'Texture')
        self.drawlist_colorbar_tag = create_tag(self.window_tag, 'DrawList', 'Colorbar')
        self.colormap_texture_tag = create_tag(self.window_tag, 'Colormap', 'Texture')
        self.crosshair_vertical_tag = create_tag(self.window_tag, 'Line', 'CrosshairVertical')
        self.crosshair_horizontal_tag = create_tag(self.window_tag, 'Line', 'CrosshairHorizontal')
        self.crosshar_draw_layer_tag = create_tag(self.window_tag, 'DrawLayer', 'CrosshairLayer')
        self.texture_draw_layer_tag = create_tag(self.window_tag, 'DrawLayer', 'TextureLayer')

        self.window_dict[self.window_tag] = {'TextureDrawList': self.drawlist_texture_tag,
                                             'TextureColormap': self.colormap_texture_tag,
                                             'ColormapDrawList': self.drawlist_colorbar_tag,
                                             'TextureDrawLayer': self.texture_draw_layer_tag,
                                             'TextureCrosshairVertical': self.crosshair_vertical_tag,
                                             'TextureCrosshairHorizontal': self.crosshair_horizontal_tag,
                                             'TextureDrawLayerCrosshair': self.crosshar_draw_layer_tag}
        
        
        with dpg.group(horizontal = True, 
                       parent = parent_window):
            with dpg.child_window(tag = self.window_tag, 
                                  width = G.CONFIG_DICT['app_settings']['main_pane_width'],
                                  height = G.CONFIG_DICT['app_settings']['main_pane_height']):
                with dpg.group(horizontal = True):
                    dpg.add_drawlist(width = G.CONFIG_DICT['app_settings']['main_texture_width'], 
                                     height = G.CONFIG_DICT['app_settings']['main_texture_height'],
                                     tag = self.drawlist_texture_tag)
                    # dpg.add_drawlist(width = G.CONFIG_DICT['app_settings']['colormap_scale_width'],
                    #                  height = G.CONFIG_DICT['app_settings']['colormap_scale_height'],
                    #                  tag = self.drawlist_colorbar_tag)
                    dpg.add_colormap_scale(min_scale=0, 
                                           max_scale=1200, 
                                           width=65, 
                                           height=-1, 
                                           tag = self.colormap_texture_tag, 
                                           colormap=G.DEFAULT_IMAGE_SETTINGS['colormap_scale'])
            
        dpg.add_draw_layer(parent = self.drawlist_texture_tag, 
                           tag = self.texture_draw_layer_tag)
        
        with dpg.draw_layer(parent = self.drawlist_texture_tag,
                            tag = self.crosshar_draw_layer_tag):

            dpg.draw_line([G.TEXTURE_CENTER, 0], 
                          [G.TEXTURE_CENTER, 1000], 
                          color = dpg.get_value(f'ValueRegister_Configuration_default_crosshair_color_value'),
                          tag = self.crosshair_vertical_tag)
            
            dpg.draw_line([0, G.TEXTURE_CENTER], 
                          [1000, G.TEXTURE_CENTER], 
                          color = dpg.get_value(f'ValueRegister_Configuration_default_crosshair_color_value'),
                          tag = self.crosshair_horizontal_tag)

    def add_volume_to_drawlist(self, 
                               volume_layer: VolumeLayer.VolumeLayer,
                               drawlist:str = ''):
        if drawlist == '':
            drawlist = self.texture_draw_layer_tag
        
        print(f'MainView Message: Drawing {volume_layer.texture.texture_tag} on {drawlist}')

        volume_layer.add_texture_to_drawlist(drawlist = drawlist,
                                             pixel_start = [0, 0],
                                             pixel_end = [volume_layer.texture_dim, 
                                                          volume_layer.texture_dim])