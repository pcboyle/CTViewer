from .Globals import *
from . import VolumeLayer

class MainView:
    mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
    mode_return_array = lambda x: x.get() if G.GPU_MODE else lambda x: x
    mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: np.array(x)
    mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
    mode_number = lambda x: getattr(cp, x.__str__()) if G.GPU_MODE else getattr(np, x.__str__())\
    
    def __init__(self, 
                 volume_layer_groups:VolumeLayer.VolumeLayerGroups):
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
            print(f'MainView Message: Using CUDA device {G.DEVICE}.')

        self.volume_layer_groups:VolumeLayer.VolumeLayerGroups = volume_layer_groups
        self.window_tag:str = ''
        self.drawlist_texture_tag:str = ''
        self.drawlist_colorbar_tag:str = ''
        self.colormap_texture_tag:str = ''
        self.crosshair_vertical_tag:str = ''
        self.crosshair_horizontal_tag:str = ''
        self.crosshar_drawlayer_tag:str = ''
        self.texture_drawlayer_tag:str = ''
        self.text_draw_layer_tag:str = ''
        self.landmark_draw_layer_tag:str = ''
        self.texture_info_text:str = ''
        self.window_dict = {}

    # I am writing these in this way so we can have multiple draw windows at some point. 
    # These should really be classes of their own. 
    def return_texture_drawlist_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureDrawList']
    
    def return_colormap_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureColormap']
    
    def return_texture_drawlayer_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureDrawLayer']
    
    def return_colormap_drawlayer_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['ColormapDrawList']
    
    def return_texture_info_text_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureDrawTextInfo']
    
    def return_landmark_drawlayer_tag(self, window_tag:str) -> str:
        return self.window_dict[window_tag]['TextureDrawLandmarks']
    
    def create_draw_window(self, 
                           window_tag:str, 
                           parent_window:str,
                           item_handler_reg_tag:str|int = None):
        
        self.window_tag = create_tag('NewMainView', 'ChildWindow', window_tag)
        self.drawlist_texture_tag = create_tag(self.window_tag, 'DrawList', 'Texture')
        self.drawlist_colorbar_tag = create_tag(self.window_tag, 'DrawList', 'Colorbar')
        self.colormap_texture_tag = create_tag(self.window_tag, 'Colormap', 'Texture')
        self.crosshair_vertical_tag = create_tag(self.window_tag, 'Line', 'CrosshairVertical')
        self.crosshair_horizontal_tag = create_tag(self.window_tag, 'Line', 'CrosshairHorizontal')
        self.crosshar_draw_layer_tag = create_tag(self.window_tag, 'DrawLayer', 'CrosshairLayer')
        self.texture_draw_layer_tag = create_tag(self.window_tag, 'DrawLayer', 'TextureLayer')
        self.text_draw_layer_tag = create_tag(self.window_tag, 'DrawLayer', 'TextLayer')
        self.texture_info_text = create_tag(self.window_tag, 'DrawText', 'TextureInfo')
        self.landmark_draw_layer_tag = create_tag(self.window_tag, 'DrawLayer', 'Landmarks')
        

        self.window_dict[self.window_tag] = {'TextureDrawList': self.drawlist_texture_tag,
                                             'TextureColormap': self.colormap_texture_tag,
                                             'ColormapDrawList': self.drawlist_colorbar_tag,
                                             'TextureDrawLayer': self.texture_draw_layer_tag,
                                             'TextureCrosshairVertical': self.crosshair_vertical_tag,
                                             'TextureCrosshairHorizontal': self.crosshair_horizontal_tag,
                                             'TextureDrawLayerCrosshair': self.crosshar_draw_layer_tag,
                                             'TextureDrawLayerText': self.text_draw_layer_tag,
                                             'TextureDrawTextInfo': self.texture_info_text,
                                             'TextureDrawLandmarks': self.landmark_draw_layer_tag}
        
        
        with dpg.group(horizontal = True, 
                       parent = parent_window):
            with dpg.child_window(tag = self.window_tag, 
                                  width = G.CONFIG_DICT['app_settings']['main_pane_width'],
                                  height = G.CONFIG_DICT['app_settings']['main_pane_height']):
                with dpg.group(horizontal = True):
                    dpg.add_drawlist(width = G.CONFIG_DICT['app_settings']['main_texture_width'], 
                                     height = G.CONFIG_DICT['app_settings']['main_texture_height'],
                                     tag = self.drawlist_texture_tag)
                    
                    dpg.add_colormap_scale(min_scale=0, 
                                           max_scale=1200, 
                                           width=G.CONFIG_DICT['app_settings']['colormap_scale_width'], 
                                           height=-1, 
                                           tag = self.colormap_texture_tag, 
                                           colormap=G.DEFAULT_IMAGE_SETTINGS['colormap_scale'])
                    
        dpg.add_draw_layer(parent = self.drawlist_texture_tag, 
                           tag = self.texture_draw_layer_tag)
        
        with dpg.draw_layer(parent = self.drawlist_texture_tag,
                            tag = self.crosshar_draw_layer_tag):

            dpg.draw_line([G.TEXTURE_CENTER, 0], 
                          [G.TEXTURE_CENTER, 1000], 
                          color = dpg.get_value(f'ValueRegister_Configuration_default_crosshair_color_value'),
                          tag = self.crosshair_vertical_tag)
            
            dpg.draw_line([0, G.TEXTURE_CENTER], 
                          [1000, G.TEXTURE_CENTER], 
                          color = dpg.get_value(f'ValueRegister_Configuration_default_crosshair_color_value'),
                          tag = self.crosshair_horizontal_tag)
            
        dpg.add_draw_layer(parent = self.drawlist_texture_tag,
                           tag = self.landmark_draw_layer_tag)
                             
            
        with dpg.draw_layer(parent = self.drawlist_texture_tag,
                            tag = self.text_draw_layer_tag):
            initial_text = \
"""                    (X    , Y    , Z    , HU   )
Texture Position  : (0.000, 0.000)
Physical Position : (0.000, 0.000, 0.000)
Voxel Position    : (0.000, 0.000, 0.000)
Mouse Position    : (0.000, 0.000, 0.000, 0.000)
Crosshair Position: (0.000, 0.000, 0.000, 0.000)"""
            dpg.draw_rectangle((10, 10), (430, 105), color = (0, 0, 0, 135), fill = (0, 0, 0, 135))
            dpg.draw_text((15, 15), initial_text, tag = self.texture_info_text, size = 14)
        
    def update_mouse_info_text(self, sender, app_data, user_data):
        
        draw_layer_pos = dpg.get_item_pos(self.texture_draw_layer_tag)
        mouse_vector = dpg.get_drawing_mouse_pos()
        mouse_x = int(mouse_vector[0])
        mouse_y = int(mouse_vector[1])

        if self.volume_layer_groups.get_current_group().n_volumes:
            rotated_mouse_vector = self.volume_layer_groups.get_current_orientation().get_volume_coords(mouse_x, mouse_y)
            test_vcoords = self.volume_layer_groups.get_current_orientation().view_plane.get_coords(int(mouse_x), int(mouse_y))
            test_hu = self.volume_layer_groups.get_current_volume().interpolator(test_vcoords).get()
        else:
            rotated_mouse_vector = None
            test_vcoords = None
            test_hu = None

        print(f'{mouse_vector = }')
        print(f'{rotated_mouse_vector = }')
        print(f'{test_vcoords = }')
        print(f'{test_hu = }')
        


    def add_volume_to_drawlist(self, 
                               volume_layer: VolumeLayer.VolumeLayer,
                               drawlist:str = ''):
        if drawlist == '':
            drawlist = self.texture_draw_layer_tag
        
        print(f'MainView Message: Drawing {volume_layer.texture.texture_tag} on {drawlist}')

        volume_layer.add_texture_to_drawlist(drawlist = drawlist,
                                             pixel_start = [0, 0],
                                             pixel_end = [volume_layer.texture_dim, 
                                                          volume_layer.texture_dim])
        
    def _cleanup_(self):
        for w_dict in self.window_dict.values():
            for value in w_dict.values():
                print(f'MainView Message: Deleting {value}.')
                if dpg.does_item_exist(value):
                    dpg.delete_item(value)
                if dpg.does_alias_exist(value):
                    dpg.delete_item(value)

        dict_keys = list(self.__dict__.keys())
        while len(dict_keys) > 0:
            attrib_key = dict_keys.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)
            cp._default_memory_pool.free_all_blocks()