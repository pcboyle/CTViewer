from .Globals import *
from . import CTVolume
from . import VolumeLayer

class FileIO(object):
    def __init__(self):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.matfile_version_dict = {'(0, 0)': ['v4', 'mat'],
                                     '(1, 0)': ['v5', 'mat'],
                                     '(2, 0)': ['v7.3', 'h5']}
        
        self.file_selection_dict = {} # key is the filename, value is list of dpg tags to delete 

        self.VOLUME_LOADED = False

    def initialize_read(self, sender, app_data):
        """
        Function that gets called whenever we read a new file. 
        
        Goes on to call self.read_file_contents() and self.volume_selection_table().
        """
        
        self.file_loaded = False
        self.file_directory = ''
        self.load_volume_masks = False
        self.file_stream = None
        self.file_info = {}
        self.array4D = False
        self.file_name = ''
        self.file_name_str = ''
        self.selected_volumes = []
        self.volume_selection_tags = []
        self.volume_selection_info = {}
        self.selectable_data = []
        self.sender = sender
        self.app_data = app_data
        
        self.get_file_type()
        self.get_file_info()
        
        if type(self.file_name) == type(None):
            self.file_name = G.CURRENT_FILE
            
        else:
            self.file_name = Path(self.file_name)
            self.file_directory = self.file_name.parent
            G.CONFIG_DICT['directories']['image_dir'] = self.file_name.parent
        
        self.volume_selection_table()
        dpg.configure_item(G.DATA_SELECTION_WINDOW, show = True)
        
        
    def get_file_type(self):
        """
        Gets information from MenuBar.openfile
        """        
        # if G.CURRENT_FILE == self.file_name:
            # self.close_file()

        if len(self.volume_selection_tags):
            for item_tag in self.volume_selection_tags:
                dpg.delete_item(item_tag)
            
        print(self.sender, self.app_data)
        self.file_key = list(self.app_data['selections'].keys())[0]
        self.file_name_str = self.app_data['selections'][self.file_key]
        G.CURRENT_FILE = Path(self.file_name_str)
        self.file_selection_dict[self.file_name_str] = []
        print(self.file_selection_dict)
        self.file_name = G.CURRENT_FILE
        
        self.file_ext = self.file_name.suffix
        self.file_type = ''
        
        match self.file_ext:
            case '.mat':
                # matfile_version returns a tuple corresponding to the file version which is a key for the matfile_version_dict
                mat_version, self.file_type = self.matfile_version_dict[f'{matfile_version(self.file_name)}']

            case '.h5':
                self.file_type = 'h5'

            case '.hdf5':
                self.file_type = 'h5'

            case '.nii':
                self.file_type = 'nii'
            
            case _:
                print('Incorrect file type selected. Please select a .mat, .h5, .hdf5 file, .nii, .nii')


    def get_file_info(self):
        
        match self.file_type:
            case 'mat':
                self.file_info = self.retrieve_matfile_info(self.file_name)

            case 'h5':
                self.file_stream = h5py.File(self.file_name, mode = 'r', swmr=True, track_order=True)
                self.file_info = self.retrieve_hdf5_info(self.file_stream)
            
            case 'nii':
                self.file_stream = nib.load(self.file_name)
                self.file_info = self.retrieve_nii_info(self.file_stream)
    

    def retrieve_matfile_info(self, matfile_path):
        """
        Retrieve information from v7 and lower matfiles. Places them in dictionary that can be used in create_tree_nodes
        """

        attributes = whosmat(matfile_path)

        key_dict = {'Name': matfile_path.name, 'Type': 'Group', 'Groups': {}, 'Datasets': {}, 'Attributes': attributes}



    def retrieve_hdf5_attrs(self, hdf5_object):
        """
        Function to retrieve attribute keys and values and return them as a dict. 
        """
        
        attrs_dict = {}
        
        for key, value in hdf5_object.attrs.items():
            attrs_dict[key] = value
            
        return attrs_dict
    

    def retrieve_hdf5_info(self, hdf5_object):
        """
        Recursively finds all information in an hdf5 file and stores it in a hierarchical dictionary.
        
        Uses retrieve hdf5_attrs.
        """
        
        key_dict = {'Name': hdf5_object.name, 'Type': '', 'Groups': {}, 'Datasets': {}, 'Attributes': self.retrieve_hdf5_attrs(hdf5_object)}
        
        if isinstance(hdf5_object, h5py.Group):
            key_dict['Type'] = 'Group'
            for key, value in hdf5_object.items():
                if isinstance(value, h5py.Group):
                    key_dict['Groups'][key] = self.retrieve_hdf5_info(value)
                
                else:
                    if len(value.shape) == 4:
                        self.array4D = True
                        for index in range(len(value)):
                            key_dict['Datasets'][f'{key}__{index + 1}'] = {'Name': f'{value.name}__{index + 1}',
                                                                           'Type': 'Dataset',
                                                                           'data': value.shape[1:],
                                                                           'shape': value.shape[1:],
                                                                           'Attributes': self.retrieve_hdf5_attrs(value)}

                    else:
                        key_dict['Datasets'][key] = {'Name': value.name, 
                                                     'Type': 'Dataset',
                                                     'data': value.shape,
                                                     'shape': value.shape,
                                                     'Attributes': self.retrieve_hdf5_attrs(value)}
        
        elif isinstance(hdf5_object, h5py.Dataset):
            key_dict['Type'] = 'Dataset'
            
        return key_dict

    
    def retrieve_nii_info(self, nii_object):
        pass


    def populate_volume_selection_table(self):
        """
        Function that parses the image data in the appropriate format and builds populates the volume selection table. 

        """

        if self.file_type == 'h5':
            self.create_tree_node(self.file_info, G.FILE_INFORMATION_TABLE)

        if self.file_type == 'mat':
            self.image_data_from_mat(self.file_info, G.FILE_INFORMATION_TABLE)

    
    def image_data_from_mat(self, data_list: list, parent_table):
        """
        Helper function that creates a list of data from within a non-v7.3 mat file. 
        """

        file_keys = [key[0] for key in data_list]
        file_shapes = [key[1] for key in data_list]
        file_dtypes = [f'{key[2]}' for key in data_list]

        dpg.add_table_column(parent = parent_table)

        # Check shapes to see if we have 4D array.

        volume_list = []

        for file_shape in file_shapes:
            if len(file_shape) == 4:
                pass

        for file_key in file_keys:
            pass


    def create_tree_node(self, dict_object, parent_table):
        """
        Helper function that recursively creates tree nodes in the table that lists the data within a file. Requires 
        hdf5 files or v7.3 mat or later mat files. 
        """

        # The initial dict_object is always a Group as it is the file itself, which is a group. 
        if dict_object['Type'] == 'Group':
            # For all items that are datasets we populate their group tree node. 
            if len(dict_object['Datasets'].items()):
                    # Add a column for holding the shape information for the datasets. 
                    dpg.add_table_column(parent = parent_table)
            for key, item in dict_object['Datasets'].items():
                if len(item['shape']) == 3:
                    with dpg.table_row(parent = parent_table):
                        dpg.add_selectable(label = key, tag = f'{item["Name"]} selectable', span_columns = True, 
                                           callback = self.table_select, disable_popup_close = True)
                        dpg.add_text(default_value = f'{item["shape"]}', tag = f'{item["Name"]} shape')
                    self.volume_selection_info[item["Name"]] = {'Selectable': True, 'Shown': True, 'Selected': False}
                    self.selectable_data.append(item["Name"])
                    self.volume_selection_tags.append(f'{item["Name"]} selectable')
                    
                else:
                    with dpg.table_row(parent = parent_table):
                        dpg.add_selectable(label = key, tag = f'{item["Name"]} unselectable', enabled = False)
                    self.volume_selection_info[item["Name"]] = {'Selectable': False, 'Shown': True, 'Selected': False}
                    self.volume_selection_tags.append(f'{item["Name"]} unselectable')
            
            # For all items that are groups, we repeat this function. 
            for key, item in dict_object['Groups'].items():
                with dpg.table_row(parent = parent_table):
                    with dpg.tree_node(label = key, selectable = False):
                        with dpg.popup(dpg.last_item(), tag = f'{item["Name"]}_select_all_dialogue', min_size = [100, 50]):
                            dpg.add_button(label = f'Select All', tag = f'{item["Name"]}++select_all', 
                                           callback = self.group_select_all, user_data = item)
                            dpg.add_button(label = f'Deselect All', tag = f'{item["Name"]}++deselect_all', 
                                           callback = self.group_select_all, user_data = item)
                            
                        with dpg.table(header_row=False, tag = item['Name'], 
                                       borders_innerH = False, borders_innerV = False,
                                       borders_outerH = False, borders_outerV = False, 
                                       no_clip = True):
                            dpg.add_table_column()
                            self.create_tree_node(item, item['Name'])

                self.volume_selection_tags.append(item['Name'])
                self.volume_selection_tags.append(f'{item["Name"]}_select_all_dialogue')
                self.volume_selection_tags.append(f'{item["Name"]}++select_all')
                self.volume_selection_tags.append(f'{item["Name"]}++deselect_all')


    def volume_selection_table(self):
        
        with dpg.window(label="Data Selector", modal=False, show=False, tag=G.DATA_SELECTION_WINDOW,
                        width = 800, height = 600, pos = [250, 250]):
            
            with dpg.group(horizontal=True):
                dpg.add_input_text(label = '', tag = 'filter_volume_tree_input', width = 395, callback = self.filter_volume_table)
                dpg.add_button(label = 'Search', tag = 'filter_volume_tree_button', width = 50, callback = self.filter_volume_table)
            
            with dpg.group(horizontal=True):
                with dpg.child_window(label = 'File Contents', tag = G.FILE_INFORMATION_WINDOW, 
                                      height = 450, width = 395, autosize_x = False, border = True):
                    with dpg.table(header_row = False, tag = G.FILE_INFORMATION_TABLE):
                        dpg.add_table_column()
                        
                        self.populate_volume_selection_table()
                    
                with dpg.child_window(label = 'Selected Data', 
                                      height = 450, width = 395, autosize_x = False, border = True):
                    with dpg.table(header_row = False, tag = G.SELECTED_ITEMS_TABLE):
                        dpg.add_table_column()
                        for selected_item_index in range(G.MAX_SELECTABLE_ITEMS):
                            with dpg.table_row(show = False):
                                dpg.add_selectable(label = '', tag = f'selectable_item_{selected_item_index}', show = False)
                        
            dpg.add_button(label = 'Select all', tag = 'select_all', callback = self.table_select_all)
            dpg.add_button(label = 'Deselect all', tag = 'deselect_all', callback = self.table_select_all)
            dpg.add_button(label = 'Sort selected volumes', tag = 'sort_selected_volumes', enabled = False, callback = self.sort_selected_volumes)
            dpg.add_button(label = 'Load selected volumes', tag = 'load_selected_volumes', enabled = False, callback = self.load_selected_volumes)
            dpg.add_checkbox(label = 'Load Masks', tag = 'load_volume_masks', enabled = True, callback = self.load_volume_mask_checkbox)
            
        self.volume_selection_tags.extend([G.FILE_INFORMATION_WINDOW, G.FILE_INFORMATION_TABLE, G.SELECTED_ITEMS_TABLE, G.DATA_SELECTION_WINDOW,
                                           'select_all', 'deselect_all', 
                                           'sort_select_volumes', 'load_selected_volumes', 'load_volume_masks',
                                           'filter_volume_tree_input', 'filter_volume_tree_button'])
        
        for tag in self.volume_selection_tags:
            print(tag)
            

    def filter_volume_table(self, dict_object, parent_table):
        """
        Function that filters the already created volume table. 
        """
        
        filtered_string = dpg.get_value('filter_volume_tree_input')
        print(f'Filtering volumes for "{filtered_string}".')
        # self.volume_selection_info[item["Name"]] = {'Selectable': True, 'Shown': True, 'Selected': False}
        
        for selection_key in self.volume_selection_info.keys():
            shape_item = f'{selection_key} shape'
            if self.volume_selection_info[selection_key]['Selectable']:
                tree_item = f'{selection_key} selectable'
                
            else:
                tree_item = f'{selection_key} unselectable'
        
            if filtered_string == '':
                try:
                    dpg.configure_item(tree_item, show = True)
                    dpg.configure_item(shape_item, show = True)
                    self.volume_selection_info[selection_key]['Shown'] = True
                    print(f'Showing "{tree_item}".')
                except:
                    print(f'"{tree_item}" cannot be shown.')
                finally:
                    pass
                
            elif filtered_string not in tree_item:
                try:
                    dpg.configure_item(tree_item, show = False)
                    dpg.configure_item(shape_item, show = False)
                    self.volume_selection_info[selection_key]['Shown'] = False
                    print(f'Hiding "{tree_item}".')
                except:
                    print(f'"{tree_item}" cannot be hidden.')
                finally:
                    pass
                
            else:
                try:
                    dpg.configure_item(tree_item, show=True)
                    dpg.configure_item(shape_item, show = True)
                    self.volume_selection_info[selection_key]['Shown'] = True
                    print(f'Showing "{tree_item}".')
                except:
                    print(f'"{tree_item}" cannot be shown.')
                finally:
                    pass


    def update_selected_table(self):
        """
        Currently this is very inefficient as it reiterates through all rows and sets them to False. 
        """
        for selected_item_index in range(G.MAX_SELECTABLE_ITEMS):
            dpg.configure_item(dpg.get_item_parent(f'selectable_item_{selected_item_index}'), show = False)
            dpg.configure_item(f'selectable_item_{selected_item_index}', show = False, label = '')
        
        for selected_item_index, selected_item in enumerate(self.selected_volumes):
            dpg.configure_item(dpg.get_item_parent(f'selectable_item_{selected_item_index}'), show = True)
            dpg.configure_item(f'selectable_item_{selected_item_index}', show = True, label = selected_item)
        

    def update_volume_count(self):
        self.selected_volume_count = len(self.selected_volumes)
        if self.selected_volume_count >= 1:
            dpg.configure_item('load_selected_volumes', enabled = True)
            dpg.configure_item('sort_selected_volumes', enabled = True)
        
        else: 
            dpg.configure_item('load_selected_volumes', enabled = False)
            dpg.configure_item('sort_selected_volumes', enabled = False)
            
    
    def table_select(self, sender, app_data):
        """
        sender will be of form "Target selectable", "Moving_1 selectable", etc. 
        app_data will be a boolean.
        
        """

        item_name = sender.split(' selectable')[0]

        if app_data:
            self.selected_volumes.append(item_name)
            self.volume_selection_info[item_name]['Selected'] = True
        else:
            self.selected_volumes.remove(item_name)
            self.volume_selection_info[item_name]['Selected'] = False
            
        self.update_volume_count()
        self.update_selected_table()
            
        print(sender, app_data, self.selected_volumes)
        
    
    def table_select_all(self, sender, app_data):

        if sender == 'select_all':
            bool_val = True
        else:
            bool_val = False

        for selection_key in self.volume_selection_info.keys():
            if self.volume_selection_info[selection_key]['Shown'] and self.volume_selection_info[selection_key]['Selectable'] and ~self.volume_selection_info[selection_key]['Selected']:
                self.selected_volumes.append(selection_key)
                self.volume_selection_info[selection_key]['Selected'] = True
        
        # elif self.file_type == 'h5':
        if sender == 'deselect_all':
            print('clearing')
            self.selected_volumes.clear()
            for selection_key in self.volume_selection_info.keys():
                self.volume_selection_info[selection_key]['Selected'] = False
            
        self.update_volume_count()
        self.update_selected_table()
            
        print(sender, self.selected_volumes)
        
        
    def group_select_all(self, sender, app_data, user_data):
        
        group, option = sender.split('++')
        
        if option == 'select_all':
            print(f'Selecting all in {group}')
            for key, item in user_data['Datasets'].items():
                if (item['Name'] in self.selectable_data) & (item['Name'] not in self.selected_volumes):
                    self.selected_volumes.append(item['Name'])
                    dpg.set_value(f'{item["Name"]} selectable', True)
                    
        if option == 'deselect_all':
            print(f'Deselecting all in {group}')
            for key, item in user_data['Datasets'].items():
                if (item['Name'] in self.selectable_data) & (item['Name'] in self.selected_volumes):
                    self.selected_volumes.remove(item['Name'])
                    dpg.set_value(f'{item["Name"]} selectable', False)
        
        dpg.configure_item(f'{group}_select_all_dialogue', show = False)
        
        self.update_volume_count()
        self.update_selected_table()
            
        print(sender, self.selected_volumes)
    

    def sort_selected_volumes(self):
        
        # Want Target to be first, then ascending Moving. 
        
        print(self.selected_volumes)
        
        if 'Target' in self.selected_volumes:
            self.selected_volumes.remove('Target')
            print(self.selected_volumes)
            self.selected_volumes.sort(key = lambda x: int(x.split('_')[1]))
            self.selected_volumes.insert(0, 'Target')
            
        else:
            self.selected_volumes.sort(key = lambda x: int(x.split('_')[1]))
        
        print(self.selected_volumes)
    

    def load_volume_mask_checkbox(self):
        self.load_volume_masks = dpg.get_value('load_volume_masks')
        print(f'Load masks: {self.load_volume_masks}')
    

    def load_selected_volumes(self):
        
        G.VOLUME_KEYS.extend(self.selected_volumes)
        
        dpg.configure_item(G.DATA_SELECTION_WINDOW, show=False)
        dpg.delete_item(G.DATA_SELECTION_WINDOW)
        dpg.configure_item(G.LOADING_WINDOW_TAG, show=True)
        
        load_message = f'Loading {G.CURRENT_FILE}'
        dpg.set_value(G.LOADING_WINDOW_TEXT, load_message)
        
        load_message = f'{load_message}\n\nLoading volumes:'
        dpg.set_value(G.LOADING_WINDOW_TEXT, load_message)
        
        # load volume once, iterate through, and add to CTVolumes if 4D array
        if self.array4D:
            volume_key = self.selected_volumes[0].split('__')[0]
            if self.file_type == 'mat':
                loaded_volume = loadmat(self.file_name, appendmat=False, variable_names=volume_key, squeeze_me=True)[volume_key]

            elif self.file_type =='h5':
                loaded_volume = self.file_stream[volume_key][()]

            else:
                print(f'Accepted file types are [mat, h5]. This is {self.file_type}')
                return

            for volume, volume_name in zip(loaded_volume, self.selected_volumes):
                
                G.APP.Volumes.append(CTVolume.CTVolume(volume_name, self.file_name, volume))
                G.N_VOLUMES += 1

            del loaded_volume

        else:
            for selected_volume in self.selected_volumes:
                volume_message = f'{load_message} Loading {selected_volume}.'
                dpg.set_value(G.LOADING_WINDOW_TEXT, volume_message)
                print(f'Loading {selected_volume} as a CTVolume')

                if self.file_type == 'mat':
                    G.APP.Volumes.append(CTVolume.CTVolume(selected_volume, 
                                                           self.file_name,
                                                           loadmat(self.file_name, 
                                                                   appendmat=False,
                                                                   variable_names=selected_volume, 
                                                                   squeeze_me=True)[selected_volume]))

                elif self.file_type == 'h5':
                    if self.load_volume_masks:
                        G.APP.Volumes.append(CTVolume.CTVolume(selected_volume,
                                                               self.file_name,
                                                               self.file_stream[selected_volume][()], 
                                                               mask = self.file_stream[selected_volume][self.h5py_mask_name][()]))
                    else:
                        G.APP.Volumes.append(CTVolume.CTVolume(selected_volume, 
                                                               self.file_name,
                                                               self.file_stream[selected_volume][()]))

                else:
                    print(f'Accepted file types are [mat, h5]. This is {self.file_type}')
                    return
            
                G.N_VOLUMES += 1
        
        G.APP.VolumeLayerGroups.add_group(group_name = 'AllVolumes', 
                                          default_orientation = [0, 0, 0, 0, 0, 0, 0], 
                                          default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire'],
                                          default_histogram = [-0.5, 1200.5, 1, 'Linear'],
                                          default_limits_origin = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                                          default_limits_norm = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                                          default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]])
        
        G.APP.VolumeLayerGroups.add_volumes_to_group('AllVolumes', 
                                                     G.APP.Volumes)
        
        G.OPTIONS_DICT['img_index_slider']['max_value'] = G.N_VOLUMES
        dpg.configure_item(G.OPTIONS_DICT['img_index_slider']['slider_tag'], max_value = G.OPTIONS_DICT['img_index_slider']['max_value'])

        if not G.FILE_LOADED:
            G.APP.main_view.load_image()
            G.APP.info_box.load_image()
            G.APP.options_panel.enable_options()
            G.APP.image_tools.enable_options()
            dpg.configure_item('save_landmarks_button', enabled = True)

            self.file_loaded = True
            G.FILE_LOADED = True
            self.VOLUME_LOADED = True

            print(f'{G.FILE_LOADED}, True')
        
        else:
            G.APP.image_tools.update_selector_lists()

        layers_tab_text = f'{G.VOLUME_KEYS[0]}'
        for vol_name in G.VOLUME_KEYS[1:]:
            layers_tab_text = f'{layers_tab_text}\n{vol_name}'
        dpg.set_value('InfoBoxTab_layers_text', layers_tab_text)
        dpg.configure_item(G.LOADING_WINDOW_TAG, show=False)
        dpg.configure_item(G.LOADING_WINDOW_TAG, modal=False)
        dpg.set_value(G.LOADING_WINDOW_TEXT, '')

        while len(self.volume_selection_tags) > 1:
            tag = self.volume_selection_tags.pop()
            
            print(f'Deleting {tag}')
            if dpg.does_item_exist(tag):
                dpg.delete_item(tag)
            
            if dpg.does_alias_exist(tag):
                dpg.remove_alias(tag)


    def close(self):
        dpg.set_value('InfoBoxTab_layers_text', '')
        self.selected_volumes.clear()
        # delete volume selection window info.

        file_keys = self.file_selection_dict.keys()
        for key in file_keys:
            while len(self.file_selection_dict[key]) > 1:
                tag = self.file_selection_dict[key].pop()            
                print(f'Deleting {tag}')
                if dpg.does_item_exist(tag):
                    dpg.delete_item(tag)
            
                if dpg.does_alias_exist(tag):
                    dpg.remove_alias(tag)
            
        G.APP.main_view.close_image()
        G.APP.info_box.close_image()
        G.APP.options_panel.disable_options()
        G.APP.image_tools.disable_options()
        dpg.configure_item('save_landmarks_button', enabled = False)
        
        if type(self.file_stream) != type(None):
            self.file_stream.close()

        G.APP.VolumeLayerGroups.remove_all_groups()
        G.APP.Volumes.clear()
        G.VOLUME_KEYS.clear()
        setattr(G.APP, 'VolumeLayerGroups', VolumeLayer.VolumeLayerGroups())
        
        setattr(self, 'VOLUME_LOADED', False)
        for GLOBAL_KEY in G.GLOBAL_DEFAULTS.keys():
            setattr(G, GLOBAL_KEY, G.GLOBAL_DEFAULTS[GLOBAL_KEY])
        
        print(f'{G.FILE_LOADED}, False')
        
        # Hopefully free GPU memory. 
        cp.get_default_memory_pool().free_all_blocks()
        cp.get_default_pinned_memory_pool().free_all_blocks()
        