# CT Volume Class

# Want to use this to load up and store information on any given CT volume. 

from .Globals import *

#########################################################

# Initialize interp functions

def _initialize_interps():
    
    x = np.random.random(10)
    y = np.random.random(100).reshape(10, 10)
    z = np.random.random(1000).reshape(10, 10, 10)
    
    interp1d(0, 10, 1, x, k=1)(5)
    interp2d([0, 0], [10, 10], [1, 1], y, k=1)(5, 5)
    interp3d([0, 0, 0], [10, 10, 10], [1, 1, 1], z, taylor_order=1)(5, 5, 5)
    
    return

#########################################################

class Dummy_Volume(object):
    
    def save_as_json(self, file_path, **kwargs):
        pass
    
    def load_from_json(self, file_path, **kwargs):
        pass
    
    def save_as_flatfile(self, file_path, **kwargs):
        pass
    
    def load_from_flatfile(self, file_path, **kwargs):
        pass

class CTVolume(object):
    def __init__(self, name:str, file:Path, volume:np.ndarray, mask = None, mask_fill = -10000, 
                 affine = None, pixel_dims = None, start_pixel = None):
        """
        Can add fill value for mask, eg np.nan, -10000, etc. If None, no mask applied. 
        
        Parameters:
        ----------
        name: Name of the volume. 
        file: Source file of the volume.
        volume: data comprising the volume.
        """
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
        self.mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: x
        self.mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
        
        volume = self.mode_return_type(self.mode_create_array(volume), 'float32')

        self.name = name
        self.file = Path(file)
        self.orientation = ['HF', 'RL', 'AP'] # Head-Foot, Right-Left, Anterior-Posterior
        if type(affine) == type(None):
            affine = self.mode_function(np.eye)(4, dtype = np.float32)

        self.affine = self.mode_create_array(affine)
        if type(pixel_dims) == type(None):
            pixel_dims = affine.diagonal()[:3]

        self.pixel_dims = self.mode_create_array(pixel_dims)
        self.start_pixel = start_pixel

        # self.volume = None
        self.mask = None
        self.shape = None
        self.original_shape = volume.shape

        self.unique_values = self.determine_unique_values(volume, difference_threshold = 500)
        
        self.preprocess_volume(volume, mask)
        # These are also the centers for the same dimensions. 
        self.volume_center = (self.mode_function(np.array)(self.shape, dtype = np.float32).reshape(3, 1)/2).round(decimals = 0)
        # if G.GPU_MODE:
        #     self.volume_center = (cp.array(self.shape, dtype = cp.float32).reshape(3, 1)/2).round(decimals = 0)
        # else:
        #     self.volume_center = (np.array(self.shape, dtype = np.float32).reshape(3, 1)/2).round(decimals = 0)

        print(f'CTVolume Message: {self.volume_center = }')

        self.volume_min = self.unique_values[0]
        self.volume_max = self.unique_values[-1]
        # Get range to set initial view parameters
        self.volume_range = self.volume_max - self.volume_min
        if self.volume_range == 0:
            self.volume_range = 1

        if len(self.unique_values) < 100:
            self.histogram_step = self.volume_range/100
        else:
            self.histogram_step = cp.median(cp.diff(self.unique_values)) if G.GPU_MODE else np.median(np.diff(self.unique_values))

        if self.volume_range/self.histogram_step > 5000:
            self.histogram_step = self.volume_range/5000.0

        # These need to be accessed by dpg. 
        if G.GPU_MODE:
            self.unique_values = cp.asnumpy(self.unique_values)
            self.histogram_step = cp.asnumpy(self.histogram_step)

        self.rounded_min_max = [(self.volume_min + self.volume_range/10).round(decimals = 0), 
                                (self.volume_max - self.volume_range/10).round(decimals = 0)]
    
        
        self.dim_shifts = np.array([0, 0, 0])
        # This contains lower limit and upper limit for use in interpolator.
        self.trans_coords_min_max = np.zeros((3, 2), dtype = int)
        self.trans_coords_shift = [0, 0, 0]
        # This is the entire grid for use as coordinates. 
        self.trans_coord_grid_list = []
        self.interpolator = None
        self.mask_interpolator = None
        self.histogram = None
        self.bin_edges = None
        
        self.initialize_image_coords()
        self.set_volume_interpolator(volume, step_sizes = [abs(x.item()) for x in pixel_dims])
        self.set_mask_interpolator(step_sizes = [abs(x.item()) for x in pixel_dims])
        
        # Textures will be loaded as squares. 
        self.texture_dim = int(np.max(self.shape))
        G.TEXTURE_DIM = int(np.max([G.TEXTURE_DIM, self.texture_dim]))
        
        # Want texture to have a center pixel
        if G.TEXTURE_DIM%2 == 0:
            G.TEXTURE_DIM += 1
            
        G.TEXTURE_CENTER = int(G.TEXTURE_DIM/2)

        del volume
        del self.mask

        print(f'CTVolume Message: {name = }, {self.shape = }, {G.TEXTURE_DIM = }, {G.TEXTURE_CENTER = }')

    def preprocess_volume(self, volume, mask, mask_fill = None):
        """
        This function doesn't do much anymore, but it does process the mask. 
        """
        load_message = dpg.get_value(G.LOADING_WINDOW_TEXT)
        load_message = f'{load_message}\n\nPreprocessing volume.'
        dpg.set_value(G.LOADING_WINDOW_TEXT, load_message)
        
        if G.GPU_MODE:
            # self.volume = cp.array(volume)
            self.mask = cp.zeros(volume.shape, dtype=cp.int8)
            self.mask[(cp.isnan(volume)) | (volume < self.unique_values[0])] += 1
            volume[self.mask > 0] = cp.nan

            print(cp.cuda.Device(), volume.device)
        else:
            # self.volume = volume
            self.mask = np.zeros(volume.shape, dtype=np.int8)
            self.mask[np.isnan(self.volume)] += 1
            volume[np.isnan(volume)] = -10000.0
            
        self.shape = volume.shape
            
        load_message = f'{load_message}\nLoading images'
        
        dpg.set_value(G.LOADING_WINDOW_TEXT, load_message)
        
        # Set texture dimension here. 
        dim_0, dim_1, dim_2 = self.shape
        texture_dim = int(np.ceil(np.sqrt(dim_0*dim_0 + dim_1*dim_1 + dim_2*dim_2)))
            
        G.TEXTURE_DIM = int(np.max([G.TEXTURE_DIM, texture_dim]))
        
        load_message = f'{load_message}\n    Padded image dimensions: {self.shape}\nPreprocessing Complete!'
        dpg.set_value(G.LOADING_WINDOW_TEXT, load_message)


    def determine_unique_values(self, volume, difference_threshold = 500):
        # Get rounded unique values. Currently rounding to 0 decimals. 
        # Then get rid of nan values in unique values. 
        # Then get rid of mask values, which will be large outliers. 
        # cp.diff is a[i + 1] - a[i]
        rounded_vol = volume.round(decimals = 0)
        unique_values = cp.unique(rounded_vol) if G.GPU_MODE else np.unique(rounded_vol)
        unique_values = unique_values[~cp.isnan(unique_values) if G.GPU_MODE else ~np.isnan(unique_values)]

        mask_indices = cp.full(unique_values.shape, True, dtype=cp.bool_)
        mask_indices[:-1] = cp.diff(unique_values) < difference_threshold
        if len(unique_values) > 10:
            if unique_values[-1] - unique_values[-2] >= difference_threshold:
                mask_indices[-1] = False

        return cp.sort(unique_values[mask_indices])

    def initialize_image_coords(self):
        for dim, shape in enumerate(self.shape):
            min_coord = int(-shape/2)
            max_coord = int(shape/2)
            self.trans_coords_shift[dim] = shape/2 # Add this to the transformed coordinates to undo the transformation.
            
            self.trans_coords_min_max[dim, 0] = min_coord
            self.trans_coords_min_max[dim, 1] = max_coord - 1
            self.trans_coord_grid_list.append(list(range(min_coord, max_coord)))


    def set_volume_interpolator(self, volume, step_sizes = [1.0, 1.0, 1.0]):

        if G.GPU_MODE:
            d1_limit, d2_limit, d3_limit = self.shape

            # d1_range = cp.linspace(0, d1_limit - 1, int(self.mode_function(np.floor)(d1_limit*step_sizes[0]).item()), dtype = cp.float32) - self.volume_center[0]
            # d2_range = cp.linspace(0, d2_limit - 1, int(self.mode_function(np.floor)(d2_limit*step_sizes[1]).item()), dtype = cp.float32) - self.volume_center[1]
            # d3_range = cp.linspace(0, d3_limit - 1, int(self.mode_function(np.floor)(d3_limit*step_sizes[2]).item()), dtype = cp.float32) - self.volume_center[2]

            d1_range = cp.arange(0, stop = d1_limit, step = 1.0, dtype = cp.float32) - self.volume_center[0]
            d2_range = cp.arange(0, stop = d2_limit, step = 1.0, dtype = cp.float32) - self.volume_center[1]
            d3_range = cp.arange(0, stop = d3_limit, step = 1.0, dtype = cp.float32) - self.volume_center[2]

            self.interpolator = RegularGridInterpolator((d1_range, d2_range, d3_range), 
                                                        volume, 
                                                        bounds_error = False, 
                                                        fill_value = cp.nan)
            

        
        else:
            lower_lims = -self.volume_center.astype(float)
            upper_lims = self.volume_center.astype(float)
        
            self.interpolator = interp3d(lower_lims, upper_lims, step_sizes, volume, k = 1, p=[True, True, True])


    def set_mask_interpolator(self, step_sizes = [1.0, 1.0, 1.0]):

        if G.GPU_MODE:
            d1_limit, d2_limit, d3_limit = self.shape

            # d1_range = cp.linspace(0, d1_limit - 1, int(self.mode_function(np.floor)(d1_limit*step_sizes[0]).item()), dtype = cp.float32) - self.volume_center[0]
            # d2_range = cp.linspace(0, d2_limit - 1, int(self.mode_function(np.floor)(d2_limit*step_sizes[1]).item()), dtype = cp.float32) - self.volume_center[1]
            # d3_range = cp.linspace(0, d3_limit - 1, int(self.mode_function(np.floor)(d3_limit*step_sizes[2]).item()), dtype = cp.float32) - self.volume_center[2]

            d1_range = cp.arange(0, stop = d1_limit, step = 1.0, dtype=cp.float32) - self.volume_center[0]
            d2_range = cp.arange(0, stop = d2_limit, step = 1.0, dtype=cp.float32) - self.volume_center[1]
            d3_range = cp.arange(0, stop = d3_limit, step = 1.0, dtype=cp.float32) - self.volume_center[2]

            self.mask_interpolator = RegularGridInterpolator((d1_range, d2_range, d3_range), 
                                                             self.mask, 
                                                             bounds_error = False, 
                                                             fill_value = cp.nan)
        
        else:
            lower_lims = -self.volume_center.astype(float)
            upper_lims = self.volume_center.astype(float)
        
            self.mask_interpolator = interp3d(lower_lims, upper_lims, 
                                              step_sizes, self.mask.astype(np.float32), 
                                              taylor_order = 1, periodic=[True, True, True])

    def _cleanup_(self):
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys) > 0:
            attrib_key = dict_keys.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)