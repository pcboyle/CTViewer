from .Globals import *

if G.GPU_MODE:
    cp.cuda.Device(G.DEVICE).use()

class DummyValue(object):
    def __init__(self):
        pass
    
mode_return_type = lambda x, y: x.astype(getattr(cp, y)) if G.GPU_MODE else lambda x, y: x.astype(getattr(np, y))
mode_create_array = lambda x: cp.array(x) if G.GPU_MODE else lambda x: np.array(x)
mode_function = lambda x: getattr(cp, x.__name__) if G.GPU_MODE else getattr(np, x.__name__)
mode_value = lambda x: getattr(cp, x.__str__()) if G.GPU_MODE else getattr(np, x.__str__())
cp_to_np = lambda x: cp.asnumpy(x) if G.GPU_MODE else lambda x: x
np_to_cp = lambda x: cp.asarray(x) if G.GPU_MODE else lambda x: x


class IntensityInfo(object):
    def __init__(self, default_intensity = [0, 1200, 
                                            G.DEFAULT_IMAGE_SETTINGS['colormap'], G.DEFAULT_IMAGE_SETTINGS['colormap_combo']], 
                                            default_limits = [[0, 3499], [1, 3500]]):
        self.min_intensity = OptionValue(tag = G.OPTION_TAG_DICT['min_intensity'], default_value = default_intensity[0], default_limits = default_limits[0])
        self.max_intensity = OptionValue(tag = G.OPTION_TAG_DICT['max_intensity'], default_value = default_intensity[1], default_limits = default_limits[1])
        self.colormap = default_intensity[2]
        self.colormap_name = default_intensity[3] # eg, Fire
        self.colormap_reversed = False
        self.window_size = 1

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()


    def update_window(self, min_intensity, max_intensity, window_size):
        
        self.min_intensity.update_values(min_intensity)
        self.max_intensity.update_values(max_intensity)

        if self.max_intensity.current_value - self.min_intensity.current_value < window_size:
            if self.max_intensity.difference_value == 0: # This means we are changing max_intensity.
                self.max_intensity.update_values(self.min_intensity.current_value + window_size)
            elif self.min_intensity.difference_value == 0: # This means we are changing min_intensity. 
                self.min_intensity.update_values(self.max_intensity.current_value - window_size)
        
            dpg.set_value(G.OPTION_TAG_DICT['min_intensity'], self.min_intensity.current_value)
            dpg.set_value(G.OPTION_TAG_DICT['max_intensity'], self.max_intensity.current_value)
        

    def update_colormap(self):
        setattr(self, 'colormap_name', dpg.get_value('colormap_combo')) # eg: Fire
        self.colormap_reversed = dpg.get_value('reverse_colormap_checkbox')
        if self.colormap_reversed: 
            setattr(self, 'colormap', G.COLORMAP_DICT[dpg.get_value('colormap_combo')]['colormap_r'])
        else:
            setattr(self, 'colormap', G.COLORMAP_DICT[dpg.get_value('colormap_combo')]['colormap'])


    def copy_intensity(self, intensity_info):
        for value_type in ['current_value', 'previous_value', 'difference_value']:
            setattr(self.min_intensity, value_type, 1.0*getattr(intensity_info.min_intensity, value_type))
            setattr(self.max_intensity, value_type, 1.0*getattr(intensity_info.max_intensity, value_type))

        self.colormap = intensity_info.colormap
        self.colormap_name = intensity_info.colormap_name
        self.colormap_reversed = intensity_info.colormap_reversed
        self.window_size = 1.0*intensity_info.window_size


    def get_colormap_string(self):
        if self.colormap_reversed:
            return f'{G.COLORMAP_DICT[self.colormap_name]["name"]}_r'
        
        return f'{G.COLORMAP_DICT[self.colormap_name]["name"]}'
    

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_name = attrib_list.pop()
            try:
                getattr(self, attrib_name)._cleanup_()
            except:
                pass
            setattr(self, attrib_name, None)
            delattr(self, attrib_name)


class OrientationInfo(object):
    def __init__(self, 
                 default_orientation = [0, 0, 0, 0, 0, 0], 
                 default_quaternion = G.QTN_DICT[G.VIEW], 
                 default_limits_origin = [-350, 350],
                 default_limits_norm = [-350, 350],
                 default_limits_angle = [-180, 180]):
        """
        default_orientation = [0, 0, 0, 0, 0, 0] -> [norm, origin_y, origin_x, , pitch, yaw, roll]
        
        """

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.origin_x = OptionValue(tag = G.OPTION_TAG_DICT['origin_x'], default_value = default_orientation[0], default_limits = default_limits_origin)
        self.origin_y = OptionValue(tag = G.OPTION_TAG_DICT['origin_y'], default_value = default_orientation[1], default_limits = default_limits_origin)
        self.norm = OptionValue(tag = G.OPTION_TAG_DICT['norm'], default_value = default_orientation[2], default_limits = default_limits_norm)
        self.pitch = OptionValue(tag = G.OPTION_TAG_DICT['pitch'], default_value = default_orientation[3], default_limits = default_limits_angle)
        self.yaw = OptionValue(tag = G.OPTION_TAG_DICT['yaw'], default_value = default_orientation[4], default_limits = default_limits_angle)
        self.roll = OptionValue(tag = G.OPTION_TAG_DICT['roll'], default_value = default_orientation[5], default_limits = default_limits_angle)
        self.quaternion = QuaternionValue(tag = 'quaternion', default_quaternion = 1.0*default_quaternion)
        self.origin_vector = VectorValue(tag = 'origin_vector', default_vector = 1.0*np.array([[0], [0], [0]]))
        self.norm_vector = VectorValue(tag='norm_vector', default_vector = 1.0*default_quaternion.rotate(np.array([[1], [0], [0]]), axis = 0))
        self.viewport_origin_vector = VectorValue(tag = 'viewport_origin', default_vector = 1.0*np.array([[0], [0], [0]]))
        self.view_plane = ViewPlane(tag = 'view_plane')


    def calculate_point_projection_on_viewplane(self, point): #need to invert y
        """
        
        This calculates the distance and projection components from the current view plane to an arbitrary point. 

        It uses the center value of the view plane to calculate distance: 

        center_point = (G.TEXTURE_CENTER * G.TEXTURE_DIM) + G.TEXTURE_CENTER * (G.TEXTURE_DIM%2)
        plane_point = 1.0 * self.view_plane.current_value[:,center_point]

        """
        center_point = (G.TEXTURE_CENTER * G.TEXTURE_DIM) + G.TEXTURE_CENTER * (G.TEXTURE_DIM%2)
        plane_point = 1.0 * self.view_plane.current_value[:,center_point]

        plane_to_point = np_to_cp(point) - plane_point
        parallel_factor = mode_function(np.dot)(plane_to_point, 
                                                np_to_cp(self.norm_vector.current_value.squeeze())) / mode_function(np.dot)(np_to_cp(self.norm_vector.current_value.squeeze()), 
                                                                                                                            np_to_cp(self.norm_vector.current_value.squeeze()))
        
        parallel_factor += 0.0
        parallel_proj = parallel_factor*(np_to_cp(self.norm_vector.current_value.squeeze()) + 0.0) + 0.0
        parallel_dist = cp.linalg.norm(parallel_proj).round(decimals = 4)

        orthogonal_proj = plane_to_point - parallel_proj
        orthogonal_dist = cp.linalg.norm(orthogonal_proj).round(decimals = 4)
        point_proj_plane = plane_point + orthogonal_proj

        # TODO: Initialize these at image load!
        x_basis = np_to_cp(np.array([0, 0, 1]))
        y_basis = np_to_cp(np.array([0, -1, 0]))
        
        viewport_x = mode_function(np.dot)(qtn_rotate(self.quaternion.current_value, x_basis), orthogonal_proj)
        viewport_y = mode_function(np.dot)(qtn_rotate(self.quaternion.current_value, y_basis), orthogonal_proj)

        parallel_dist = mode_function(np.round)(parallel_dist, decimals = 4)
        parallel_proj = parallel_proj.round(decimals = 4)
        orthogonal_proj = orthogonal_proj.round(decimals = 4)

        return (parallel_dist, parallel_proj, orthogonal_proj, point_proj_plane, viewport_x, viewport_y)
    

    def copy_orientation(self, orientation_info):
        for orientation_key in orientation_info.__dict__.keys():
            check_string = f'{orientation_key}\n--------------------\n'
            if orientation_key != 'view_plane':
                check_string = f'{check_string}{getattr(self, orientation_key)}\nNew: '

            
            for value_type in ['current_value', 'previous_value', 'difference_value']:
                setattr(getattr(self, orientation_key), value_type, 1.0*getattr(getattr(orientation_info, orientation_key), value_type))


            if orientation_key != 'view_plane':
                check_string = f'{check_string}{getattr(self, orientation_key)}'

            if (orientation_key != 'view_plane') and G.DEBUG_MODE:
                print(check_string)


    def update_orientation(self):
        with dpg.mutex():
            # Update from sliders and input. 
            self.update_pitch_yaw_roll()
            self.update_quaternion()
            self.update_norm()
            self.update_origin()
            
            # Update vectors and view plane
            self.update_viewport_origin_vector()
            self.update_origin_vector()
            self.update_norm_vector()
            self.update_view_plane()
        
         
    def reset_orientation(self):
        with dpg.mutex():
            self.pitch.reset()
            self.yaw.reset()
            self.roll.reset()
            self.norm.reset()
            self.origin_x.reset()
            self.origin_y.reset()
            self.quaternion.reset()
            self.viewport_origin_vector.reset()
            self.origin_vector.reset()
            self.norm_vector.reset()
            self.view_plane.reset()
        
          
    def update_pitch_yaw_roll(self):#dpg.get_value(slider_tag)
        self.pitch.update_values(dpg.get_value(G.OPTION_TAG_DICT['pitch']))
        self.yaw.update_values(dpg.get_value(G.OPTION_TAG_DICT['yaw']))
        self.roll.update_values(dpg.get_value(G.OPTION_TAG_DICT['roll']))
        
        
    def update_quaternion(self):
        """
        To update our current quaternion, we multiply it by the difference between the new and previous value. 
        """
        rotate_qtn = qtn.array([1, 0, 0, 0])
        
        for angle_index, angle_tag in enumerate(['roll', 'yaw', 'pitch']):
            angle = getattr(self, angle_tag)
            if angle.difference_value != 0:
                angle_rad = np.deg2rad(angle.difference_value)
                rotate_qtn[0] = np.cos(angle_rad/2)
                rotate_qtn[angle_index + 1] = np.sin(angle_rad/2)
                
        self.quaternion.update_values(rotate_qtn*self.quaternion.current_value)
        
           
    def update_norm(self):
        self.norm.update_values(dpg.get_value(G.OPTION_TAG_DICT['norm']))
        
        
    def update_origin(self):
        self.origin_x.update_values(dpg.get_value(G.OPTION_TAG_DICT['origin_x']))
        self.origin_y.update_values(dpg.get_value(G.OPTION_TAG_DICT['origin_y']))
    
    
    def update_origin_vector(self):
        self.origin_vector.update_values(
            self.origin_vector.current_value 
            + self.quaternion.current_value.rotate(
                self.quaternion.default_value.rotate(
                    np.array([[self.norm.difference_value],
                              [-1.0*self.origin_y.difference_value],
                              [self.origin_x.difference_value]]
                              ),
                    axis = 0), 
                axis = 0).round(decimals = 4),
            )
        
        
    def update_norm_vector(self):
        self.norm_vector.update_values(self.quaternion.difference_value.rotate(self.norm_vector.current_value, axis = 0).round(decimals = 4))
    
    
    def update_viewport_origin_vector(self):
        self.viewport_origin_vector.update_values(
            self.quaternion.current_value.rotate(
                self.quaternion.default_value.rotate(
                    np.array([[0], 
                              [-1.0*self.origin_y.difference_value], 
                              [self.origin_x.difference_value]]),
                    axis = 0),
                axis = 0).round(decimals = 4),
            )
    
    
    def update_view_plane(self):
        """
        The math for this goes: 
            (diff_qtn*view_plane - origin_vector) * 
            (origin_vector + viewport_origin_vector + viewplane_norm_difference*viewplane_norm_vector)
        
        It's convoluted because we control the orientation from the viewplane space, 
        transform it into volume space, and then back into viewplane space

        """

        if G.GPU_MODE:
            self.view_plane.update_values(
                qtn_rotate(self.quaternion.difference_value, 
                           self.view_plane.current_value 
                           - cp.array(self.origin_vector.current_value), axis = 0).round(decimals = 4)
                + cp.array(self.origin_vector.current_value 
                + self.viewport_origin_vector.current_value 
                + self.norm.difference_value*self.norm_vector.current_value).round(decimals = 4))
            
        else:
            self.view_plane.update_values(
                qtn_rotate(self.quaternion.difference_value,
                           self.view_plane.current_value 
                           - self.origin_vector.current_value, axis = 0).round(decimals = 4)
                + self.origin_vector.current_value 
                + self.viewport_origin_vector.current_value 
                + self.norm.difference_value*self.norm_vector.current_value)
    
    
    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_name = attrib_list.pop()
            try:
                getattr(self, attrib_name)._cleanup_()
            except:
                pass
            setattr(self, attrib_name, None)
            delattr(self, attrib_name)


class HistogramInfo(object):
    def __init__(self, default_histogram = [0.5, 1200.5, 1, 'Linear']): # [min, max, step, scale]
        self.bins_min = OptionValue(tag = 'histogram_bins_min', default_value = default_histogram[0])
        self.bins_max = OptionValue(tag = 'histogram_bins_max', default_value = default_histogram[1])
        self.bin_step = OptionValue(tag = 'histogram_bin_step', default_value = default_histogram[2])
        self.bin_edges = ArrayValue(tag = 'histogram_bin_edges', default_array = cp.arange(self.bins_min(), 
                                                                                           self.bins_max(), 
                                                                                           self.bin_step()))
        self.bin_centers = ArrayValue(tag = 'histogram_bin_centers', default_array = cp.arange(self.bins_min(), 
                                                                                               self.bins_max(), 
                                                                                               self.bin_step()))
        self.bin_counts = ArrayValue(tag = 'histogram_bin_counts', default_array = cp.ones(self.bin_centers().shape))
        self.count_scale = StringValue(tag = 'histogram_count_scale', default_string = default_histogram[3])

        self.update_histogram_params(min_value = self.bins_min(), 
                                     max_value = self.bins_max(), 
                                     bin_step = self.bin_step())
    
    
    def return_size(self):
        return ['bin_centers', self.bin_centers.current_value.nbytes,
                'bin_edges', self.bin_centers.current_value.nbytes,
                'bin_counts', self.bin_counts.current_value.nbytes]


    def update_histogram_params(self, min_value = None, max_value = None, bin_step = None):
        
        self.update_bins(min_value = min_value, max_value = max_value, bin_step = bin_step)
        self.update_scale()


    def update_bins(self, min_value = None, max_value = None, bin_step = None):

        self.bins_min.update_values(self.bins_min.default_value if min_value is None else min_value)
        self.bins_max.update_values(self.bins_max.default_value if max_value is None else max_value)
        self.bin_step.update_values(self.bin_step.default_value if bin_step is None else bin_step)
        self.bin_edges.update_values(cp.arange(self.bins_min(), self.bins_max() + self.bin_step(), self.bin_step()))
        self.bin_centers.update_values(self.bin_edges()[:-1] + (self.bin_edges()[1:] - self.bin_edges()[:-1])/2.0)

    #TODO Complete update_scale function. 
    def update_scale(self):
        # self.count_scale = f'{dpg.get_value("InfoBoxTab_histogram_scale")}'
        pass


    def update_histogram_counts(self, histogram_data):
        self.bin_counts.update_values(cp.histogram(histogram_data, bins = self.bin_edges())[0])


    def get_histogram(self, return_order = 'reversed', asnumpy = True):
        if return_order == 'reversed':
            return [self.bin_centers().get() if asnumpy else self.bin_centers(), 
                    self.bin_counts().get() if asnumpy else self.bin_counts()]
        else:
            return [self.bin_counts().get() if asnumpy else self.bin_counts(), 
                    self.bin_centers().get() if asnumpy else self.bin_centers()]


    def reset_histogram(self):
        self.bins_min.reset()
        self.bins_max.reset()
        self.bin_step.reset()
        self.count_scale = f'{self.default_scale}'
        self.bin_centers = None


    def copy_histogram(self, histogram_info):
        for histogram_key in histogram_info.__dict__.keys():
            check_string = f'{histogram_key}\n--------------------\n'
            check_string = f'{check_string}{getattr(self, histogram_key)}\nNew: '
            for value_type in ['current_value', 'previous_value']:
                if histogram_key == 'count_scale':
                    setattr(getattr(self, histogram_key), value_type, f'{getattr(getattr(histogram_info, histogram_key), value_type)}')
                else:
                   setattr(getattr(self, histogram_key), value_type, 1.0*getattr(getattr(histogram_info, histogram_key), value_type))

            if G.DEBUG_MODE:
                print(check_string)


    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_name = attrib_list.pop()
            try:
                getattr(self, attrib_name)._cleanup_()
            except:
                pass
            setattr(self, attrib_name, None)
            delattr(self, attrib_name)


class StringValue(object):
    def __init__(self, tag = '', default_string = 'Default'):

        self.tag = tag
        self.default_value = f'{default_string}'
        self.current_value = f'{default_string}'
        self.previous_value = f'{default_string}'

    def __repr__(self):
        return f'{self.current_value}'

    def __call__(self):
        return self.current_value
        
    def set_previous_value(self):
        self.previous_value = f'{self.current_value}'
    
    def set_current_value(self, new_current):
        self.current_value = f'{new_current}'
        
    def update_values(self, new_current):
        self.set_previous_value()
        self.set_current_value(new_current)
        
    def reset(self):
        self.set_current_value(self.default_value)
        self.set_previous_value()

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_key = attrib_list.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)


class ArrayValue(object):
    def __init__(self, tag = '', default_array = cp.zeros((5, 5, 5)) if G.GPU_MODE else np.zeros((5, 5, 5))):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.tag = tag
        self.default_value = 1.0*default_array
        self.current_value = 1.0*default_array
        self.previous_value = 1.0*default_array
        self.min_value = self.current_value.min()
        self.max_value = self.current_value.max()

    
    def __repr__(self):
        return f'{self.current_value}'

    def __call__(self):
        return self.current_value
        
    def set_previous_value(self):
        self.previous_value = 1.0*self.current_value
    
    def set_current_value(self, new_current):
        self.current_value = 1.0*new_current
        
    def update_values(self, new_current):
        self.set_previous_value()
        self.set_current_value(new_current)
        
    def reset(self):
        self.set_current_value(1.0*self.default_value)
        self.set_previous_value()

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_key = attrib_list.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)


class QuaternionValue(object):
    def __init__(self, tag = '', 
                 default_quaternion = G.QTN_DICT[G.VIEW]):
    
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.tag = tag
        self.default_value = 1.0*default_quaternion
        self.current_value = 1.0*default_quaternion
        self.previous_value = 1.0*default_quaternion
        self.difference_value = 1.0*default_quaternion

    def __repr__(self):
        return f'{self.current_value}'
    
    def __call__(self):
        return self.current_value
        
    def set_difference_value(self):
        self.difference_value = self.current_value * self.previous_value.inverse
        
    def set_previous_value(self):
        self.previous_value = 1.0*self.current_value
    
    def set_current_value(self, new_current):
        self.current_value = 1.0*new_current
        
    def update_values(self, new_current):
        self.set_previous_value()
        self.set_current_value(new_current)
        self.set_difference_value()
        
    def reset(self):
        self.set_current_value(1.0*self.default_value)
        self.set_previous_value()
        self.set_difference_value()

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_key = attrib_list.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)


class VectorValue(object):
    def __init__(self, tag = '', default_vector = np.zeros((3))):
        
        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.tag = tag
        self.default_value = 1.0*default_vector
        self.current_value = 1.0*default_vector
        self.previous_value = 1.0*default_vector
        self.difference_value = self.current_value - self.previous_value
    
    def __repr__(self):
        return f'{self.current_value}'

    def __call__(self):
        return self.current_value

    def set_difference_value(self):
        self.difference_value = self.current_value - self.previous_value
        
    def set_previous_value(self):
        self.previous_value = 1.0*self.current_value
    
    def set_current_value(self, new_current):
        self.current_value = 1.0*new_current
        
    def update_values(self, new_current):
        self.set_previous_value()
        self.set_current_value(new_current)
        self.set_difference_value()

    def rotate(self, quaternion: qtn.QuaternionicArray = qtn.array([1, 0, 0, 0])):
        self.update_values(quaternion.rotate(self.current_value, axis = 0))
        
    def reset(self):
        self.set_current_value(1.0*self.default_value)
        self.set_previous_value()
        self.set_difference_value()

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_key = attrib_list.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)


class OptionValue(object):
    def __init__(self, tag = '', default_value = 0, default_limits = [0, 3500]):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        self.tag = tag
        self.default_value = 1.0*default_value
        self.previous_value = 1.0*default_value
        self.current_value = 1.0*default_value
        self.difference_value = self.current_value - self.previous_value 
        self.limit_low = default_limits[0]
        self.limit_high = default_limits[1]

    def __repr__(self):
        return f'{self.current_value}'
    
    def __call__(self):
        try:
            return self.current_value.item()
        except:
            return self.current_value
     
    def set_difference_value(self):
        self.difference_value = self.current_value - self.previous_value
        
    def set_previous_value(self):
        self.previous_value = 1.0*self.current_value
        
    def set_current_value(self, new_value):
        self.current_value = 1.0*new_value

    def set_limits(self, new_limits):
        self.limit_low = 1.0*new_limits[0]
        self.limit_high = 1.0*new_limits[1]
        
    def update_values(self, new_current):
        self.set_previous_value()
        self.set_current_value(new_current)
        self.set_difference_value()
        
    def reset(self):
        self.set_current_value(1.0*self.default_value)
        self.set_previous_value()
        self.set_difference_value()

    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_key = attrib_list.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)


class ViewPlane(object):
    """
    
    This is a view plane object. It holds position information only, which is then used to find the interpolated intensity
    values in a given volume. 

    """
    def __init__(self, tag = ''):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()
            
        self.tag = tag

        if G.GPU_MODE:
            self.default_value = cp.zeros((3, G.TEXTURE_DIM, G.TEXTURE_DIM))
            self.default_value[1:] = cp.indices((G.TEXTURE_DIM, G.TEXTURE_DIM)) - G.TEXTURE_CENTER
            self.default_value = self.default_value.reshape((3, G.TEXTURE_DIM*G.TEXTURE_DIM))
            self.default_value = qtn_rotate(G.QTN_DICT[G.VIEW], self.default_value, axis = 0)

        else:
            self.default_value = np.zeros((3, G.TEXTURE_DIM, G.TEXTURE_DIM))
            self.default_value[1:] = np.indices((G.TEXTURE_DIM, G.TEXTURE_DIM)) - G.TEXTURE_CENTER
            self.default_value = self.default_value.reshape((3, G.TEXTURE_DIM*G.TEXTURE_DIM))
            self.default_value = G.QTN_DICT[G.VIEW].rotate(self.default_value, axis = 0)

        self.current_value = 1.0*self.default_value
        self.previous_value = 1.0*self.default_value
        self.difference_value = self.current_value - self.previous_value


    def __repr__(self):
        return f'{self.current_value}'
    

    def __call__(self):
        return self.current_value

    def set_difference_value(self):
        self.difference_value = self.current_value - self.previous_value
        

    def set_previous_value(self):
        self.previous_value = 1.0*self.current_value
        

    def set_current_value(self, new_value):
        self.current_value = 1.0*new_value
        

    def update_values(self, new_current):
        self.set_previous_value()
        self.set_current_value(new_current)
        self.set_difference_value()
        

    def reset(self):
        self.set_current_value(1.0*self.default_value)
        self.set_previous_value()
        self.set_difference_value()


    def _cleanup_(self):
        attrib_list = list(self.__dict__.keys())
        while len(attrib_list) > 0:
            attrib_key = attrib_list.pop()
            setattr(self, attrib_key, None)
            delattr(self, attrib_key)


def qtn_rotate(quaternion, vector, axis = -1):
    if G.GPU_MODE:
        m = cp.array(quaternion.to_rotation_matrix)
        tensordot_axis = m.ndim - 2
        final_axis = tensordot_axis + (axis % vector.ndim)
        return cp.moveaxis(
                cp.tensordot(
                    m, 
                    vector, 
                    axes = (-1, axis)), 
                tensordot_axis, 
                final_axis)

    else:
        return quaternion.rotate(vector, axis = axis)