import sys
import argparse

try:
    from .ct_processes.Globals import *
    
except:
    from ct_processes.Globals import *

try: 
    from .__init__ import __version__

except:
    from __init__ import __version__

def main():
    parser = argparse.ArgumentParser(
        prog='CT Viewer',
        description = 'A tool to examine multiple ct volumes.',
    )

    parser.add_argument('-debug', '--debug', help = 'Turn debug mode on.', action = 'store_true')
    parser.add_argument('-gpu', '--gpu', nargs='?', type=int, action='store', const = 0, default = -1,
                        help='Enable GPU computation and select device number. Default device is 0.')

    args = parser.parse_args()
    print(f'APP Message: arguments parsed: {args = }')

    if args.gpu > -1:
        if args.gpu >= cp.cuda.runtime.getDeviceCount():
            print(f'APP Message: Device {args.gpu = } not valid. Max device index is {cp.cuda.runtime.getDeviceCount() - 1}.')
            print('APP Message: Running in CPU Mode.')
            
        else:
            setattr(G, 'GPU_MODE', True)
            setattr(G, 'DEVICE', 1*args.gpu)
            cp.cuda.Device(args.gpu).use()
    else:
        setattr(G, 'GPU_MODE', False)

    if args.debug:
        setattr(G, 'DEBUG_MODE', True)
    else:
        setattr(G, 'DEBUG_MODE', False)

    G.initialize_colormaps()

    dpg.create_context()

    try:
        from .ct_processes import CTViewer as ctv

    except: 
        from ct_processes import CTViewer as ctv

    ct_viewer = ctv(dpg.window(label = "", 
                               tag = G.ROOT,
                               width = G.CONFIG_DICT['app_settings']['app_width'], 
                               height = G.CONFIG_DICT['app_settings']['app_height']))
    
    if G.GPU_MODE:
        cp.cuda.Device(G.DEVICE).use()
        dpg.configure_app(auto_device=False, device = G.DEVICE, wait_for_input=False)
    else:
        dpg.configure_app(auto_device=True, wait_for_input=False)

    if G.GPU_MODE:
        window_title = f'CT Viewer {__version__}, GPU {cp.cuda.runtime.getDeviceProperties(G.DEVICE)["name"].decode()}' 
    else:
        window_title = f'CT Viewer {__version__}'

    dpg.create_viewport(title = window_title, 
                        decorated = False,
                        width = G.CONFIG_DICT['app_settings']['app_width'], 
                        height = G.CONFIG_DICT['app_settings']['app_height'], 
                        x_pos = 0, 
                        y_pos = 0)
    
    dpg.setup_dearpygui()
    dpg.show_viewport()
    dpg.set_primary_window(G.ROOT, True)
    dpg.focus_item(G.ROOT)
    
    if G.DEBUG_MODE:
        dpg.show_style_editor()
        dpg.show_item_registry()
        dpg.show_tool(dpg.mvTool_Metrics)
        # dpg.show_item(G.APP.texture_registry)
        # dpg.show_tool(dpg.mvTool_Stack)
        dpg.show_debug()
        try:
            while dpg.is_dearpygui_running():
            # insert here any code you would like to run in the render loop
            # you can manually stop by using stop_dearpygui()
                if G.FILE_LOADED:
                    for debug_tag in G.DEBUG_INFO_TAGS:
                        dpg.set_value(f'{debug_tag}_debug_info', f'{getattr(G.APP.main_view, debug_tag)}')
                
                dpg.render_dearpygui_frame()
                
        finally:
            G.save_config()
            ct_viewer._cleanup_()
            dpg.destroy_context()
            cp.get_default_memory_pool().free_all_blocks()
            cp.get_default_pinned_memory_pool().free_all_blocks()
                
        return 0
            
    else:
        try:
            dpg.start_dearpygui()

        except:
            with Exception as e:
                print(f'{e}')
            
        finally:
            G.save_config()
            ct_viewer._cleanup_()
            dpg.destroy_context()
            cp.get_default_memory_pool().free_all_blocks()
            cp.get_default_pinned_memory_pool().free_all_blocks()
        
        return 0
    
if __name__ == '__main__':
    err = main()
    if err:
        sys.exit(err)