from .Globals import *
from . import VolumeLayer
from . import NewMainView
from . import OptionValue

class OptionsPanel:
    """
    Options panel class. Holds the various functional, geometric, and color options in the leftmost panel. 
    Each option here needs to be added to the G.OPTIONS_DICT and associated lists. 
    """
    def __init__(self,
                 tab = ''):
        
        # These are set in set_volume_and_draw_objects
        self.volume_layer_groups = None
        self.draw_window = None
        self.orientation_tags = []
        self.intensity_tags = []

        dpg.add_mouse_wheel_handler(callback=self.mouse_wheel_slider, 
                                    tag = 'option_panel_mouse_wheel_handler', 
                                    parent = G.HANDLER_REG_TAG)
        dpg.add_item_clicked_handler(button=dpg.mvMouseButton_Right, 
                                     callback=self.item_right_clicked, 
                                     tag = 'option_panel_mouse_click_handler',
                                     parent = G.ITEM_HANDLER_REG_TAG)

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        with dpg.child_window(width = G.CONFIG_DICT['app_settings']['option_panel_width'], # G.OPTIONS_PANEL_WINDOW_DEFAULTS['WINDOW_WIDTH'], 
                              height = G.CONFIG_DICT['app_settings']['option_panel_height']): # G.OPTIONS_PANEL_WINDOW_DEFAULTS['WINDOW_HEIGHT']):
            option_key = 'img_index_slider'
            
            with dpg.group(horizontal = True, tag = G.OPTIONS_DICT[option_key]['group_tag']):
                dpg.add_text(G.OPTIONS_DICT[option_key]['label'], 
                             tag = G.OPTIONS_DICT[option_key]['label_tag'])
                dpg.add_slider_int(label = '', 
                                   width = 150, 
                                   height = 25, 
                                   user_data = (0, 0), # group_index, volume_index
                                   callback = self.update_image_index,
                                   default_value = G.OPTIONS_DICT[option_key]['default_value'],
                                   min_value = G.OPTIONS_DICT[option_key]['min_value'], 
                                   max_value = G.OPTIONS_DICT[option_key]['max_value'],
                                   tag = G.OPTIONS_DICT[option_key]['slider_tag'])
            
            # Orientation Group
            with dpg.group(horizontal = True, tag = 'orientation_group_options'):
                with dpg.group(tag = 'orientation_group_options_slider_group'):
                    for option_key in G.ORIENTATION_OPTIONS: 
                        with dpg.group(horizontal = True, 
                                       user_data = f'{G.OPTIONS_DICT[option_key]["group_tag"]}_increment_popup',
                                       tag = G.OPTIONS_DICT[option_key]['group_tag']):
                            with dpg.window(popup=True, 
                                            min_size = [15, 15], 
                                            show = False,
                                            tag = f'{G.OPTIONS_DICT[option_key]["group_tag"]}_increment_popup'):
                                dpg.add_input_float(label = 'Increment', 
                                                    step = 0.05, 
                                                    step_fast = 0.5, 
                                                    default_value = 1, 
                                                    tag = f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float',
                                                    min_value = 0.01, 
                                                    max_value = 10.0, 
                                                    min_clamped = True,
                                                    max_clamped = True, 
                                                    callback = self.set_increment_value)
                                
                            dpg.add_text(G.OPTIONS_DICT[option_key]['label'], 
                                         tag = G.OPTIONS_DICT[option_key]['label_tag'])
                            dpg.add_input_float(label = '',
                                                tag = G.OPTIONS_DICT[option_key]['slider_tag'],
                                                width = 100, 
                                                format = '%.2f',
                                                step = G.OPTIONS_DICT[option_key]['step_value'], 
                                                step_fast = G.OPTIONS_DICT[option_key]['step_value_fast'], 
                                                default_value = G.OPTIONS_DICT[option_key]['default_value'],
                                                min_value = G.OPTIONS_DICT[option_key]['min_value'], 
                                                max_value = G.OPTIONS_DICT[option_key]['max_value'],
                                                min_clamped = True, 
                                                max_clamped = True,
                                                callback = self.update_volume)
                            self.orientation_tags.append(dpg.last_item())
                        
                        dpg.bind_item_handler_registry(G.OPTIONS_DICT[option_key]['group_tag'], 
                                                       G.ITEM_HANDLER_REG_TAG)
                
                b_height = 135
                tag = f'orientation_{G.GROUP_LAYER_CONTROL_BUTTON}'
                dpg.add_button(label = G.DEFAULT_GROUP_LAYER_CONTROL, 
                               tag = tag, 
                               height = b_height, 
                               user_data = G.DEFAULT_GROUP_LAYER_CONTROL,
                               callback = self.update_frame_of_reference)
                
                tag = f'orientation_{G.GROUP_LAYER_RESET_BUTTON}'
                dpg.add_button(label = 'Reset', 
                               tag = tag, 
                               height = b_height, 
                               callback = self.reset_orientation)
            
            with dpg.group(horizontal = True, tag = 'intensity_group_options'):
                with dpg.group(tag = 'intensity_group_options_slider_group'):
                    for option_key in ['min_intensity_slider', 'max_intensity_slider']:
                        with dpg.group(horizontal = True, 
                                       user_data = f'{G.OPTIONS_DICT[option_key]["group_tag"]}_increment_popup',
                                       tag = G.OPTIONS_DICT[option_key]['group_tag']):
                            with dpg.window(popup=True, 
                                            min_size = [15, 15], 
                                            show = False,
                                            tag = f'{G.OPTIONS_DICT[option_key]["group_tag"]}_increment_popup'):
                                dpg.add_input_float(label = 'Increment', 
                                                    step = 0.25, 
                                                    step_fast = 1, 
                                                    default_value = 1, 
                                                    tag = f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float',
                                                    min_value = 0.01, 
                                                    max_value = 10.0, 
                                                    min_clamped = True, 
                                                    max_clamped = True, 
                                                    callback = self.set_increment_value)
                                
                            dpg.add_text(G.OPTIONS_DICT[option_key]['label'], 
                                         tag = G.OPTIONS_DICT[option_key]['label_tag'])
                            dpg.add_input_float(label = '', 
                                                tag = G.OPTIONS_DICT[option_key]['slider_tag'],
                                                width = 150, 
                                                format = '%.2f', 
                                                step = G.OPTIONS_DICT[option_key]['step_value'], 
                                                step_fast = G.OPTIONS_DICT[option_key]['step_value_fast'], 
                                                default_value = G.OPTIONS_DICT[option_key]['default_value'],
                                                min_value = G.OPTIONS_DICT[option_key]['min_value'], 
                                                max_value = G.OPTIONS_DICT[option_key]['max_value'],
                                                min_clamped = True, 
                                                max_clamped = True,
                                                callback = self.update_volume)
                            self.intensity_tags.append(dpg.last_item())
                                
                        dpg.bind_item_handler_registry(G.OPTIONS_DICT[option_key]['group_tag'], G.ITEM_HANDLER_REG_TAG)

                tag = f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}'
                dpg.add_button(label = G.DEFAULT_GROUP_LAYER_CONTROL, 
                               tag = tag, 
                               height = 42, 
                               user_data = G.DEFAULT_GROUP_LAYER_CONTROL,
                               callback = self.update_frame_of_reference)
            
            with dpg.group(tag = 'colormap_and_colorscale'):
                with dpg.group(horizontal = True):
                    dpg.add_text('Colormap  :')
                    dpg.add_combo(items = list(G.COLORMAP_DICT.keys()), width = 225, 
                                callback = self.update_volume, default_value = 'Fire',
                                tag = 'colormap_combo')
                    dpg.add_checkbox(label = 'Reverse', 
                                     tag = 'reverse_colormap_checkbox', 
                                     callback = self.update_volume)
                    dpg.set_value('colormap_combo', 'Fire')

                with dpg.group(horizontal = True):
                    dpg.add_text('Colorscale:')
                    dpg.add_combo(items = list(G.COLORMAP_SCALES), 
                                  width = 225,
                                  callback = self.update_volume, 
                                  default_value = 'Linear',
                                  tag = 'colormap_scale_combo')
                    dpg.add_checkbox(label = 'Rescale', 
                                     tag = 'rescale_colormap_checkbox', 
                                     callback = self.update_volume)
                
            with dpg.group(tag = 'mask_segmentation_options'):
                with dpg.group(horizontal = True, 
                               tag = 'mask_segmentation_group'):
                    dpg.add_text('Mask      :')
                    dpg.add_combo(items = list(G.MASK_DICT.keys()), 
                                  width = 225, 
                                  callback = self.update_volume, 
                                  default_value = 'Body', 
                                  tag = 'mask_combo')
                    dpg.set_value('mask_combo', 'Body')
                    dpg.add_checkbox(label = 'Enable', 
                                     tag = 'enable_mask_checkbox', 
                                     default_value=False, 
                                     callback = self.update_volume)

                with dpg.group(horizontal = True, 
                               tag = 'mask_exclude_low_group'):
                    dpg.add_text('Mask Low  :')
                    dpg.add_input_float(label = '', 
                                        callback = self.update_volume, 
                                        width = 150, 
                                        step = 1, 
                                        step_fast = 5,
                                        default_value = -3500, 
                                        tag = 'mask_exclude_low_float')
                    dpg.add_checkbox(label = 'Enable', 
                                     tag = 'enable_mask_low_exclude_checkbox', 
                                     default_value=False, 
                                     callback = self.update_volume)
                
                    with dpg.popup('mask_exclude_low_group', 
                                   min_size = [15, 15], 
                                   tag = f'mask_exclude_low_increment_popup'):
                        dpg.add_input_float(label = 'Increment', 
                                            step = 0.05, 
                                            step_fast = 0.5, 
                                            default_value = 1, 
                                            tag = f'mask_exclude_low_float_increment_input_float',
                                            min_value = 0.01, 
                                            max_value = 10.0, 
                                            min_clamped = True, 
                                            max_clamped = True, 
                                            callback = self.set_increment_value)

                with dpg.group(horizontal = True, 
                               tag = 'mask_exclude_high_group'):
                    dpg.add_text('Mask High :')
                    dpg.add_input_float(label = '', 
                                        callback = self.update_volume, 
                                        width = 150, 
                                        step = 1, 
                                        step_fast = 5,
                                        default_value = 3500, 
                                        tag = 'mask_exclude_high_float')
                    dpg.add_checkbox(label = 'Enable', 
                                     tag = 'enable_mask_high_exclude_checkbox', 
                                     default_value=False, 
                                     callback = self.update_volume)

                    with dpg.popup('mask_exclude_high_group', 
                                   min_size = [15, 15], 
                                   tag = f'mask_exclude_high_increment_popup'):
                        dpg.add_input_float(label = 'Increment', 
                                            step = 0.05, 
                                            step_fast = 0.5, 
                                            default_value = 1, 
                                            tag = f'mask_exclude_high_float_increment_input_float',
                                            min_value = 0.01, 
                                            max_value = 10.0, 
                                            min_clamped = True, 
                                            max_clamped = True, 
                                            callback = self.set_increment_value)
                    
                with dpg.group(horizontal = True, 
                               tag = 'mask_opacity_group'):
                    dpg.add_text('Opacity   :', 
                                 tag = 'mask_opacity_label')
                    dpg.add_input_float(label = '', 
                                        callback = self.update_volume, 
                                        width = 150, 
                                        step = 0.01, 
                                        step_fast = 0.1, 
                                        format = '%.2f', 
                                        default_value = 1.0, 
                                        min_value = 0.0, 
                                        max_value = 1.0, 
                                        min_clamped = True, 
                                        max_clamped = True, 
                                        tag = 'mask_opacity_slider')
                    
                    dpg.add_color_edit(label = 'Mask Color', 
                                       tag = 'mask_color_picker', 
                                       default_value=(20, 20, 230, 255), 
                                       no_inputs = True, 
                                       callback = self.update_volume)
            
            with dpg.group(tag = 'interpolation_options', 
                           horizontal=True):
                dpg.add_text('Interpolation:')
                dpg.add_combo(items = G.INTERPOLATION_OPTIONS, 
                              width = 225,
                              callback = self.update_volume, 
                              default_value = G.INTERPOLATION_OPTIONS[0], 
                              tag = 'interpolation_combo_box')

            with dpg.group(horizontal = True):
                dpg.add_text('(X, Y, Z, H):')
                dpg.add_text('(0, 0, 0, 0)\n(0, 0, 0, 0)\n(0, 0, 0, 0)', 
                             tag = 'mouse_position_text')
            with dpg.group(horizontal=True):
                dpg.add_text('             ')
                dpg.add_text('(0, 0, 0, 0)', 
                             tag = 'crosshair_position_text')
            
            with dpg.group(horizontal=True):
                dpg.add_text('Quaternion   ')
                dpg.add_text('(0, 0, 0, 0)', 
                             tag = 'OptionPanel_quaternion_display')
            with dpg.group(horizontal=True):
                dpg.add_text('Origin       ')
                dpg.add_text('(0, 0, 0)', 
                             tag = 'OptionPanel_origin_vector_display')
            with dpg.group(horizontal=True):
                dpg.add_text('Norm         ')
                dpg.add_text('(0, 0, 0)', 
                             tag = 'OptionPanel_norm_vector_display')

        self.disable_options()

    def set_volume_and_draw_objects(self,
                                    volume_layer_groups: VolumeLayer.VolumeLayerGroups,
                                    draw_window: NewMainView.MainView):
        
        self.volume_layer_groups = volume_layer_groups
        self.draw_window = draw_window

    def item_right_clicked(self, sender, app_data):
        popup_id = dpg.get_item_user_data(app_data[1])
        with dpg.mutex():
            if dpg.get_item_pos(popup_id) != dpg.get_mouse_pos():
                dpg.set_item_pos(popup_id, dpg.get_mouse_pos())
            if dpg.is_item_shown(popup_id):
                dpg.hide_item(popup_id)
            if not dpg.is_item_shown(popup_id):
                dpg.show_item(popup_id)
        
        print(f'OptionsPanel Message: {dpg.get_item_alias(popup_id)}, {dpg.get_item_pos(popup_id)}')

  
    def set_increment_value(self, sender, app_data):
        # Sender is of form: f'{G.OPTIONS_DICT[option_key]['slider_tag']}_increment_input_float'
        dpg.configure_item(sender.split('_increment_input_float')[0], step = app_data)
        dpg.configure_item(sender.split('_increment_input_float')[0], step_fast = 5*app_data)


    def update_image_index(self, 
                           sender, 
                           app_data, 
                           user_data):
        print(f'OptionsPanel Message: Setting image index {sender}: \n\tUpdated Index: (0, {app_data - 1})\n\tPrevious Index: {user_data}')
        dpg.set_item_user_data(sender, (0, app_data - 1))
        with dpg.mutex():
            # print('OptionsPanel Message: Deleting Texture')
            self.volume_layer_groups.get_current_volume().remove_texture_from_drawlist()
            self.volume_layer_groups.set_current_volume_by_index(0, app_data - 1)

            dpg.set_item_label(f'orientation_{G.GROUP_LAYER_CONTROL_BUTTON}', self.volume_layer_groups.get_current_volume().orientation_control)
            dpg.set_item_label(f'intensity_{G.GROUP_LAYER_CONTROL_BUTTON}', self.volume_layer_groups.get_current_volume().intensity_control)

            self.volume_layer_groups.get_current_volume().set_control_options('orientation', update = True)
            self.volume_layer_groups.get_current_volume().set_control_options('intensity', update = True)

            dpg.set_value('colormap_combo', self.volume_layer_groups.get_current_volume().colormap_name.current_value)
            dpg.set_value('reverse_colormap_checkbox', self.volume_layer_groups.get_current_volume().colormap_reversed)

            dpg.set_item_label(G.VOLUME_TAB_TAG, f'Volume Tab: {self.volume_layer_groups.get_current_volume().name}')
        self.update_volume()

       
    def update_frame_of_reference(self, sender, app_data, user_data):
        # print(sender, app_data)
        current_label = dpg.get_item_label(sender)
        frame_dict = {'Group': 'Layer', 'Layer': 'Group'}
        
        dpg.set_item_label(sender, frame_dict[current_label])
        # We update control so that we copy from Group to Layer upon a change. 
        self.volume_layer_groups.update_control()
        # G.APP.main_view.current_volume_info.update_control()
        self.update_option_values(sender)
        self.update_volume()
        
    def get_orientation_info(self):
        orientation_info = {'origin_x': dpg.get_value('origin_x_slider'),
                            'origin_y': dpg.get_value('origin_y_slider'),
                            'norm': dpg.get_value('norm_slider'),
                            'pitch': dpg.get_value('pitch_slider'),
                            'yaw': dpg.get_value('yaw_slider'),
                            'roll': dpg.get_value('roll_slider'),
                            'pixel_spacing_x': dpg.get_value('pixel_spacing_x_input'),
                            'pixel_spacing_y': dpg.get_value('pixel_spacing_y_input'),
                            'slice_thickness': dpg.get_value('slice_thickness_input'),
                            'drawlayer_tag': self.draw_window.return_texture_drawlayer_tag(self.draw_window.window_tag)}

        return orientation_info
    
    def get_intensity_info(self):
        intensity_info = {'colormap_name': dpg.get_value('colormap_combo'),
                          'colormap_reversed': dpg.get_value('reverse_colormap_checkbox'),
                          'min_intensity': dpg.get_value('min_intensity_slider'),
                          'max_intensity': dpg.get_value('max_intensity_slider'),
                          'window_size': 1.0,
                          'colormap_rescaled': dpg.get_value('rescale_colormap_checkbox'),
                          'colormap_scale_type': dpg.get_value('colormap_scale_combo'),
                          'colormap_scale_tag': self.draw_window.return_colormap_tag(self.draw_window.window_tag)}
        
        return intensity_info

    def update_volume(self):

        orientation_info = {'origin_x': dpg.get_value('origin_x_slider'),
                            'origin_y': dpg.get_value('origin_y_slider'),
                            'norm': dpg.get_value('norm_slider'),
                            'pitch': dpg.get_value('pitch_slider'),
                            'yaw': dpg.get_value('yaw_slider'),
                            'roll': dpg.get_value('roll_slider'),
                            'pixel_spacing_x': dpg.get_value('pixel_spacing_x_input'),
                            'pixel_spacing_y': dpg.get_value('pixel_spacing_y_input'),
                            'slice_thickness': dpg.get_value('slice_thickness_input'),
                            'drawlayer_tag': self.draw_window.return_texture_drawlayer_tag(self.draw_window.window_tag)}
        
        intensity_info = {'colormap_name': dpg.get_value('colormap_combo'),
                          'colormap_reversed': dpg.get_value('reverse_colormap_checkbox'),
                          'min_intensity': dpg.get_value('min_intensity_slider'),
                          'max_intensity': dpg.get_value('max_intensity_slider'),
                          'window_size': 1.0,
                          'colormap_rescaled': dpg.get_value('rescale_colormap_checkbox'),
                          'colormap_scale_type': dpg.get_value('colormap_scale_combo'),
                          'colormap_scale_tag': self.draw_window.return_colormap_tag(self.draw_window.window_tag)}

        print(f'OptionsPanel Message: ')
        for key, tag in G.OPTION_TAG_DICT.items():
            print(f'\t{f"{key} value":<30}: {dpg.get_value(tag)}')
        self.volume_layer_groups.update_current_volume(orientation_info, 
                                                       intensity_info)


    def reset_orientation(self):
        print(f"OptionsPanel Message: Resetting orientation.")
        for orientation_option_tag in G.ORIENTATION_OPTIONS:
            dpg.set_value(f'{orientation_option_tag}_current_value', 
                          G.OPTIONS_DICT[orientation_option_tag]['default_value'])
            dpg.set_value(G.OPTIONS_DICT[orientation_option_tag]['slider_tag'], 
                          G.OPTIONS_DICT[orientation_option_tag]['default_value'])
            
        self.volume_layer_groups.get_current_volume().reset_orientation()
        self.update_volume()

    def update_option_values(self, sender:str):
        control_category = sender.split(f'_{G.GROUP_LAYER_CONTROL_BUTTON}')[0]
        control_list = getattr(self.volume_layer_groups.get_current_volume(), 
                               f'{control_category}_control_list')
        for control_option_name in control_list: 
            option_tag = G.OPTION_TAG_DICT[control_option_name]
            if dpg.get_item_label(sender) == 'Group': # Indicates we've changed from Layer -> Group, so retrieve info from group_info
                control_option = getattr(getattr(self.volume_layer_groups.get_current_group(), 
                                                 control_category), 
                                                 control_option_name)
            else:# Indicates we've changed from Group -> Layer, so retrieve info from volume_info
                control_option = getattr(getattr(self.volume_layer_groups.get_current_volume(), 
                                                 control_category), 
                                                 control_option_name)
            dpg.set_value(f'{option_tag}_current_value', 
                          control_option.current_value)
            dpg.set_value(option_tag, 
                          control_option.current_value)


    def mouse_wheel_slider(self, sender, app_data):
        for option_key in G.OPTIONS_DICT.keys():
            if dpg.is_item_hovered(G.OPTIONS_DICT[option_key]['group_tag']) and dpg.is_item_enabled(G.OPTIONS_DICT[option_key]['slider_tag']):
                current_value_tag = '{0}_current_value'.format(G.OPTIONS_DICT[option_key]['slider_tag'])
                current_value = dpg.get_value(option_key)

                if option_key != 'img_index_slider':
                    step = 1.0*dpg.get_value(f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float')
                    
                else:
                    step = 1

                new_value = current_value + app_data * step
                
                clipped_new_value = self.clamp_option_value(option_key, new_value)
                
                # G.OPTIONS_DICT[option_key]['current_value'] = clipped_new_value
                dpg.set_value(current_value_tag, clipped_new_value)
                dpg.set_value(G.OPTIONS_DICT[option_key]['slider_tag'], clipped_new_value)
                
                self.update_volume()


    def clamp_option_value(self, option_key, new_value):

        if option_key in self.volume_layer_groups.get_current_volume().orientation_control_list:
            min_value = getattr(self.volume_layer_groups.get_current_volume().orientation, 
                                option_key).limit_low
            max_value = getattr(self.volume_layer_groups.get_current_volume().orientation, 
                                option_key).limit_high
                    
        elif option_key in self.volume_layer_groups.get_current_volume().intensity_control_list:
            min_value = getattr(self.volume_layer_groups.get_current_volume().intensity, 
                                option_key).limit_low
            max_value = getattr(self.volume_layer_groups.get_current_volume().intensity, 
                                option_key).limit_high
        
        else:
            min_value = G.OPTIONS_DICT[option_key]['min_value']
            max_value = G.OPTIONS_DICT[option_key]['max_value']

        if new_value < min_value:
            clipped_new_value = min_value
                    
        elif new_value > max_value:
            clipped_new_value = max_value

        else:
            clipped_new_value = new_value

        return clipped_new_value 
    

    def key_press_handler(self, sender, app_data):
        
        """
        app_data is an int corresponding to the key pressed. 
        
        """
        # print(sender, app_data)
        
        if app_data == dpg.mvKey_Right:
            value = 1
                    
        elif app_data == dpg.mvKey_Left:
            value = -1
            
        else:
            value = 0
        
        for option_key in G.OPTIONS_DICT.keys():
            if dpg.is_item_hovered(G.OPTIONS_DICT[option_key]['group_tag']) and dpg.is_item_enabled(G.OPTIONS_DICT[option_key]['slider_tag']):
                current_value_tag = f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_current_value'
                current_value = dpg.get_value(option_key)
                
                if option_key != 'img_index_slider':
                    step = 1*dpg.get_value(f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float')
                    step_fast = 5*dpg.get_value(f'{G.OPTIONS_DICT[option_key]["slider_tag"]}_increment_input_float')
                    
                else:
                    step = 1
                    step_fast = 5
                    
                if dpg.is_key_down(dpg.mvKey_Control):
                    new_value = current_value + value * step_fast
                else:
                    new_value = current_value + value * step

                clipped_new_value = self.clamp_option_value(option_key, new_value)
                
                # G.OPTIONS_DICT[option_key]['current_value'] = clipped_new_value
                dpg.set_value(current_value_tag, clipped_new_value)
                dpg.set_value(G.OPTIONS_DICT[option_key]['slider_tag'], clipped_new_value)
                
                self.update_volume()
            
                
    def enable_options(self):
        for option_tag in G.OPTION_TAGS:
            dpg.enable_item(option_tag)


    def disable_options(self):
        for option_tag in G.OPTION_TAGS:
            print(f'OptionsPanel Message: {option_tag} disabled' )
            dpg.disable_item(option_tag)

    def _cleanup_(self):
        pass