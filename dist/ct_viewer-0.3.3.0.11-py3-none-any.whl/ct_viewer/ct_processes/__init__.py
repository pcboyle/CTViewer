class CTViewer:
    # Main window chosen in ct_viewer.py, which contains the main() class. 
    def __init__(self, main_window):

        if G.GPU_MODE:
            cp.cuda.Device(G.DEVICE).use()

        from . import MenuBar
        from . import CTVolume
        from . import OptionsPanel
        from . import NodeEditor
        # from . import OptionValue
        # from . import MainView
        from . import NewMainView
        from . import AnalysisView
        from . import FileDialog
        # from . import FileIO
        from . import InformationBox
        from . import VolumeLayer
        from . import ImageTools
        from . import Themes

        # Set this instance as the ct_viewer. 
        print('Initialized')
        G.APP = self
        # self.FileIO = FileIO.FileIO()

        # self.Volumes = []
        self.VolumeLayerGroups:VolumeLayer.VolumeLayerGroups = VolumeLayer.VolumeLayerGroups()
        self.VolumeLayerGroups.add_group(group_name = 'AllVolumes', 
                                         default_origin = [0, 0, 0],
                                         default_angle = [0, 0, 0],
                                         default_norm = 0.0,
                                         default_intensity = [0, 1200, G.DEFAULT_IMAGE_SETTINGS['colormap'], 'Fire', 'Linear'],
                                         default_histogram = [-0.5, 1200.5, 1, 'Linear'],
                                         default_limits_origin = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                                         default_limits_norm = [-G.TEXTURE_CENTER, G.TEXTURE_CENTER], 
                                         default_limits_intensity = [[-1e6, 1e6 - 1], [-1e6 + 1, 1e6]])
        self.main_view:NewMainView.MainView = NewMainView.MainView(self.VolumeLayerGroups)
        self.texture_registry = dpg.add_texture_registry(tag = G.TEX_REG_TAG) # 'main_texture_registry'
        self.colormap_registry = dpg.add_colormap_registry(tag = G.COLORMAP_TAG)
        self.value_registry = dpg.add_value_registry(tag = G.VALUE_REG_TAG)
        self.handler_registry = dpg.add_handler_registry(tag = G.HANDLER_REG_TAG)
        # Need an item handler registry for hovering only. 
        self.item_handler_registry = dpg.add_item_handler_registry(tag = G.ITEM_HANDLER_REG_TAG)
        self.item_hovered_registry = dpg.add_item_handler_registry(tag = 'item_hovered_registry')
        self.themes = Themes.Themes()
        
        self.FileDialog = FileDialog.FileDialog(G.CONFIG_DICT['directories']['image_dir'], 
                                                has_parent = True,
                                                debug = False, 
                                                show = False)
        
        self.NodeEditor = NodeEditor.NodeEditor()

        G.add_input_options_to_value_registry(self.value_registry)
        G.add_configuration_to_value_registry(self.value_registry)
        G.add_texture_center_to_value_registry(self.value_registry)
        
        # Load up interpolators.
        CTVolume._initialize_interps()
        
        with main_window:
            self.menu_bar = MenuBar.MenuBar(value_registry = self.value_registry)
            with dpg.group(tag = 'RootWindowGroup',
                           horizontal = True):
                with dpg.child_window(tag = 'Navigation_Window',
                                      width = G.CONFIG_DICT['app_settings']['navigation_window_width'], 
                                      height = G.CONFIG_DICT['app_settings']['navigation_window_height'],
                                      border = True, 
                                      no_scrollbar = True):
                    with dpg.tab_bar(tag = G.LEFT_TAB_BAR, 
                                     callback = self.print_current_tab):
                        with dpg.tab(label = 'Navigation', 
                                     tag = G.NAVIGATION_TAB_TAG):
                            with dpg.group(tag = 'OptionsPanel_ImageTools_Group'):
                                self.options_panel = OptionsPanel.OptionsPanel(debug = True)
                                self.image_tools = ImageTools.ImageTools(self.VolumeLayerGroups)
                        # with dpg.tab(label = 'File Explorer', tag = G.FILE_EXPLORER_TAB_TAG):
                        #     self.file_explorer = FileExplorer.FileExplorer()
                with dpg.child_window(tag = 'MainViewTexture_Window',
                                      width = G.CONFIG_DICT['app_settings']['tab_pane_width'], #G.MAIN_TAB_VIEW_WINDOW_DEFAULTS['WINDOW_WIDTH'],
                                      height = G.CONFIG_DICT['app_settings']['tab_pane_height'], #G.MAIN_TAB_VIEW_WINDOW_DEFAULTS['WINDOW_HEIGHT'],
                                      border = True):
                    with dpg.tab_bar(tag = G.TAB_BAR_TAG, 
                                     callback = self.print_current_tab):
                        with dpg.tab(label = 'Volume Tab', 
                                     tag = G.VOLUME_TAB_TAG):
                            self.main_view.create_draw_window('MainTexture', 
                                                              G.VOLUME_TAB_TAG, 
                                                              item_handler_reg_tag=self.item_hovered_registry)
                        with dpg.tab(label = 'Analysis Tab', 
                                     tag = G.ANALYSIS_TAB_TAG):
                            self.analysis_view = AnalysisView.AnalysisView()
                
                self.info_box = InformationBox.InformationBox(self.VolumeLayerGroups)

        self.options_panel.set_volume_and_draw_objects(self.VolumeLayerGroups,
                                                       self.main_view)
        
        self.options_panel.set_info_box(self.info_box)
        
        self.FileDialog.initialize(volume_layer_groups = self.VolumeLayerGroups,
                                   draw_window = self.main_view,
                                   options_panel = self.options_panel,
                                   information_box = self.info_box,
                                   debug = G.DEBUG_MODE)
        
        dpg.add_item_hover_handler(parent = self.item_hovered_registry, 
                                   callback = self.VolumeLayerGroups.update_mouse_volume_coord_info)
        dpg.bind_item_handler_registry(self.main_view.return_texture_drawlist_tag(self.main_view.window_tag),
                                       self.item_hovered_registry)
        
        dpg.add_key_press_handler(key = dpg.mvKey_None, 
                                  callback = self.options_panel.mouse_and_keyboard_navigation, 
                                  tag = 'mouse_and_keyboard_navigation_handler', 
                                  parent = self.handler_registry)

    def print_current_tab(self, sender, app_data):
        print('Tab clicked!')
        print('Sender: ', sender)
        print('App Data: ', app_data)

    def _cleanup_(self):
        dict_keys = list(self.__dict__.keys())
        while len(dict_keys) > 0:
            attrib_key = dict_keys.pop()
            try: 
                getattr(self, attrib_key)._cleanup_()
            except:
                pass
            finally:
                setattr(self, attrib_key, None)
                delattr(self, attrib_key)
        
from .Globals import *